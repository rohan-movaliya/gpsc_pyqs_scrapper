# 04 - AI Mock Interview System — Redis Session Management

> **Version**: 1.1.0  
> **Last Updated**: February 2026  
> **Topic**: Distributed State & Persistence with Redis

---

## **1\. Overview**

Originally, the system managed interview sessions using a global in-memory dictionary (`active_interviews`). While simple for development, this approach was not production-ready because:

1.  **No Persistence**: Restarting the server wiped all active interviews.
2.  **Not Scalable**: Multiple server workers couldn't share the same memory, making horizontal scaling impossible.
3.  **Memory Bloat**: Long-running sessions consumed server RAM indefinitely.

We have refactored the system to use **Redis** for distributed, persistent, and horizontally scalable session management.

---

## **2\. Architecture**

The backend follows a **stateless** service pattern. The `InterviewService` no longer stores data; it retrieves the session state from Redis at the start of every request and saves it back at the end.

```
┌─────────────────┐       ┌─────────────────┐       ┌───────────────┐
│     Client      │ ────> │ FastAPI Backend │ ────> │ Redis Storage │
│ (React Frontend)│ <──── │   (Stateless)   │ <──── │ (Session Data)│
└─────────────────┘       └─────────────────┘       └───────────────┘
                                  │
                                  ▼
                          ┌─────────────────┐
                          │   LLM Engines   │
                          │ (Gemini / Groq) │
                          └─────────────────┘
```

### **Key Components**

| Component | Path | Responsibility |
| --- | --- | --- |
| `RedisSessionManager` | `app/services/session_manager.py` | Implementation of CRUD operations on Redis. |
| `InterviewSession` | `app/apis/interview/schemas.py` | Pydantic model for serializable session data. |
| `redis_client.py` | `app/infrastructure/cache/redis_client.py` | Async Redis connection pooling and client setup. |

---

## **3\. Data Model & Serialization**

Because Redis is a key-value store, we cannot directly store Python objects (like LangChain Memory or LLM Chains). Instead, we store a **serializable snapshot** of the session.

### `InterviewSession` **(Pydantic Model)**

This model contains only the "raw" data required to re-hydrate the session logic:

- `session_id`: Unique UUID.
- `chat_history`: List of `(Question, Answer)` pairs.
- `extracted_resume_data`: The structured JSON from the initial resume scan.
- `current_topic`, `covered_topics`, `followup_count`: State variables for the interview flow.

### **Serialization Flow**

1.  **Save**: `session.model_dump_json()` → Redis String.
2.  **Load**: Redis String → `InterviewSession.model_validate_json()` → Python Object.

---

## **4\. State Re-hydration**

When a request comes in (e.g., `POST /answer`), the service performs **Re-hydration**:

1.  Fetches the `InterviewSession` data from Redis.
2.  Reconstructs the **LangChain Conversation Memory** by re-applying the `chat_history`.
3.  Re-initializes the **LLM Chains**.
4.  Performs the AI logic.
5.  Updates the data model and saves it back to Redis.

This ensures that the LLM always has the full "context" of the conversation, even if the request is handled by a different server instance than the previous one.

---

## **5\. Implementation Details**

### **TTL & Session Expiry**

To prevent Redis from filling up with abandoned sessions, we use a **Time-To-Live (TTL)**.

- Default TTL: **1 Hour**.
- Every time a candidate submits an answer or starts a stream, the session is **refreshed**, resetting the 1-hour timer.

### **Concurrent Background Extraction**

When an interview starts, resume extraction runs as a **Background Task**.

1.  The initial `/start` response is returned immediately to the user.
2.  The background task fetches the session from Redis.
3.  It performs the extraction.
4.  it saves the structured data back to the Redis session.

---

## **6\. Configuration**

The Redis connection is configured in `app/core/constants.py`:

```env
REDIS_URL=redis://localhost:6379/0
```

In production (Docker), this is typically set to:

```env
REDIS_URL=redis://redis:6379/0
```

### **Docker Integration**

We use a dedicated Redis container in `docker-compose.yml`:

```typescript
services:
  redis:
    image: redis:7-alpine
    container_name: mock_interview_redis
    ports:
      - "6379:6379"
    volumes:
      - redis_data:/data
```

---

## **7\. Benefits**

1.  **Scalability**: Add 10 more API instances; they all share the same Redis store.
2.  **Persistence**: The server can crash or restart, and the candidate's interview session remains exactly where it was.
3.  **Infrastructure Readiness**: Redis is the industry standard for session management, making this project ready for AWS/GCP/Azure deployment.