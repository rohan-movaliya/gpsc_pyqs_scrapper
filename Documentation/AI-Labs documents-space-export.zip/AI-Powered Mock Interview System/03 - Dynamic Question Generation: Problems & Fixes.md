# 03 - Dynamic Question Generation: Problems & Fixes

> **Date:** 2026-02-19 **Files changed:** `app/ai/prompts/templates.py`, `app/apis/interview/services.py`

---

## **Overview**

This document records all the bugs, root causes, and fixes applied to the interview question generation pipeline to make it behave like a real, adaptive interviewer.

---

## **Problem 1 — Prompt Was Too Simple (No Real Interviewer Logic)**

### **Symptom**

The question chain only had two modes:

- **Switch topic** — if the candidate said they didn't know.
- **Stay on topic** — for every other answer, regardless of confidence.

There was no concept of escalating difficulty when the candidate answered confidently, no targeted follow-ups for partial answers, and no natural topic rotation after a few questions on the same topic.

### **Root Cause**

The original `interview_question_template` had only two decision branches and no way to distinguish between a strong, partial, or weak answer.

### **Fix**

Rewrote the prompt to classify every answer into one of four categories:

| Classification | Criteria |
| --- | --- |
| **STRONG** | Correct, detailed, uses precise terminology |
| **PARTIAL** | Right idea but vague, lacks depth or edge cases |
| **WEAK** | Incorrect, shallow, mostly guessing |
| **BLANK** | "Don't know", skip request, or irrelevant answer |

Added decision logic per classification:

| Situation | Action |
| --- | --- |
| BLANK | Immediately switch topic |
| STRONG + followup_count < 2 | Ask a harder question on same topic |
| STRONG + followup_count ≥ 2 | Switch topic (expertise proven) |
| PARTIAL | Ask targeted follow-up on the missing piece |
| WEAK + first attempt | Ask a simpler version of the same question |
| WEAK + already tried once | Switch topic |
| followup_count ≥ 3 | Always switch topic (hard cap) |

---

## **Problem 2 —** `followup_count` **Not Passed to Groq Fallback**

### **Symptom**

```
ERROR: Input to PromptTemplate is missing variables {'followup_count'}.
Expected: ['chat_history', 'experience', 'followup_count', 'job_role', 'resume_data']
Received: ['chat_history', 'resume_data', 'experience', 'job_role']
```

The system fell back to a hardcoded `FALLBACK_QUESTION` on every answer because the Groq fallback path crashed with an `INVALID_PROMPT_INPUT` error.

### **Root Cause**

The Groq fallback block inside `process_answer_stream` had its own hardcoded `invoke_input` dict that was built **before** `followup_count` was added to the template. It was missing the new variable.

### **Fix**

Added `"followup_count": state.followup_count` to the Groq fallback `invoke_input` inside `process_answer_stream`.

**Location:** `services.py` → `process_answer_stream` → Groq fallback block.

---

## **Problem 3 — Rapid Topic Switching (Irrelevant Questions)**

### **Symptom**

Even with the new prompt, the interviewer was constantly switching topics after every single answer. Follow-up questions were not relevant to what the candidate had just said.

### **Root Cause**

The `chat_history` was being passed to the prompt as raw **LangChain Python objects** (`state.memory.chat_memory.messages`). When LangChain serialised this list into the prompt string, the LLM received:

```
[AIMessage(content='Can you tell me about Python?', additional_kwargs={}, response_metadata={}, id='...'),
 HumanMessage(content='I use it for web dev', additional_kwargs={}, ...)]
```

The LLM could not parse this as a readable conversation, so it could not determine what topic was being discussed. It defaulted to classifying every answer as BLANK and switched the topic immediately.

### **Fix**

Added a `_format_chat_history()` helper method that converts the `state.chat_history` list of `(question, answer)` tuples into a clean, human-readable dialogue:

```
Interviewer: Can you tell me about Python?
Candidate: I use it for web development with Django...

Interviewer: How do you handle database migrations in Django?
Candidate: I use the built-in django.db.migrations framework...
```

This clean format allowed the LLM to correctly identify the current topic, classify the answer, and generate a proper follow-up.

**All three** `invoke_input` **sites** were updated (sync path, streaming path, Groq fallback path).

---

## **Problem 4 — Hallucination After Second Topic Change**

### **Symptom**

The first topic's follow-up questions worked correctly. But after the second or third topic change, the questions became increasingly irrelevant — often repeating questions from earlier topics or asking about completely unrelated subjects.

### **Root Cause**

Two compounding issues:

1.  **Growing context window** — the full `chat_history` was injected into every prompt, so by turn 10+, the prompt contained 1000+ tokens of old conversation. The LLM's attention spread too thin and it confused older topics with the current one.
2.  **No explicit topic anchoring** — the LLM had to _infer_ the current topic by reading the full conversation history. After multiple topic switches, this inference became unreliable.

### **Fix**

Replaced the single `chat_history` variable with three focused variables:

| Variable | Contents | Why |
| --- | --- | --- |
| `current_topic` | The exact topic being discussed now (e.g. `"Python's GIL"`) | LLM is told explicitly what to stay on |
| `covered_topics` | Comma-separated list of already-done topics | LLM avoids revisiting them when switching |
| `recent_history` | Only the **last 3 Q&A turns** | Keeps prompt size constant regardless of session length |

Added to `InterviewState`:

```python
self.current_topic = "General technical skills"
self.covered_topics: list[str] = []
```

Updated logic in `process_answer` and `process_answer_stream`:

- On **switch_topic = True**: appends `current_topic` to `covered_topics`, extracts the new topic label from the next question, resets `followup_count`.
- On **switch_topic = False**: increments `followup_count`.

Added `_format_recent_history(chat_history, n_turns=3)` helper to return only the last N turns as a clean string.

### **Result**

The prompt is now **always the same compact size** regardless of how long the interview runs. The LLM receives explicit anchors for the current topic and a blocklist of covered topics, preventing both context overload and topic repetition.

---

## **Summary of All Changes**

### `app/ai/prompts/templates.py`

| Change | Detail |
| --- | --- |
| New input variables | `current_topic`, `covered_topics`, `recent_history`, `followup_count` (removed old `chat_history`) |
| Answer classification | 4-way STRONG / PARTIAL / WEAK / BLANK classification |
| Decision table | Bullet-point rules per classification + followup_count value |
| Topic switch guard | Step 3 explicitly references `covered_topics` blocklist |
| Stay-on-topic guard | Step 4 explicitly references `current_topic` to prevent drift |

### `app/apis/interview/services.py`

| Change | Detail |
| --- | --- |
| `InterviewState.followup_count` | Tracks consecutive follow-ups on current topic |
| `InterviewState.current_topic` | Tracks the active topic label |
| `InterviewState.covered_topics` | Tracks all previously covered topics |
| `_format_recent_history()` | New helper — returns last 3 turns as clean dialogue |
| `_format_chat_history()` | Existing helper — retained for full-history use cases (e.g. evaluation) |
| All `invoke_input` dicts | Updated in sync path, streaming path, and Groq fallback path |
| Topic archival logic | On switch: appends current_topic → covered_topics, resets followup_count |

---

## **Architecture Diagram — Prompt Data Flow (After Fix)**

```
InterviewState
├── chat_history          → _format_recent_history() → recent_history (last 3 turns)
├── current_topic         ─────────────────────────→ current_topic
├── covered_topics        ─────────────────────────→ covered_topics (comma-joined)
├── extracted_resume_data → _format_resume_data()  → resume_data
├── experience            ─────────────────────────→ experience
├── job_role              ─────────────────────────→ job_role
└── followup_count        ─────────────────────────→ followup_count
                                          │
                                          ▼
                             interview_question_template
                                          │
                                          ▼
                              Gemini / Groq LLM
                                          │
                                          ▼
                         {"switch_topic": bool, "question": str}
                                          │
                           ┌─────────────┴─────────────┐
                           │                           │
                    switch_topic=true           switch_topic=false
                           │                           │
              append current_topic            followup_count += 1
              to covered_topics
              update current_topic
              reset followup_count = 0
```