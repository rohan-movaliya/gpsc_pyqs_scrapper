# Voice-to-Voice Interview System — Design & Decision Document

# **1\. Overview**

We initially implemented the **Voice-to-Voice Interview Feature** using **LiveKit Realtime Plugins**.

## **What are LiveKit Realtime Plugins?**

LiveKit Realtime Plugins provide a **ready-made voice pipeline agent** that handles:

- Audio streaming (WebRTC)
- Speech-to-Text (STT)
- LLM interaction
- Text-to-Speech (TTS)

It acts as an **end-to-end voice pipeline**, where we can attach tools and logic.

# **2\. Initial Approach**

We used:

LiveKit Realtime Agent → STT → LLM → TTS → Response

Additionally, we implemented:

- **Interview State Management**
    - When to change topic
    - When to ask follow-up
    - When to repeat question
    - Based on answer quality (STRONG / WEAK / etc.)

# **3\. Problem Faced (Critical Issue)**

## **Hallucination & Control Issues**

We observed:

- The system **hallucinated questions**
- It **missed correct question flow**
- Sometimes:
    - wrong follow-up
    - wrong topic switch
    - ignored state logic

##  **Root Cause**

 Due to **Realtime Agent behavior**

- The agent processes **streaming input continuously**
- It does NOT clearly know:  
    when to call tools (LLM, logic)
- No clear boundary of:
    - "user finished speaking"
    - "now generate next question"

Result:x\`

Loss of control over interview logic

---

# **4\. New Approach (Custom Pipeline)**

We decided:

**Do NOT rely fully on LiveKit Realtime Agent**

Instead:

Use LiveKit ONLY for streaming

Build our own pipeline logic

---

# **5\. Final Architecture**

User (Voice)

    ↓

LiveKit (audio streaming)

    ↓

STT (Speech-to-Text)

    ↓

Interview Logic (LLM + State)

    ↓

TTS (Text-to-Speech)

    ↓

LiveKit → Audio Output

---

# **6\. Latency Problem**

In this pipeline:

STT → LLM → TTS (sequential)

This introduces delay.

---

# **7\. Optimization Strategy**

## **Parallel Processing**

We improved design using:

### **VAD (Voice Activity Detection) + STT**

User speaks → audio chunks → STT runs continuously

Benefits:

- STT works **during speech**
- Reduces post-speech delay

---

# **8\. STT Research & Comparison**

## **8.1 Whisper**

###  **Pros:**

- Free
- Good accuracy

###  **Cons:**

- Not streaming
- Reprocesses full audio repeatedly
- High CPU usage

---

## **8.2 Google STT**

### **Latency:**

- ~200–400 ms

### **Cost:**

- ~$0.48 per 20 min interview

###  **Issue:**

- Expensive for scale

---

## **8.3 Deepgram (Selected)**

### **Latency:**

- ~150–300 ms

### **Cost:**

- ~$0.10 per 20 min interview

### **Pros:**

- True streaming STT
- Low latency
- Easy integration

### **Cons:**

- $200 free credits (limited for long term)

---

# **9\. TTS Research & Comparison**

## **9.1 Edge TTS**

###  **Issues:**

- Robotic voice
- Poor pronunciation
- Not suitable for interviews

---

## **9.2 ElevenLabs**

### **Pros:**

- Very natural voice

### **Cons:**

- Limited credits (~10k words)
- Expensive for testing

---

## **9.3 PlayHT**

###  **Pros:**

- Good voice quality

###  **Cons:**

- Limited credits (~5000 words)
- Latency issues

---

## **9.4 Sarvam TTS**

###  **Limitation:**

- Only ~1000 free credits

---

## **9.5 Qwen3 TTS**

### **Issues:**

- Latency: ~1–3 seconds
- GPU: 8–16 GB required

---

## **9.6 Fish Voice**

### **Issues:**

- Latency: ~500ms – 1s (GPU)
- GPU: 4–8 GB
- Slow on CPU

---

## **9.7 Kokoro (Selected)**

### **✅ Pros:**

- Good balance of quality
- Lower GPU requirement (~1–4 GB)
- Better than basic open-source models

### **Cons:**

- No streaming support
- CPU latency exists

---

# **10\. Final Pipeline Decision**

## **Selected Stack**

STT → Deepgram

LLM → Existing Interview Logic

TTS → Kokoro

---

# **11\. Final Latency Calculation**

## **Given:**

- STT → ~300 ms
- LLM → ~600 ms
- TTS → ~400–800 ms

---

## **Total Latency:**

~1.5 to 2 seconds

---

# **12\. Key Insights**

## **1\. Streaming vs Control Trade-off**

|     |     |     |
| --- | --- | --- |
| **Approach** | **Advantage** | **Problem** |
| LiveKit Realtime Agent | Low latency | No control |
| Custom Pipeline | Full control | Slight delay |

---

## **2\. Latency Optimization**

- STT runs during speech ✅
- Reduces waiting time after speech

---

## **3\. Most Critical Learning**

Pipeline design > Individual model choice

---

## **4\. Final Trade-off**

We chose:

Better control + acceptable latency

over

Uncontrolled real-time behavior

---

# **13\. Final Conclusion**

- LiveKit Realtime Agent is powerful but **not suitable for strict logic systems like interviews**
- Custom pipeline provides:
    - deterministic behavior
    - better control
    - reliable question flow

Final system achieves:

Controlled interview flow + ~1.5–2s latency