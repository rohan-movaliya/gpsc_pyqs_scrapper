# 06 — Voice-to-Voice Implementation Guide

# **06 — Voice-to-Voice Implementation Guide**

This document provides a deep dive into the **Voice-to-Voice** interview feature. Unlike the Text-mode, which uses Server-Sent Events (SSE), the Voice-mode leverages **WebRTC** via **LiveKit** to provide a low-latency, natural conversational experience.

---

## **1\. High-Level Architecture**

The voice feature is split into four distinct layers that interact in real-time:

```mermaid
graph TD
    User((Candidate)) <--> |Audio WebRTC| LK[LiveKit Cloud]
    LK <--> |Audio WebRTC| VW[Voice Worker]
    VW <--> |HTTP REST| BE[FastAPI Backend]
    BE <--> |Query/Store| RD[(Redis)]
```

1.  **Frontend (React):** Handles microphone capture and connects to the LiveKit Room.
2.  **LiveKit Cloud:** Acts as the WebRTC SFU, routing audio between the user and our AI worker.
3.  **Voice Worker (**`voice_agent.py`**):** A standalone Python service (Docker) that acts as the "orchestrator." it joins the room as a participant.
4.  **Backend (FastAPI):** Serves as the "Brain." The Voice Worker calls the same REST API as the Text-mode, ensuring consistent evaluation logic.

---

## **2\. The Orchestration Pipeline**

The "Voice-to-Voice" experience is actually a coordinated pipeline of four AI models:

### **A. Speech-to-Text (STT)**

- **Provider:** Groq (Whisper-large-v3).
- **Role:** Converts the user's spoken audio into text in milliseconds.
- **Optimization:** Configure with extremely low silence detection to minimize lag.

### **B. Logic & Orchestration (LLM)**

- **Brain:** `BackendLLM` (in `voice_agent.py`).
- **Flow:** This component extracts the transcript from STT and sends it to `POST /api/v1/interview/answer`**.**
- **Benefit:** By using the REST API, we guarantee that the voice interview follows the exact same resume-aware, difficulty-calibrated logic as the text interview.

### **C. Text-to-Speech (TTS)**

- **Provider:** OpenAI (Onyx voice).
- **Role:** Converts the text response from the backend into a high-quality, natural-sounding human voice.

### **D. Activity & Turn Detection (VAD)**

- **Provider:** Silero VAD (Local).
- **Calibration:** Using `min_endpointing_delay=1.2s`. This allows candidates to pause and think during technical answers without being interrupted by the AI.

---

## **3\. Data Flow Example**

1.  **User says:** _"I used TensorFlow for a project..."_ (VAD detects speech).
2.  **User stops speaking:** (VAD waits 1.2s).
3.  **STT (Groq):** Transcribes the audio → _"I used TensorFlow for a project"_.
4.  **Worker:** Submits transcript to `backend/api/v1/interview/answer`.
5.  **Backend:**
    - Evaluates the answer.
    - Generates the _next_ follow-up question.
    - Updates Redis session.
    - Returns: _"That's great. How did you handle data augmentation in that project?"_
6.  **TTS (OpenAI):** Streams the audio back to the user via LiveKit.

---

## **4\. Stability & Edge Cases**

### **The "Repeat Intent" Problem**

During voice interviews, users often say fragments like _"Can you repeat?"_ or _"What do you mean?"_.

- **Solution:** We implemented a "Step 0" check in the \[Prompt Template\](file:///home/root495/Inexture/mock_interview/backend/app/ai/prompts/templates.py).
- If the user's transcript matches a clarification request, the backend detects `repeat=true` and re-phrases the current question instead of moving to a new topic.

### **Context Management**

The `voice_agent.py` maintains a `ChatContext` which is mirrored in the Backend's Redis session. This ensures that even if a network interruption occurs, the interview can resume exactly where it left off.

---

## **5\. Deployment & Configuration**

The voice feature is fully containerized. Use the following command to start the entire stack:

```bash
cd backend
docker compose up -d --build
```

**Required Env Vars:**

- `LIVEKIT_URL`, `LIVEKIT_API_KEY`, `LIVEKIT_API_SECRET`
- `GROQ_API_KEY` (for STT)
- `OPENAI_API_KEY` (for TTS)
- `GOOGLE_API_KEY` (Optional fallback for LLM)

---