# 08 — Roadmap & Pending Work: DB Migration, Authentication, JD Input, Dashboard, History, & Voice-to-Voice

## **1\. Overview & Strategic Sequence**

To move the AI Mock Interview system from a single-user prototype to a scalable, multi-tenant enterprise application, we must address several architectural limitations. The current use of a local SQLite database (`interview.db`) acts as a primary blocker for implementing user-specific histories, secure authentication, and robust tracking.

The implementation must follow a precise sequential progression to ensure each task builds upon stable foundations:

```mermaid
graph TD
    A[Task 1: PostgreSQL Migration] --> B[Task 2: Implement User Authentication]
    B --> C[Task 3: Refactor JD Input & Dashboard]
    C --> D[Task 4: Research & Plan History + Retakes]
    D --> E[Task 5: Finalize & Polish Voice-to-Voice System]
```

---

## **2\. Task 1: PostgreSQL Migration**

### **2.1 The SQLite Blocker**

Currently, the backend uses direct SQLite queries to manage a single table (`interview_results`). This is inadequate for production because:

- **Concurrency**: SQLite locks the database file during writes, which causes latency and errors under concurrent user loads.
- **Scalability**: A single flat table cannot scale to handle user profiles, organizational permissions, and detailed interview histories.
- **Data Durability & Isolation**: Data is stored locally inside the container's volume, making it difficult to secure, scale, and back up in a production environment.

### **2.2 Migration Plan**

- **PostgreSQL Setup**: Provision a PostgreSQL instance (via Docker Compose for development and managed DB for staging/production).
- **ORM Integration**: Integrate SQLAlchemy or SQLModel as the Object-Relational Mapper (ORM) along with Alembic for database migration and version control.
- **Connection Lifecycle**: Replace the custom database connections in the core backend with a FastAPI database session dependency (`get_db`) to ensure efficient connection pooling and transaction lifecycle management.

---

## **3\. Task 2: User Authentication & Profile Setup**

Once PostgreSQL is established, we will implement the authentication and authorization layers necessary to associate data with specific users rather than a single global default.

### **3.1 Profile and Authentication Setup**

- **Scope**: For the initial release, the system will support a single user role (the Candidate). This establishes the infrastructure for identity and access management while keeping the authentication surface simple.
- **Authentication**: Integrate FastAPI's OAuth2 with JWT tokens for secure registration and login.
- **User Identity**: Move from a global, hardcoded `"default_user"` identifier to dynamic user accounts, ensuring candidate-data isolation.

### **3.2 Frontend Integration**

- **Auth State**: Manage authentication tokens and current user session data via a React context provider (`AuthContext`).
- **Routing**: Wrap routes in an authentication-based router wrapper to restrict page access to logged-in users.

---

## **4\. Task 3: Job Description (JD) Input & Dashboard Refactoring**

### **4.1 Job Description (JD) Input Flow**

The current session setup relies on resume analysis and custom input fields. We need to tie interviews to formal Job Descriptions stored in the database.

- **JD Selection**: Update the candidate setup wizard to let candidates select from active JDs instead of manually typing role details.
- **Resume-to-JD Matching**: Update the backend logic in the interview initialization endpoint to fetch the chosen JD from PostgreSQL and feed it to the LLM context. This ensures that the generated interview questions are calibrated specifically against the target job's requirements and experience level.

### **4.2 Dashboard Page Refactoring**

The dashboard will be refactored to handle individual user profiles:

#### **Candidate Dashboard**

- **Progress Tracking**: Visual progression charts (e.g., Technical, Communication, Confidence, Behavioral scores over time).
- **Attempt History**: List of past interview attempts with completion status and links to detailed feedback reports.
- **Targeted Feedback**: Summaries of key strengths and improvement areas dynamically pulled from previous reports.

---

## **5\. Task 4: Research & Plan History + Retake Functionality**

To allow candidates to view their historic performance and retake interviews to measure improvement, we need to design a persistent attempt tracking model.

### **5.1 Research Scope**

- **Data Retention**: Study optimal ways to store full conversation histories (question-and-answer pairs, response times, and audio/video files) associated with each attempt without causing table bloat.
- **Retake Logic**: Research how to design the "Retake" flow—specifically, how a new attempt is initiated, how the system links attempts to the same Job Description, and how to represent this progression cleanly on the dashboard.
- **Performance Comparison**: Investigate methods to pass previous attempt scores to the LLM (Gemini) during evaluation, enabling the generation of comparative progression feedback (e.g., identifying whether the user improved or regressed in specific evaluation metrics).

---

## **6\. Task 5: Voice-to-Voice Feature Finalization & Polish**

The Voice-mode currently leverages WebRTC via LiveKit and is driven by a standalone orchestrator (`voice_agent.py`) using STT (Groq), LLM (Gemini), TTS (OpenAI), and VAD (Silero).

### **6.1 Technical Approach**

- **Architecture**: Standardize on **LiveKit WebRTC + Voice Agent Orchestrator**. This approach provides the sub-1.5s latency required for a natural, flowing conversation, avoiding the jitter and echo issues associated with raw HTTP polling or WebSockets.
- **Database Integration**: Sync voice interview transcripts, durations, and evaluations back to PostgreSQL in real-time or upon completion.

### **6.2 Functionality & Flow Improvements**

- **Interruption Handling**: Implement an interruption listener. If Voice Activity Detection (VAD) detects that the candidate is speaking while the AI is responding, the agent must immediately stop streaming the current audio response.
- **Turn-Taking Calibration**: Calibrate Silero VAD thresholds to distinguish intentional pauses (e.g., thinking during a coding explanation) from completed sentences to prevent the AI from interrupting the candidate.
- **Session Resilience**: Allow the client to reconnect and resume an active voice session if the WebRTC connection drops.

### **6.3 UI/UX Improvements**

- **Voice Waveform UI**: Add a responsive audio waveform visualizer showing active voice amplitude for both candidate and agent.
- **Status Indicators**: Display clear states (e.g., `Connecting`, `Listening`, `Thinking`, `Speaking`) to keep the user informed.
- **Network Quality Guard**: Add real-time network quality metrics, warning the candidate if high latency or packet loss is likely to impact their voice experience.