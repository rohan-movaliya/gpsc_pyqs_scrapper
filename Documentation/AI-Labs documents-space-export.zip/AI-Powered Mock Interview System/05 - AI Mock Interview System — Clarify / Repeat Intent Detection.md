# 05 - AI Mock Interview System — Clarify / Repeat Intent Detection

> **Version**: 1.2.0  
> **Last Updated**: March 2026  
> **Topic**: Handling Candidate Clarification Requests During the Interview

---

## **1\. Overview**

Previously, when a candidate responded with a clarification request such as _"Can you please rephrase that?"_ or _"I didn't understand the question"_, the system incorrectly treated it as a real interview answer and moved on — generating a new question, incrementing the follow-up counter, and potentially switching topics.

This document describes the **Clarify / Repeat Intent Detection** feature, which detects these requests and re-elaborates the current question in simpler language **without advancing the interview state**.

---

## **2\. How It Works**

### **Flow Diagram**

```
Candidate submits a message
          │
          ▼
  LLM evaluates message (Step 0 in prompt)
          │
    ┌─────┴──────────────────────┐
    │                            │
repeat = true               repeat = false
(clarification request)     (real answer)
    │                            │
    ▼                            ▼
Re-elaborate same          Normal interview flow:
question in simpler        - Append to chat history
language.                  - Increment followup_count
                           - Evaluate answer quality
Do NOT:                    - Switch topic if needed
- Append to chat history
- Increment followup_count
- Change topic
```

### **The** `repeat` **Flag**

The LLM now returns a three-key JSON response on every turn:

```json
{
  "switch_topic": false,
  "repeat": true,
  "question": "Sure! A decorator is simply a function that wraps another function to add behaviour. When would you use one?"
}
```

| Key | Type | Description |
| --- | --- | --- |
| `switch_topic` | bool | Whether to advance to a new resume topic. |
| `repeat` | bool | `true` if the candidate is asking for clarification, not answering. |
| `question` | string | The next question (or re-elaborated version of the same question). |

---

## **3\. Clarification Patterns Detected**

The LLM (Step 0 in `interview_question_template`) recognises the following candidate intents as clarification requests:

| Example Phrase | Detected As |
| --- | --- |
| "I didn't understand the question" | ✅ Repeat |
| "Can you please rephrase that?" | ✅ Repeat |
| "What do you mean?" | ✅ Repeat |
| "Could you explain that differently?" | ✅ Repeat |
| "Please say that again / simplify" | ✅ Repeat |
| Any non-answer asking to re-hear the question | ✅ Repeat |
| An actual technical answer | ❌ Not repeat — normal flow |

---

## **4\. Files Changed**

### **Backend**

#### `app/ai/prompts/templates.py`

- Added **Step 0** to `interview_question_template` — executed before the existing Steps 1–6.
- Step 0 detects clarification intent and sets `repeat = true`.
- Added `repeat` key to the required JSON output format.

```
Step 0 — Detect REPEAT / CLARIFICATION intent FIRST:
  If the candidate's last message is a clarification request:
    → Set repeat = true
    → Re-state the CURRENT question in simpler language
    → Set switch_topic = false
  Otherwise:
    → Set repeat = false
    → Proceed with Steps 1–6 as normal
```

#### `app/apis/interview/schemas.py`

- Added `repeat: bool = False` to `InterviewSession`.
- This persists the flag in Redis for every session turn.

#### `app/apis/interview/services.py`

Both `process_answer` (sync) and `process_answer_stream` (SSE streaming) were updated with the same pattern:

```python
# Build context with candidate's message so LLM can detect intent,
# but don't commit to chat_history yet.
temp_history = session.chat_history + [(session.current_question, answer)]

# ... invoke LLM ...

is_repeat = bool(parsed.get("repeat", False))
session.repeat = is_repeat

if is_repeat:
    # Freeze all interview state — just update the question text
    logger.info("Repeat intent detected. Re-elaborating question.")
else:
    # Normal answer — commit to history and advance state
    session.chat_history.append((session.current_question, answer))
    if session.switch_topic:
        session.covered_topics.append(session.current_topic)
        session.current_topic = next_question.split("?")[0][:60].strip()
        session.followup_count = 0
    else:
        session.followup_count += 1
```

> **Key design decision**: The candidate's answer is built into `temp_history` (a local copy) so the LLM has full context to judge intent, but it is only written to `session.chat_history` if `repeat=False`. This ensures the final evaluation never sees clarification requests — only real answers.

---

## **5\. Streaming Response**

For the SSE streaming endpoint (`/answer/stream`), the `done` event now includes the `repeat` flag so the frontend can react if needed:

```json
{ "done": true, "question": "...", "repeat": true }
```

---

## **6\. Interview Evaluation Impact**

Because clarification exchanges are **not appended to** `chat_history`, the end-of-session evaluation (`POST /interview/end`) only sees genuine Q&A pairs. The candidate is not penalised for asking for a simpler phrasing.

---

## **7\. Example Scenario**

```
Interviewer: Can you explain what a Python decorator is and how it works internally?

Candidate: Sorry, I didn't quite understand that question. Could you rephrase it?

System detects: repeat = true
→ followup_count stays at 0
→ chat_history unchanged
→ No topic switch

Interviewer: Sure! A decorator is basically a function that wraps another
             function to add extra behaviour — like logging or auth checks.
             Have you ever used one in a real project?

Candidate: Yes, I've used @login_required in Django to protect views...

System detects: repeat = false
→ Evaluates answer as STRONG
→ followup_count becomes 1
→ Appended to chat_history
```