# Technical Document Speech Processing Pipeline Improvement

# AI Mock Interview – Speech Processing Pipeline Improvement

## 1\. Overview

### Problem Statement

In the current AI Mock Interview system, the voice processing pipeline occasionally behaves incorrectly when background noise is present.

Examples of problematic sounds:

- Fan noise
- Air conditioner noise
- Keyboard typing
- Breathing sounds
- Static microphone noise
- Background TV/audio
- Silent periods

Currently, these sounds may be incorrectly interpreted as real user speech.

Because the Speech-to-Text (STT) engine attempts to convert any incoming audio into text, it may generate incorrect or hallucinated transcripts such as:

- "Thank you for watching"
- "Please subscribe"
- "Hola amigo"
- Random foreign-language text
- "you"
- "oh"

This creates several interview flow issues:

- AI assumes the user has spoken
- Interview gets interrupted unexpectedly
- Backend LLM receives invalid input
- AI responds to noise instead of the user
- Natural interview experience breaks

---

## 2\. Objective

The goal is to build a robust speech validation pipeline that ensures:

- Only real human speech reaches the AI backend
- Background noise is ignored
- Fake STT hallucinations are blocked
- AI does not interrupt unnecessarily
- Interview flow feels natural and stable
- English-only interview policy is maintained
- Higher transcription accuracy for interview answers

---

## 3\. Current Architecture (Problematic Flow)

### Current Flow

User Microphone  
↓  
LiveKit Audio Stream  
↓  
Speech-to-Text (STT)  
↓  
Transcript sent directly to Backend  
↓  
LLM Processing  
↓  
AI Response

### Problem in Current Flow

The STT engine receives all audio, including invalid sounds.

Example:

Background fan noise:

ffffffffffff

STT may hallucinate:

"Thank you for watching"

System assumes:

User spoke

AI responds incorrectly.

### Root Cause

No validation layer exists before speech reaches the STT engine.

---

## 4\. Proposed Solution Architecture

A multi-stage validation pipeline is introduced.

### Improved Flow

User Microphone  
↓  
Audio Preprocessing  
↓  
Voice Activity Detection (VAD)  
↓  
Speech-to-Text (STT)  
↓  
Transcript Validation Layer  
↓  
Turn Completion Detection  
↓  
Backend LLM  
↓  
Text-to-Speech (TTS) Response

---

# 5\. Component-by-Component Explanation

## 5.1 Audio Preprocessing Layer

### Purpose

Clean raw microphone input before any speech detection.

Microphones capture:

- User speech
- Room noise
- Echo
- Keyboard clicks
- Fan sounds
- Static noise

Raw audio quality directly affects transcription accuracy.

### Functionality

Apply:

- Noise suppression
- Echo cancellation
- Automatic gain control
- Static reduction

### Example

Raw Input:

Fan noise + User speech + Room echo

Processed Output:

Cleaner speech signal

### Browser Configuration Example

```javascript
audio: {
  echoCancellation: true,
  noiseSuppression: true,
  autoGainControl: true
}
```

### Expected Outcome

Reduces invalid audio reaching downstream systems.

---

## 5.2 Voice Activity Detection (VAD)

### Purpose

Determine whether incoming audio contains actual human speech.

This is the most critical layer.

### Why Needed

Without VAD:

Any sound reaches STT.

Examples:

- Fan noise
- Breathing
- Keyboard clicks
- Chair movement
- TV audio

These may trigger false transcripts.

### Behavior

Fan Noise:

ffffffff

Decision:

Reject

Real Speech:

"Tell me about FastAPI"

Decision:

Accept

### Recommended Technologies

Options:

- Silero VAD
- WebRTC VAD
- LiveKit Built-in VAD

### Preferred Option

Silero VAD

Reasons:

- Lightweight
- Fast
- Reliable
- Optimized for real-time speech detection

### Expected Outcome

Only actual human speech proceeds to STT.

---

## 5.3 Speech-to-Text (STT) Layer

### Purpose

Convert validated speech audio into text.

### STT Providers Evaluated

- OpenAI Whisper
- Deepgram Nova-2
- AssemblyAI
- Google Streaming STT

### Initial Provider

OpenAI Whisper (gpt-4o-mini-transcribe)

### Observed Issues with Whisper

Whisper is multilingual by design.

Even when configured with:

```python
language="en"
```

it may still:

- Detect other languages
- Generate hallucinated transcripts
- Produce inaccurate results from background noise

Reason:

The language parameter acts as a hint rather than a strict language lock.

### Deepgram Nova-2 Evaluation

To improve speech recognition quality, testing was performed using Deepgram Nova-2.

### Results

Compared to Whisper:

- Achieved noticeably better transcription accuracy
- Reduced hallucinated transcripts
- Better recognition of spoken English
- Improved handling of real interview responses
- More stable real-time performance
- Faster response times during microphone testing

### Conclusion

Based on testing, Deepgram Nova-2 provided significantly better speech-to-text performance for the mock interview use case and is currently the preferred STT solution.

### Expected Outcome

Audio:

"Explain machine learning"

Transcript:

"Explain machine learning"

---

## 5.4 Transcript Validation Layer

### Purpose

Filter invalid or suspicious transcripts before backend processing.

Even after VAD and STT, occasional false transcripts may occur.

### Validation Rules

### Rule 1: Empty Input Rejection

Reject:

- Empty transcripts
- Whitespace-only transcripts

### Rule 2: Hallucination Phrase Filtering

Block known false outputs:

Examples:

- Thank you for watching
- Please subscribe
- Subtitles by
- you you you
- oh oh

### Rule 3: Confidence Threshold

Reject low-confidence transcripts.

Example:

Confidence < 0.75

### Rule 4: Minimum Speech Length

Reject accidental triggers.

Example:

Audio duration < 300–500 ms

### Rule 5: English-Only Validation

Accept:

- Explain Python decorators

Reject:

- Hola amigo
- Bonjour
- 你好

### Rule 6: Technical Vocabulary Override

Technical interviews contain domain-specific terms:

Examples:

- React
- FastAPI
- Docker
- SQL
- LangChain
- TensorFlow
- Kubernetes
- PostgreSQL

If strong technical vocabulary is detected:

Accept transcript.

### Expected Outcome

Only meaningful interview responses reach the backend.

---

## 5.5 Turn Completion Detection

### Purpose

Determine when the user has finished speaking.

### Problem Without This

User says:

"Python is used for..."

Short pause

AI may interrupt before the answer is complete.

### Solution

Wait for silence timeout.

Recommended timeout:

1.5–2 seconds

### Behavior

If silence exceeds threshold:

User finished speaking

Proceed to AI processing.

### Expected Outcome

- Natural conversation flow
- No mid-sentence interruption
- Better interview experience

---

## 5.6 Backend LLM Processing

Only validated transcripts reach the LLM.

### Accepted Examples

- What is overfitting?
- Explain transformers
- Difference between SQL and NoSQL
- What are Python decorators?

### Blocked Examples

- Thank you for watching
- Hola amigo
- Random hallucinated phrases
- Noise-generated transcripts

### Expected Outcome

Backend receives only relevant interview answers.

---

## 5.7 Text-to-Speech (TTS) Layer

### Purpose

Convert AI-generated responses back into speech.

### Flow

LLM Response  
↓  
TTS Engine  
↓  
Audio Response to User

### Expected Outcome

Natural conversational interview experience.

---

# 6\. Final System Flow

User Microphone  
↓  
Audio Preprocessing  
↓  
Voice Activity Detection (VAD)  
↓  
Speech Valid?

NO → Discard

YES → Continue

↓  
Speech-to-Text (Deepgram Nova-2)  
↓  
Transcript Validation  
↓  
Transcript Valid?

NO → Discard

YES → Continue

↓  
Turn Completion Detection  
↓  
Backend LLM  
↓  
TTS Response

---

# 7\. Models Currently Used in the Project

### 1\. Silero VAD

Purpose:

Voice Activity Detection

Responsibilities:

- Detect speech start
- Detect speech end
- Filter non-speech audio

### 2\. Deepgram Nova-2

Purpose:

Speech-to-Text

Responsibilities:

- Convert speech into text
- Improve transcription accuracy
- Reduce hallucinations
- Provide better real-time interview transcription

### 3\. OpenAI GPT Model

Purpose:

Interview intelligence

Responsibilities:

- Understand candidate answers
- Generate follow-up questions
- Evaluate responses

### 4\. OpenAI TTS (gpt-4o-mini-tts)

Voice:

Onyx

Purpose:

Convert AI responses into natural speech

Responsibilities:

- Generate professional AI interviewer voice
- Deliver responses naturally to users

---

# 8\. Expected Benefits

After implementing the proposed pipeline:

- Reduced false speech detections
- Improved speech recognition accuracy
- Better English-only enforcement
- Fewer hallucinated transcripts
- More natural interview conversations
- Reduced backend processing of invalid inputs
- Improved user experience
- More reliable AI interviewer behavior
- Higher transcription quality using Deepgram Nova-2

**Model changed**

**Deepgram nova 2 general**

Deepgram currently gives **$200 free credits** when you sign up, and those credits can be used with **Nova-2**, **Nova-3**, streaming STT, batch transcription, TTS, and other public models. No credit card is required to start.

For **Nova-2**, pricing is approximately **$0.0043 per minute** for pre-recorded transcription.

That means your $200 credit is roughly enough for:

- **≈ 46,500 minutes** of pre-recorded transcription
- **≈ 775 hours** of transcription
- **≈ 32 days of continuous audio processing**

For real-time streaming models, the number of hours will be lower because streaming costs more than batch transcription.

For your **AI Mock Interview** project, where users speak answers for a few minutes per session, the $200 free credit is typically enough to run a prototype and test with many users before incurring any cost.