# Case Study: Building an AI-Powered Mock Interview Platform

## _Bridging the Technical Assessment Gap with Real-Time Text, Voice, and Video Intelligence_

> **Project Name**: AI Mock Interview System  
> **Target Audience**: Technical Recruiters, Engineering Leaders, and Candidates  
> **Key Metrics**: < 1.5s Voice Response Latency · 100% Session Uptime via Dual-LLM Resilience · Real-Time Performance Analytics  
> **Author / Developer**: AI Engineering Team

---

## Executive Summary

Modern technical recruiting is bottlenecked by the high cost of human-led interviews, inconsistencies in evaluation, and candidate anxiety. Conversely, candidates struggle to access realistic, context-aware preparation environments.

To solve this, we engineered the **AI Mock Interview System**—a premium, full-stack, voice- and text-capable mock interview platform. The system ingests resumes and job descriptions (JDs), processes them through a background text-extraction pipeline, and uses an adaptive **6-step LLM decision engine** to conduct natural, personalized, and difficulty-calibrated technical interviews. With WebRTC-based voice mode (via **LiveKit Agents**), low-overhead chunked video recording, and a dynamic dashboard with analytics charts, the platform simulates a real technical interview, producing rich evaluations at a fraction of the cost.

```mermaid
graph TD
    A[Candidate: Resume + JD Upload] -->|Parses PDF/DOCX| B[Backend API: FastAPI]
    B -->|Structured Data Extraction| C[(Redis Session Store)]
    C -->|Topic Selection & Difficulty| D[Adaptive 6-Step Decision Engine]
    D -->|SSE Text Stream / WebRTC Voice| E[Interactive Interview Room]
    E -->|Answer Submission| D
    E -->|Chunked WebM Uploads| F[Video Service: FFmpeg Merge]
    E -->|Complete Session| G[Evaluation Engine]
    G -->|Multi-Metric Scoring| H[Analytics Dashboard]
```

---

## The Challenge

Mock interviews are traditionally hard to scale, expensive, and subjective. Existing solutions suffer from:

1.  **Generic Questions**: Many online systems ask static questions from a database, failing to probe the candidate’s specific experience (e.g., projects from their resume).
2.  **High Interaction Latency**: Standard LLM APIs introduce significant latency, disrupting the natural conversational flow necessary for voice-based practice.
3.  **Fragile AI Operations**: Real-time mock interviews are highly sensitive to LLM rate limits and API downtime; a single failed API call can ruin an ongoing interview session.
4.  **Heavy Video Overhead**: Uploading a single 20-minute high-definition video recording at the end of an interview frequently fails due to network instability or browser timeouts.

---

## The Architecture & Solution

We developed a high-throughput, low-latency, and resilient web application. Here is a breakdown of our architectural choices:

### 1\. Technology Stack

| Layer | Technologies | Role in System |
| --- | --- | --- |
| **Frontend** | React 18, TypeScript, Vite, Tailwind CSS, shadcn/ui, Recharts | Deliver a premium, responsive, glassmorphic UI with dynamic dashboard visualization and low-latency WebRTC streams. |
| **Backend** | FastAPI, Python 3.12, Uvicorn, SQLite3 | Perform high-speed asynchronous REST API orchestration, session management, and background media transcoding. |
| **AI Orchestration** | LangChain LCEL, Google Gemini 2.5 Flash, Groq Llama 3.3 70B | Orchestrate prompt chains, handle resume intelligence extraction, run primary LLM queries, and handle failover. |
| **Voice Engine** | LiveKit Cloud & Agents SDK, OpenAI STT/TTS, Silero VAD | Power full-duplex, low-latency voice-to-voice interview rooms with advanced silence/endpointing detection. |
| **Session Cache** | Redis 7 | Hold transient session states, interview history, topic queues, and video upload locks. |
| **Media Processing** | FFmpeg, WebM Recorder, Python Threading | Capture raw WebM segments from the browser, perform background stitching, and transcode to MP4 format. |

---

## Deep Dives into Core Innovations

### 1\. The Adaptive 6-Step Question Engine

Instead of linear question sequences, our platform implements a stateful, adaptive interview flow. The engine operates on a 6-step loop for every student response:

1.  **Clarification Detection**: Parses the input for repeat or clarification intents (e.g., _"Could you rephrase that?"_). If found, the engine drops difficulty and rephrases the last question.
2.  **Answer Classification**: Evaluates the candidate's response and labels it: `STRONG`, `PARTIAL`, `WEAK`, or `BLANK`.
3.  **Difficulty Calibration**: Dynamically adjusts question complexity. A series of `STRONG` answers increases difficulty, while `WEAK` or `BLANK` responses trigger a simpler follow-up.
4.  **Follow-Up vs. Topic Switch**: Decides whether to drill deeper (follow-up) or pivot topics.
5.  **Resume & JD Integration**: If switching topics, it reads the parsed resume schema (skills, projects) and the target Job Description to pick a relevant technical domain.
6.  **Question Generation**: Synthesizes the next prompt in natural language, streaming it token-by-token using **Server-Sent Events (SSE)**.