# 01 - Project Documentation

> **Version**: 1.0.0  
> **Last Updated**: February 2026  
> **Stack**: FastAPI · React · LangChain · Google Gemini · Groq

---

## **Table of Contents**

1.  [Project Overview](https://file+.vscode-resource.vscode-cdn.net/home/root495/Inexture/mock_interview/documents/PROJECT_DOCUMENTATION.md#1-project-overview)
2.  [Architecture Overview](https://file+.vscode-resource.vscode-cdn.net/home/root495/Inexture/mock_interview/documents/PROJECT_DOCUMENTATION.md#2-architecture-overview)
3.  [Tech Stack](https://file+.vscode-resource.vscode-cdn.net/home/root495/Inexture/mock_interview/documents/PROJECT_DOCUMENTATION.md#3-tech-stack)
4.  [Project Structure](https://file+.vscode-resource.vscode-cdn.net/home/root495/Inexture/mock_interview/documents/PROJECT_DOCUMENTATION.md#4-project-structure)
5.  [Backend — Detailed Reference](https://file+.vscode-resource.vscode-cdn.net/home/root495/Inexture/mock_interview/documents/PROJECT_DOCUMENTATION.md#5-backend--detailed-reference)
    - [Entry Point](https://file+.vscode-resource.vscode-cdn.net/home/root495/Inexture/mock_interview/documents/PROJECT_DOCUMENTATION.md#51-entry-point)
    - [API Layer](https://file+.vscode-resource.vscode-cdn.net/home/root495/Inexture/mock_interview/documents/PROJECT_DOCUMENTATION.md#52-api-layer)
    - [AI Layer](https://file+.vscode-resource.vscode-cdn.net/home/root495/Inexture/mock_interview/documents/PROJECT_DOCUMENTATION.md#53-ai-layer)
    - [Helper Utilities](https://file+.vscode-resource.vscode-cdn.net/home/root495/Inexture/mock_interview/documents/PROJECT_DOCUMENTATION.md#54-helper-utilities)
    - [Core / Config](https://file+.vscode-resource.vscode-cdn.net/home/root495/Inexture/mock_interview/documents/PROJECT_DOCUMENTATION.md#55-core--config)
6.  [Frontend — Detailed Reference](https://file+.vscode-resource.vscode-cdn.net/home/root495/Inexture/mock_interview/documents/PROJECT_DOCUMENTATION.md#6-frontend--detailed-reference)
7.  [Data Flow & Session Lifecycle](https://file+.vscode-resource.vscode-cdn.net/home/root495/Inexture/mock_interview/documents/PROJECT_DOCUMENTATION.md#7-data-flow--session-lifecycle)
8.  [LLM Strategy — Primary & Fallback](https://file+.vscode-resource.vscode-cdn.net/home/root495/Inexture/mock_interview/documents/PROJECT_DOCUMENTATION.md#8-llm-strategy--primary--fallback)
9.  [API Reference](https://file+.vscode-resource.vscode-cdn.net/home/root495/Inexture/mock_interview/documents/PROJECT_DOCUMENTATION.md#9-api-reference)
10. [Environment Variables](https://file+.vscode-resource.vscode-cdn.net/home/root495/Inexture/mock_interview/documents/PROJECT_DOCUMENTATION.md#10-environment-variables)
11. [Setup & Running Locally](https://file+.vscode-resource.vscode-cdn.net/home/root495/Inexture/mock_interview/documents/PROJECT_DOCUMENTATION.md#11-setup--running-locally)
12. [Testing](https://file+.vscode-resource.vscode-cdn.net/home/root495/Inexture/mock_interview/documents/PROJECT_DOCUMENTATION.md#12-testing)
13. [Known Limitations & Future Improvements](https://file+.vscode-resource.vscode-cdn.net/home/root495/Inexture/mock_interview/documents/PROJECT_DOCUMENTATION.md#13-known-limitations--future-improvements)

---

## **1\. Project Overview**

The **AI Mock Interview System** is a full-stack web application that conducts AI-powered technical mock interviews. Candidates upload their resume, specify their target job role and years of experience, and the system:

1.  Extracts structured data from the resume (skills, projects, work experience, education, certifications).
2.  Generates contextual, difficulty-calibrated interview questions using a large language model.
3.  Adapts each follow-up question based on the candidate's previous answer.
4.  Produces a comprehensive evaluation report at the end of the session.

The system is designed to simulate a real technical interview experience, with real-time token streaming for a natural "typing" effect.

---

## **2\. Architecture Overview**

```
┌─────────────────────────────────────────────────────────────┐
│                        Browser (React)                       │
│  Pages: Index · NewSession · Interview · VoiceInterview      │
└────────────────────────┬────────────────────────────────────┘
                         │ HTTP / SSE (text/event-stream)
                         ▼
┌─────────────────────────────────────────────────────────────┐
│                  FastAPI Backend (Python)                     │
│                                                              │
│  routes.py  →  services.py  →  chain.py  →  LLM Clients     │
│                     │                                        │
│              InterviewState                                  │
│           (in-memory session store)                          │
└──────────────────────┬──────────────────────────────────────┘
                       │
          ┌────────────┴────────────┐
          ▼                         ▼
┌──────────────────┐     ┌──────────────────────┐
│  Google Gemini   │     │    Groq (Llama 3.3)  │
│  gemini-2.5-flash│     │  llama-3.3-70b-vers. │
│  (Primary LLM)   │     │  (Fallback LLM)      │
└──────────────────┘     └──────────────────────┘
```

**Communication patterns:**

- Standard endpoints (`/start`, `/answer`, `/end`) → JSON over HTTP
- Streaming endpoint (`/answer/stream`) → Server-Sent Events (SSE)

---

## **3\. Tech Stack**

### **Backend**

| Component | Technology | Version |
| --- | --- | --- |
| Web framework | FastAPI | latest |
| ASGI server | Uvicorn | latest |
| LLM orchestration | LangChain | 0.3.9 |
| Primary LLM SDK | google-genai | latest |
| Primary LLM model | Gemini 2.5 Flash | —   |
| Fallback LLM | langchain-groq | 0.2.1 |
| Fallback LLM model | Llama 3.3 70B Versatile | —   |
| Data validation | Pydantic + pydantic-settings | latest |
| PDF extraction | PyPDF2 | 3.0.1 |
| DOCX extraction | python-docx | 1.1.2 |
| Conversation memory | LangChain ConversationBufferMemory | —   |
| Runtime | Python | 3.12.3 |

### **Frontend**

| Component | Technology | Version |
| --- | --- | --- |
| Framework | React | 18.3.1 |
| Build tool | Vite | 5.4.19 |
| Language | TypeScript | 5.8.3 |
| Styling | Tailwind CSS | 3.4.17 |
| UI components | Radix UI + shadcn/ui | various |
| Routing | React Router DOM | 6.30.1 |
| Data fetching | TanStack Query | 5.83.0 |
| Forms | React Hook Form + Zod | latest |
| Icons | Lucide React | 0.462.0 |

---

## **4\. Project Structure**

```
mock_interview/
├── backend/
│   ├── app/
│   │   ├── main.py                    # FastAPI app entry point, CORS, router registration
│   │   ├── helper.py                  # PDF/DOCX extraction, JSON parsing utilities
│   │   ├── database.py                # (Reserved) DB connection placeholder
│   │   ├── ai/
│   │   │   ├── llm/
│   │   │   │   ├── base.py            # BaseLLM abstract interface
│   │   │   │   ├── gemini_client.py   # GeminiClient + GeminiLangChainWrapper
│   │   │   │   └── groq_client.py     # GroqClient (fallback)
│   │   │   ├── prompts/
│   │   │   │   ├── templates.py       # PromptTemplate definitions (question, eval, resume)
│   │   │   │   └── chain.py           # LCEL chain factory functions
│   │   │   └── agents/
│   │   │       └── evaluation_agent.py
│   │   ├── apis/
│   │   │   └── interview/
│   │   │       ├── routes.py          # HTTP route handlers
│   │   │       ├── services.py        # Core business logic & session management
│   │   │       ├── schemas.py         # Pydantic request/response models
│   │   │       └── dependencies.py    # FastAPI dependency injection helpers
│   │   └── core/
│   │       ├── constants.py           # App settings (loaded from .env)
│   │       └── logger.py             # Logging configuration
│   ├── tests/
│   │   └── unit/
│   │       └── test_interview_service.py
│   ├── requirements.txt
│   └── .env                           # API keys (not committed to git)
│
├── frontend/
│   ├── src/
│   │   ├── pages/
│   │   │   ├── Index.tsx              # Landing / home page
│   │   │   ├── NewSession.tsx         # Resume upload + session setup
│   │   │   ├── Interview.tsx          # Active interview UI (SSE consumer)
│   │   │   ├── VoiceInterview.tsx     # Voice-based interview variant
│   │   │   └── NotFound.tsx           # 404 page
│   │   ├── components/                # Reusable UI components (shadcn/ui based)
│   │   ├── hooks/                     # Custom React hooks
│   │   ├── lib/                       # Utility functions
│   │   └── App.tsx                    # Root component + routing
│   ├── package.json
│   └── vite.config.ts
│
└── documents/
    └── PROJECT_DOCUMENTATION.md       # This file
```

---

## **5\. Backend — Detailed Reference**

### **5.1 Entry Point**

`app/main.py`

- Creates the `FastAPI` application instance with title `"AI Mock Interview API"` and version `1.0.0`.
- Registers **CORS middleware** (currently allows all origins — restrict in production).
- Mounts the interview router at prefix `/api/v1/interview`.
- Exposes a `GET /health` endpoint returning `{"status": "healthy"}`.
- Logs a startup message via the app-wide logger.

---

### **5.2 API Layer**

#### `app/apis/interview/routes.py`

Defines four HTTP endpoints. All delegate to the module-level `InterviewService` singleton.

| Endpoint | Method | Body | Response |
| --- | --- | --- | --- |
| `/api/v1/interview/start` | POST | `multipart/form-data` (resume file + job_role + experience) | `InterviewStartResponse` |
| `/api/v1/interview/answer` | POST | JSON `AnswerRequest` | `InterviewResponse` |
| `/api/v1/interview/answer/stream` | POST | JSON `AnswerRequest` | `StreamingResponse` (SSE) |
| `/api/v1/interview/end` | POST | Query param `session_id` | `EvaluationResponse` |

**Error mapping:**

- `ValueError` → HTTP 404 (unknown session)
- All other exceptions → HTTP 500

#### `app/apis/interview/schemas.py`

Pydantic models for request validation and response serialisation:

| Class | Direction | Fields |
| --- | --- | --- |
| `AnswerRequest` | Request | `session_id: str`, `answer: str` |
| `InterviewStartResponse` | Response | `session_id`, `message`, `first_question` |
| `InterviewResponse` | Response | `session_id`, `current_question`, `status` |
| `EvaluationResponse` | Response | `session_id`, `evaluation` |
| `ErrorResponse` | Response | `detail: str` |

#### `app/apis/interview/services.py`

The core business logic class. Key components:

`InterviewState` — per-session data container:

- `session_id`, `resume_text`, `job_role`, `experience`
- `extracted_resume_data` — structured JSON from resume extraction
- `question_chain` — LCEL chain for question generation
- `memory` — `ConversationBufferMemory` for full conversation context
- `chat_history` — list of `(question, answer)` tuples for evaluation
- `current_question` — the question currently awaiting an answer
- `switch_topic` — boolean flag (one-turn-behind) controlling topic switching

`InterviewService` — service class methods:

| Method | Purpose |
| --- | --- |
| `start_interview(resume_text, job_role, experience)` | Creates session, extracts resume data, returns first question |
| `process_answer(session_id, answer)` | Synchronous: appends Q/A, generates next question |
| `process_answer_stream(session_id, answer)` | Generator: streams next question as SSE tokens |
| `evaluate_interview(session_id)` | Evaluates full conversation, deletes session |

`active_interviews` — module-level dict `{session_id: InterviewState}`. Replace with Redis for production.

#### `app/apis/interview/dependencies.py`

Provides `get_interview_service()` — a FastAPI dependency function that returns a fresh `InterviewService` instance. Currently not wired into routes (routes use a singleton), but ready to use with `Depends(get_interview_service)` for better testability.

---

### **5.3 AI Layer**

#### **LLM Clients (**`app/ai/llm/`**)**

`base.py` **—** `BaseLLM` **(Abstract)**

Defines the interface all LLM clients must implement:

- `generate(prompt: str, **kwargs) -> str` — single-turn text generation
- `get_llm_instance()` — returns the underlying LangChain `BaseChatModel`

`gemini_client.py` **—** `GeminiClient` **(Primary)**

- Uses the official `google-genai` SDK (`google.genai`).
- Model: `gemini-2.5-flash`.
- `GeminiLangChainWrapper` — custom `BaseChatModel` subclass that bridges the SDK to LangChain.
- Supports both blocking (`_generate`) and streaming (`stream_prompt`) generation.
- Module-level `_client` singleton avoids per-request cold starts.

`groq_client.py` **—** `GroqClient` **(Fallback)**

- Uses LangChain's native `ChatGroq` integration.
- Model: `llama-3.3-70b-versatile`.
- `temperature=0` for deterministic, consistent output.

#### **Prompts (**`app/ai/prompts/`**)**

`templates.py` — Three `PromptTemplate` definitions:

| Template | Variables | Output |
| --- | --- | --- |
| `interview_question_template` | `chat_history`, `resume_data`, `experience`, `job_role` | JSON `{"switch_topic": bool, "question": str}` |
| `evaluation_template` | `conversation` | Structured text with Q/A/Feedback + 5 category scores |
| `resume_extraction_system_prompt` | `resume_text` | JSON with Projects, Skills, Work Experience, Education, Certifications |

`chain.py` — LCEL chain factory functions:

| Function | Chain | Used by |
| --- | --- | --- |
| `create_question_chain(llm)` | `interview_question_template \| llm` | `process_answer`, `process_answer_stream` |
| `create_evaluation_chain(llm)` | `evaluation_template \| llm` | `evaluate_interview` |
| `create_resume_extraction_chain(llm)` | `ChatPromptTemplate([system]) \| llm` | `start_interview` |

---

### **5.4 Helper Utilities**

`app/helper.py`

| Function | Purpose |
| --- | --- |
| `resume_text_from_pdf(file, file_type)` | Extracts plain text from PDF or DOCX uploads |
| `parse_resume_data(response_text)` | Parses LLM JSON response with 5 fallback strategies |
| `simple_resume_parser(resume_text)` | Keyword-based fallback parser (no LLM needed) |
| `balance_curly_braces(json_string)` | Fixes malformed JSON by balancing `{` and `}` |

`parse_resume_data` **fallback chain:**

1.  Direct `json.loads()`
2.  Balance braces → `json.loads()`
3.  Regex extract JSON block → `json.loads()`
4.  `simple_resume_parser()` (keyword matching)
5.  Return empty default structure

---

### **5.5 Core / Config**

`app/core/constants.py` — Loads settings from `.env` via `pydantic-settings`:

- `GOOGLE_API_KEY`
- `GROQ_API_KEY`

`app/core/logger.py` — Configures the `"mock_interview_app"` logger used across all modules.

---

## **6\. Frontend — Detailed Reference**

Built with **React 18 + TypeScript + Vite**. UI components from **shadcn/ui** (Radix UI primitives + Tailwind CSS).

### **Pages**

| Page | Route | Purpose |
| --- | --- | --- |
| `Index.tsx` | `/` | Landing page — entry point for the application |
| `NewSession.tsx` | `/new` | Resume upload form + job role / experience inputs |
| `Interview.tsx` | `/interview` | Active interview UI — displays questions, accepts answers, consumes SSE stream |
| `VoiceInterview.tsx` | `/voice` | Voice-based interview variant |
| `NotFound.tsx` | `*` | 404 fallback page |

### **Key Libraries**

- **TanStack Query** — server state management and API call caching
- **React Hook Form + Zod** — form validation with schema-based type safety
- **React Router DOM** — client-side routing
- **Lucide React** — icon set
- **Sonner** — toast notifications
- **Recharts** — charts (for evaluation score visualisation)

---

## **7\. Data Flow & Session Lifecycle**

```
1. POST /start
   ├── Upload resume (PDF/DOCX)
   ├── Extract text → resume_text_from_pdf()
   ├── LLM: extract structured data → {Projects, Skills, Work Experience, ...}
   ├── Create InterviewState (session_id, chains, memory)
   └── Return: session_id + first_question ("Tell me about your technical skills")

2. POST /answer/stream  (repeated per question)
   ├── Append (current_question, answer) to chat_history + memory
   ├── If switch_topic=True (from previous turn): inject resume_data into prompt
   ├── Stream prompt → Gemini stream_prompt() → yield SSE tokens
   │   data: {"token": "..."}\n\n  (per chunk)
   │   data: {"done": true, "question": "..."}\n\n  (final)
   ├── Parse full response JSON → extract switch_topic + next_question
   └── Update state.current_question

3. POST /end
   ├── Format chat_history as "Q: ...\nA: ..." string
   ├── LLM: evaluate_chain.invoke({conversation: ...})
   ├── Return evaluation report (per-Q feedback + 5 category scores)
   └── Delete session from active_interviews
```

---

## **8\. LLM Strategy — Primary & Fallback**

Every LLM call in `InterviewService` follows this pattern:

```
Try Gemini (primary)
    ├── Success → use result
    └── Exception → log warning
        Try Groq (fallback)
            ├── Success → use result
            └── Exception → log error
                Return FALLBACK_QUESTION / raise
```

**Streaming fallback:** If Gemini streaming fails, the system falls back to a single non-streaming Groq response, emitted as one token event + done event. The client experience degrades gracefully (no streaming animation) but the interview continues.

**Topic switching (**`switch_topic` **flag):**

- The LLM returns `{"switch_topic": true/false, "question": "..."}` on every turn.
- `switch_topic=True` means the candidate didn't know the answer / asked to skip.
- On the **next** turn, the full resume data is injected so the LLM can pick a new topic.
- This one-turn-behind design prevents the LLM from switching topics mid-answer.

---

## **9\. API Reference**

### **POST** `/api/v1/interview/start`

**Content-Type:** `multipart/form-data`

| Field | Type | Required | Description |
| --- | --- | --- | --- |
| `resume` | File | ✅   | PDF or DOCX resume |
| `job_role` | string | ✅   | Target job role (e.g. "Backend Engineer") |
| `experience` | integer | ✅   | Years of experience (0–20) |

**Response** `200`**:**

```json
{
  "session_id": "550e8400-e29b-41d4-a716-446655440000",
  "message": "Interview started successfully",
  "first_question": "Can you please tell me a bit about your technical skills?"
}
```

---

### **POST** `/api/v1/interview/answer`

**Content-Type:** `application/json`

```json
{
  "session_id": "550e8400-e29b-41d4-a716-446655440000",
  "answer": "I have 3 years of experience with Python and Django..."
}
```

**Response** `200`**:**

```json
{
  "session_id": "550e8400-e29b-41d4-a716-446655440000",
  "current_question": "Can you describe a challenging Django project you worked on?",
  "status": "in_progress"
}
```

---

### **POST** `/api/v1/interview/answer/stream`

Same request body as `/answer`. Returns `text/event-stream`.

**SSE Events:**

```
data: {"token": "Can you "}\n\n
data: {"token": "describe a "}\n\n
data: {"token": "challenging project?"}\n\n
data: {"done": true, "question": "Can you describe a challenging project?"}\n\n
```

---

### **POST** `/api/v1/interview/end`

**Query param:** `?session_id=<uuid>`

**Response** `200`**:**

```json
{
  "session_id": "550e8400-e29b-41d4-a716-446655440000",
  "evaluation": "Q1: ...\nA1: ...\nF1: ...\n\nFinal Evaluation:\n1. Technical Accuracy: 7/10..."
}
```

---

### **GET** `/health`

```json
{"status": "healthy"}
```

---

## **10\. Environment Variables**

Create `backend/.env`:

```env
GOOGLE_API_KEY=your_google_gemini_api_key_here
GROQ_API_KEY=your_groq_api_key_here
```

| Variable | Where to get |
| --- | --- |
| `GOOGLE_API_KEY` | [Google AI Studio](https://aistudio.google.com/app/apikey) |
| `GROQ_API_KEY` | [Groq Console](https://console.groq.com/keys) |

---

## **11\. Setup & Running Locally**

### **Backend**

```bash
# 1. Navigate to backend
cd backend

# 2. Create and activate virtual environment
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Create .env file (see Section 10)

# 5. Start the development server
uvicorn app.main:app --reload
```

API available at: `http://127.0.0.1:8000`  
Swagger UI: `http://127.0.0.1:8000/docs`  
ReDoc: `http://127.0.0.1:8000/redoc`

### **Frontend**

```bash
# 1. Navigate to frontend
cd frontend

# 2. Install dependencies
npm install

# 3. Start the dev server
npm run dev
```

Frontend available at: `http://localhost:5173`

---

## **12\. Testing**

### **Backend Unit Tests**

```bash
cd backend
python -m pytest tests/
```

Test file: `tests/unit/test_interview_service.py`  
Uses `unittest.mock.patch` to mock `GeminiClient` and `GroqClient`.

### **Frontend Tests**

```bash
cd frontend
npm run test
```

Uses **Vitest** + **@testing-library/react**.

---

## **13\. Known Limitations & Future Improvements**

| Area | Current State | Recommended Improvement |
| --- | --- | --- |
| Session storage | In-memory dict (`active_interviews`) | Replace with **Redis** for multi-worker support |
| CORS | `allow_origins=["*"]` | Restrict to specific frontend origin in production |
| Authentication | None | Add JWT-based auth for user accounts and session history |
| Resume formats | PDF + DOCX only | Add support for plain text, LinkedIn PDF exports |
| Question count | Unlimited | Add configurable max question limit per session |
| Evaluation format | Plain text string | Return structured JSON for richer frontend visualisation |
| Streaming fallback | Groq non-streaming | Implement Groq streaming as a true streaming fallback |
| Dependency injection | Module-level singleton | Wire `Depends(get_interview_service)` into routes |
| `requirements.txt` | Contains unused legacy deps (streamlit, chromadb, etc.) | Clean up to only include active dependencies |