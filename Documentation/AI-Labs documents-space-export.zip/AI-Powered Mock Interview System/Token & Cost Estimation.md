# Token & Cost Estimation

## **AI Mock Interview System (30-Minute Session)**

### **Overview**

This document provides a clear estimation of token usage and cost for a single 30-minute interview session, covering:

- Interview Logic (LLM)
- Speech-to-Text (STT)
- Text-to-Speech (TTS)

The goal is to give a transparent, scalable, and predictable cost model.

---

### **1\. Interview Logic (LLM)**

#### **Description**

Handles:

- Question generation
- Follow-up logic
- Context understanding

**Model Used**: OpenAI `gpt-4o-mini`

#### **Assumptions**

- ~30 questions in 30 minutes (upper bound)
- ~450–550 **Input Tokens** per interaction (System prompt, current Q/A context)
- ~100–150 **Output Tokens** per interaction (AI's generated question/response)
- Optimized prompt (bounded context, no full history growth)
- Total per interaction: ~600–700 tokens

#### **Usage Table**

| Metric | Input Tokens (Prompt) | Output Tokens (Completion) | Total Tokens |
| --- | --- | --- | --- |
| 1 Sentence (1 Q/A cycle) | ~450–550 | ~100–150 | ~600–700 |
| 1 Minute Usage | ~450–900 | ~100–250 | ~600–1,200 |
| 30 Minutes Usage | 13,500 – 16,500 | 3,000 – 4,500 | 18,000 – 21,000 |
| Pricing (`gpt-4o-mini`) | ~$0.150 / 1M tokens | ~$0.600 / 1M tokens |     |
| **Estimated Cost (30 min)** | **~$0.002 – $0.0025** | **~$0.0018 – $0.0027** | **~$0.004 – $0.0055** |

---

### **2\. Speech-to-Text (STT)**

#### **Description**

- Converts user speech to text
- Uses OpenAI Whisper
- Billing based on audio duration

#### **Assumptions**

- User speaks ~40–60% of time
- 30 min session results in 15–20 min speech

#### **Usage Table**

| Metric | Value |
| --- | --- |
| 1 Sentence (Answer) | ~15–30 sec audio |
| 1 Minute Usage | 1 min audio |
| 30 Minutes Usage | 15–20 minutes audio processed |
| Token Equivalent | ~2,500 – 5,000 tokens |
| Pricing | ~$0.006 per minute |
| Total Cost (30 min) | $0.09 – $0.12 |

---

### **3\. Text-to-Speech (TTS)**

#### **Description**

- Converts AI question to voice
- Uses OpenAI TTS
- Billing based on characters

#### **Assumptions**

- ~30 questions
- ~100–150 characters per question

#### **Usage Table**

| Metric | Value |
| --- | --- |
| 1 Sentence (Question) | ~100–150 characters |
| 1 Minute Usage | ~120–300 characters |
| 30 Minutes Usage | 3,600 – 4,000 characters |
| Token Equivalent | ~800 – 1,000 tokens |
| Pricing | ~$0.015 per 1K characters |
| Total Cost (30 min) | $0.04 – $0.06 |

---

### **4\. Combined Usage Summary**

#### **Cost Perspective (Actual Billing)**

| Component | Cost |
| --- | --- |
| STT (Whisper) | $0.09 – $0.12 |
| TTS (OpenAI) | $0.04 – $0.06 |
| LLM Input (Prompt) | ~$0.002 – $0.003 |
| LLM Output (Completion) | ~$0.002 – $0.003 |
| **Total Pipeline Cost** | **$0.134 – $0.186 per 30-min session** |

**Final Total (Full System):** ~$0.135 – $0.190 per 30-minute session

---

### **Key Insights**

1.  **LLM is the Primary Cost Driver**: ~80% of total cost comes from LLM usage.
2.  **STT Optimization**: Only processes actual speech (via VAD), reducing unnecessary cost.
3.  **Bounded Token Design**: Only recent context (last few turns) is used, meaning token usage remains constant per question.
4.  **Scalable Architecture**: Cost grows linearly, not exponentially, making it predictable for large-scale deployment.

---

### **Final Summary**

| Metric | Value |
| --- | --- |
| Session Duration | 30 minutes |
| Questions | ~30 (max) |
| Total Input Tokens | 13.5K – 16.5K |
| Total Output Tokens | 3K – 4.5K |
| Total Voice Cost (STT + TTS) | $0.13 – $0.18 |
| Total LLM Cost (In + Out) | ~$0.004 – $0.006 |
| **Total Pipeline Runtime Cost** | **$0.134 – $0.186** |
| Total Token Equivalent | 22K – 27K |