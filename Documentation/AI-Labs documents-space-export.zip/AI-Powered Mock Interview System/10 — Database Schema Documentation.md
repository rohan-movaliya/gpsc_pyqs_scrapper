# 10 — Database Schema Documentation

This document provides a comprehensive overview of the PostgreSQL database schema used by the AI Mock Interview application. The database is built on PostgreSQL and managed via SQLAlchemy 2.0 async declarative models.

---

## **1\. Database Architecture & Technology Stack**

- **RDBMS**: PostgreSQL
- **ORM**: SQLAlchemy 2.0 (Async Declarative Mapping)
- **Migrations**: Alembic
- **Primary Keys**: UUID (v4) generated on-client/on-insert for distributed-friendly identity.
- **Timezones**: UTC-aware timestamps (`DateTime(timezone=True)`) default to server-side `CURRENT_TIMESTAMP`.

---

## **2\. Entity-Relationship Diagram (ERD)**

The following Mermaid diagram shows the complete entity relationships across all 14 tables in the system.

```mermaid
erDiagram
    users ||--o{ resumes : "has"
    users ||--o{ job_descriptions : "has"
    users ||--o{ interview_sessions : "performs"
    users ||--o{ user_sessions : "authenticates"
    users ||--o{ email_verification_tokens : "verifies"
    users ||--o{ password_reset_tokens : "resets"

    resumes ||--o{ interview_sessions : "referenced-by"
    job_descriptions ||--o{ interview_sessions : "referenced-by"

    interview_sessions ||--o{ interview_questions : "contains"
    interview_sessions ||--o| interview_evaluations : "evaluates"
    interview_sessions ||--o| speech_analytics : "analyzes"
    interview_sessions ||--o| video_recordings : "stores"
    interview_sessions ||--o{ improvement_suggestions : "suggests"
    interview_sessions ||--o{ skill_scores : "scores"
    interview_sessions ||--o{ interview_sessions : "retakes (self-ref)"

    interview_questions ||--o| interview_answers : "answered-by"
```

---

## **3\. Core Database Tables & Fields**

### **3.1** `users`

Stores user profile information, authentication hashes, role definitions, and OAuth provider linkages.

| Column | Data Type (PostgreSQL) | Constraints | Default | Description |
| --- | --- | --- | --- | --- |
| `id` | `UUID` | `PRIMARY KEY` | `uuid_generate_v4()` | Unique user identifier |
| `full_name` | `VARCHAR(255)` | `NOT NULL` | \-  | User's full name |
| `email` | `VARCHAR(255)` | `UNIQUE, NOT NULL, INDEX` | \-  | User's email (login credential) |
| `password_hash` | `TEXT` | `NOT NULL` | \-  | Hashed password |
| `is_verified` | `BOOLEAN` | `NOT NULL` | `FALSE` | Email verification flag |
| `is_active` | `BOOLEAN` | `NOT NULL` | `TRUE` | Soft-disable / activation flag |
| `last_login` | `TIMESTAMPTZ` | `NULL` | \-  | Timestamp of last successful login |
| `experience` | `INTEGER` | `NULL` | \-  | Years of work experience |
| `target_role` | `VARCHAR(255)` | `NULL` | \-  | Desired career role |
| `role` | `VARCHAR(20)` | `NOT NULL` | `'candidate'` | User role (e.g. `'candidate'`, `'admin'`) |
| `deleted_at` | `TIMESTAMPTZ` | `NULL` | \-  | Soft delete timestamp |
| `created_by` | `UUID` | `NULL` | \-  | Auditing: Creator ID |
| `updated_by` | `UUID` | `NULL` | \-  | Auditing: Updater ID |
| `provider` | `VARCHAR(50)` | `NOT NULL` | `'local'` | Authentication provider (e.g., `'local'`, `'google'`) |
| `provider_id` | `VARCHAR(255)` | `NULL` | \-  | OAuth provider unique ID |
| `created_at` | `TIMESTAMPTZ` | `NOT NULL` | `CURRENT_TIMESTAMP` | Creation timestamp |
| `updated_at` | `TIMESTAMPTZ` | `NOT NULL` | `CURRENT_TIMESTAMP` | Last updated timestamp |

---

### **3.2** `resumes`

Stores uploaded resume documents, text extracts, and structured data parsed by AI.

| Column | Data Type (PostgreSQL) | Constraints | Default | Description |
| --- | --- | --- | --- | --- |
| `resume_id` | `UUID` | `PRIMARY KEY` | `uuid_generate_v4()` | Unique resume identifier |
| `user_id` | `UUID` | `FOREIGN KEY (users.id) ON DELETE CASCADE, NOT NULL, INDEX` | \-  | Owner ID |
| `file_name` | `VARCHAR(255)` | `NOT NULL` | \-  | Original uploaded filename |
| `file_path` | `TEXT` | `NULL` | \-  | Storage path (S3 or Local) |
| `resume_text` | `TEXT` | `NULL` | \-  | Extracted raw text |
| `extracted_json` | `JSONB` | `NULL` | \-  | Parsed entities (skills, education, etc.) |
| `uploaded_at` | `TIMESTAMPTZ` | `NOT NULL` | `CURRENT_TIMESTAMP` | Upload timestamp |

---

### **3.3** `job_descriptions`

Stores job descriptions input or uploaded by the user to tailor the mock interview questions.

| Column | Data Type (PostgreSQL) | Constraints | Default | Description |
| --- | --- | --- | --- | --- |
| `jd_id` | `UUID` | `PRIMARY KEY` | `uuid_generate_v4()` | Unique JD identifier |
| `user_id` | `UUID` | `FOREIGN KEY (users.id) ON DELETE CASCADE, NOT NULL, INDEX` | \-  | Creator ID |
| `title` | `VARCHAR(255)` | `NOT NULL` | \-  | Role title for the JD |
| `jd_text` | `TEXT` | `NULL` | \-  | Raw text of the job description |
| `file_name` | `VARCHAR(255)` | `NULL` | \-  | Uploaded filename if provided |
| `file_path` | `TEXT` | `NULL` | \-  | Path to the uploaded document |
| `uploaded_at` | `TIMESTAMPTZ` | `NOT NULL` | `CURRENT_TIMESTAMP` | Creation timestamp |

---

### **3.4** `interview_sessions`

Central coordinator mapping a candidate's mock interview. Supports retaking past sessions.

| Column | Data Type (PostgreSQL) | Constraints | Default | Description |
| --- | --- | --- | --- | --- |
| `session_id` | `UUID` | `PRIMARY KEY` | `uuid_generate_v4()` | Unique session identifier |
| `user_id` | `UUID` | `FOREIGN KEY (users.id) ON DELETE CASCADE, NOT NULL, INDEX` | \-  | Candidate ID |
| `resume_id` | `UUID` | `FOREIGN KEY (resumes.resume_id) ON DELETE SET NULL, NULL` | \-  | Resume used in session |
| `jd_id` | `UUID` | `FOREIGN KEY (job_descriptions.jd_id) ON DELETE SET NULL, NULL` | \-  | Job Description used in session |
| `job_role` | `VARCHAR(100)` | `NOT NULL` | \-  | Target job role for interview |
| `experience_years` | `INTEGER` | `NOT NULL` | \-  | Target experience level in years |
| `interview_mode` | `VARCHAR(20)` | `NOT NULL` | `'text'` | Modality: `'text'` or `'voice'` |
| `status` | `VARCHAR(20)` | `NOT NULL` | `'pending'` | Lifecycle: `'pending'`, `'in_progress'`, `'completed'`, `'failed'` |
| `start_time` | `TIMESTAMPTZ` | `NULL` | \-  | Interview start time |
| `end_time` | `TIMESTAMPTZ` | `NULL` | \-  | Interview completion/abort time |
| `is_retake` | `BOOLEAN` | `NOT NULL` | `FALSE` | Retake flag |
| `parent_session_id` | `UUID` | `FOREIGN KEY (interview_sessions.session_id) ON DELETE SET NULL, NULL` | \-  | Original session ID (if retake) |
| `created_at` | `TIMESTAMPTZ` | `NOT NULL` | `CURRENT_TIMESTAMP` | Creation timestamp |

---

### **3.5** `interview_questions`

Logs questions generated and posed to the candidate during a session.

| Column | Data Type (PostgreSQL) | Constraints | Default | Description |
| --- | --- | --- | --- | --- |
| `question_id` | `UUID` | `PRIMARY KEY` | `uuid_generate_v4()` | Unique question identifier |
| `session_id` | `UUID` | `FOREIGN KEY (interview_sessions.session_id) ON DELETE CASCADE, NOT NULL` | \-  | Parent interview session |
| `question_text` | `TEXT` | `NOT NULL` | \-  | Generated question text |
| `topic` | `VARCHAR(255)` | `NULL` | \-  | Focus topic (e.g. `'React'`, `'System Design'`) |
| `difficulty_level` | `VARCHAR(20)` | `NULL` | \-  | Difficulty rating (e.g. `'easy'`, `'hard'`) |
| `question_order` | `INTEGER` | `NULL` | \-  | Order sequence in the interview |
| `created_at` | `TIMESTAMPTZ` | `NOT NULL` | `CURRENT_TIMESTAMP` | Creation timestamp |

---

### **3.6** `interview_answers`

Stores candidate answers, duration, and individual question feedback.

| Column | Data Type (PostgreSQL) | Constraints | Default | Description |
| --- | --- | --- | --- | --- |
| `answer_id` | `UUID` | `PRIMARY KEY` | `uuid_generate_v4()` | Unique answer identifier |
| `question_id` | `UUID` | `FOREIGN KEY (interview_questions.question_id) ON DELETE CASCADE, UNIQUE, NOT NULL` | \-  | Related question |
| `answer_text` | `TEXT` | `NOT NULL` | \-  | User's transcripts/submitted answers |
| `response_duration_seconds` | `INTEGER` | `NOT NULL` | `0` | Time taken to answer in seconds |
| `feedback` | `TEXT` | `NULL` | \-  | Question-specific AI feedback |
| `created_at` | `TIMESTAMPTZ` | `NOT NULL` | `CURRENT_TIMESTAMP` | Response timestamp |

---

### **3.7** `interview_evaluations`

Stores comprehensive aggregate evaluation scores and AI summaries of an completed interview session.

| Column | Data Type (PostgreSQL) | Constraints | Default | Description |
| --- | --- | --- | --- | --- |
| `evaluation_id` | `UUID` | `PRIMARY KEY` | `uuid_generate_v4()` | Unique evaluation identifier |
| `session_id` | `UUID` | `FOREIGN KEY (interview_sessions.session_id) ON DELETE CASCADE, UNIQUE, NOT NULL` | \-  | Associated session |
| `overall_score` | `NUMERIC(5, 2)` | `NOT NULL` | \-  | Overall score (out of 100) |
| `technical_score` | `NUMERIC(5, 2)` | `NOT NULL` | \-  | Technical performance score |
| `communication_score` | `NUMERIC(5, 2)` | `NOT NULL` | \-  | Communication quality score |
| `problem_solving_score` | `NUMERIC(5, 2)` | `NOT NULL` | \-  | Logical reasoning and problem-solving |
| `confidence_score` | `NUMERIC(5, 2)` | `NOT NULL` | \-  | Estimated candidate confidence score |
| `behavioral_score` | `NUMERIC(5, 2)` | `NOT NULL` | \-  | Soft skills/behavioral score |
| `feedback` | `TEXT` | `NULL` | \-  | Detailed qualitative analysis |
| `strengths` | `TEXT[]` | `NOT NULL` | `ARRAY[]` | List of candidate strengths |
| `improvements` | `TEXT[]` | `NOT NULL` | `ARRAY[]` | List of target areas for improvement |
| `created_at` | `TIMESTAMPTZ` | `NOT NULL` | `CURRENT_TIMESTAMP` | Evaluation timestamp |

---

### **3.8** `skill_scores`

Individual breakdown of specific skill matches evaluated during the session.

| Column | Data Type (PostgreSQL) | Constraints | Default | Description |
| --- | --- | --- | --- | --- |
| `skill_score_id` | `UUID` | `PRIMARY KEY` | `uuid_generate_v4()` | Unique skill score identifier |
| `session_id` | `UUID` | `FOREIGN KEY (interview_sessions.session_id) ON DELETE CASCADE, NOT NULL` | \-  | Associated session |
| `skill_name` | `VARCHAR(100)` | `NOT NULL` | \-  | Analyzed skill (e.g. `'Python'`, `'SQL'`) |
| `score` | `NUMERIC(5, 2)` | `NOT NULL` | \-  | Calculated score (out of 100) |

---

### **3.9** `speech_analytics`

Quantitative and qualitative audio speech metrics for voice interviews.

| Column | Data Type (PostgreSQL) | Constraints | Default | Description |
| --- | --- | --- | --- | --- |
| `speech_id` | `UUID` | `PRIMARY KEY` | `uuid_generate_v4()` | Unique speech analytics identifier |
| `session_id` | `UUID` | `FOREIGN KEY (interview_sessions.session_id) ON DELETE CASCADE, UNIQUE, NOT NULL` | \-  | Associated session |
| `words_per_minute` | `NUMERIC(8, 2)` | `NOT NULL` | \-  | Candidate speaking pace |
| `filler_word_count` | `INTEGER` | `NOT NULL` | `0` | Number of filler words (e.g. `'um'`, `'like'`) |
| `pause_count` | `INTEGER` | `NOT NULL` | `0` | Significant/awkward pauses |
| `speech_clarity_score` | `NUMERIC(5, 2)` | `NOT NULL` | \-  | Pronunciation/clarity score |
| `average_answer_duration` | `NUMERIC(8, 2)` | `NOT NULL` | \-  | Average answer length in seconds |
| `created_at` | `TIMESTAMPTZ` | `NOT NULL` | `CURRENT_TIMESTAMP` | Record timestamp |

---

### **3.10** `video_recordings`

Reference to raw video uploads/merged videos capturing candidate webcam feeds.

| Column | Data Type (PostgreSQL) | Constraints | Default | Description |
| --- | --- | --- | --- | --- |
| `video_id` | `UUID` | `PRIMARY KEY` | `uuid_generate_v4()` | Unique recording identifier |
| `session_id` | `UUID` | `FOREIGN KEY (interview_sessions.session_id) ON DELETE CASCADE, UNIQUE, NOT NULL` | \-  | Associated session |
| `file_path` | `TEXT` | `NOT NULL` | \-  | Local file path or cloud bucket URI |
| `duration_seconds` | `INTEGER` | `NOT NULL` | \-  | Recording duration in seconds |
| `file_size_mb` | `NUMERIC(10, 2)` | `NOT NULL` | \-  | Video size on disk |
| `uploaded_at` | `TIMESTAMPTZ` | `NOT NULL` | `CURRENT_TIMESTAMP` | Upload completion timestamp |

---

### **3.11** `improvement_suggestions`

Actionable takeaways provided by the AI evaluator to help the candidate improve.

| Column | Data Type (PostgreSQL) | Constraints | Default | Description |
| --- | --- | --- | --- | --- |
| `suggestion_id` | `UUID` | `PRIMARY KEY` | `uuid_generate_v4()` | Unique suggestion identifier |
| `session_id` | `UUID` | `FOREIGN KEY (interview_sessions.session_id) ON DELETE CASCADE, NOT NULL` | \-  | Associated session |
| `category` | `VARCHAR(100)` | `NOT NULL` | \-  | Area (e.g., `'technical'`, `'communication'`) |
| `weakness` | `TEXT` | `NOT NULL` | \-  | Identified weakness |
| `recommendation` | `TEXT` | `NOT NULL` | \-  | Specific tip to overcome it |
| `priority` | `VARCHAR(20)` | `NOT NULL` | `'medium'` | Action priority: `'low'`, `'medium'`, `'high'` |
| `created_at` | `TIMESTAMPTZ` | `NOT NULL` | `CURRENT_TIMESTAMP` | Record timestamp |

---

### **3.12** `user_sessions`

Manages JWT Refresh token rotation, expiry, and device fingerprints for active logins.

| Column | Data Type (PostgreSQL) | Constraints | Default | Description |
| --- | --- | --- | --- | --- |
| `id` | `UUID` | `PRIMARY KEY` | `uuid_generate_v4()` | Session token identifier |
| `user_id` | `UUID` | `FOREIGN KEY (users.id) ON DELETE CASCADE, NOT NULL, INDEX` | \-  | Reference to the logged-in user |
| `refresh_token_hash` | `TEXT` | `NOT NULL` | \-  | Hashed token for validation checks |
| `device_info` | `TEXT` | `NULL` | \-  | User-agent description |
| `ip_address` | `VARCHAR(45)` | `NULL` | \-  | IP address of request (IPv4/IPv6 ready) |
| `expires_at` | `TIMESTAMPTZ` | `NOT NULL, INDEX` | \-  | Token expiration limit |
| `created_at` | `TIMESTAMPTZ` | `NOT NULL` | `CURRENT_TIMESTAMP` | Session start timestamp |

---

### **3.13** `email_verification_tokens`

Tokens sent to users to verify their email address during onboarding.

| Column | Data Type (PostgreSQL) | Constraints | Default | Description |
| --- | --- | --- | --- | --- |
| `id` | `UUID` | `PRIMARY KEY` | `uuid_generate_v4()` | Unique token identifier |
| `user_id` | `UUID` | `FOREIGN KEY (users.id) ON DELETE CASCADE, NOT NULL, INDEX` | \-  | Owning user |
| `token_hash` | `TEXT` | `NOT NULL` | \-  | Secure hash of verification token |
| `used` | `BOOLEAN` | `NOT NULL` | `FALSE` | True if token has been redeemed |
| `expires_at` | `TIMESTAMPTZ` | `NOT NULL, INDEX` | \-  | Token expiration limit |
| `created_at` | `TIMESTAMPTZ` | `NOT NULL` | `CURRENT_TIMESTAMP` | Token creation timestamp |

---

### **3.14** `password_reset_tokens`

Temporary hashes for password recovery workflow.

| Column | Data Type (PostgreSQL) | Constraints | Default | Description |
| --- | --- | --- | --- | --- |
| `id` | `UUID` | `PRIMARY KEY` | `uuid_generate_v4()` | Unique token identifier |
| `user_id` | `UUID` | `FOREIGN KEY (users.id) ON DELETE CASCADE, NOT NULL, INDEX` | \-  | Requesting user |
| `token_hash` | `TEXT` | `NOT NULL` | \-  | Secure hash of recovery token |
| `used` | `BOOLEAN` | `NOT NULL` | `FALSE` | True if token has been redeemed |
| `expires_at` | `TIMESTAMPTZ` | `NOT NULL, INDEX` | \-  | Token expiration limit |
| `created_at` | `TIMESTAMPTZ` | `NOT NULL` | `CURRENT_TIMESTAMP` | Token creation timestamp |

---

## **4\. Key Relationships & Cascades**

### **4.1 Delete Cascade Strategies**

1.  **User Cascades**:
    - Deleting a `User` will delete all related records in `resumes`, `job_descriptions`, `interview_sessions`, `user_sessions`, `email_verification_tokens`, and `password_reset_tokens` via `ondelete="CASCADE"`.
2.  **Session Cascades**:
    - Deleting an `InterviewSession` will delete all related `interview_questions` (and their `interview_answers`), `interview_evaluations`, `speech_analytics`, `video_recordings`, `improvement_suggestions`, and `skill_scores` via `ondelete="CASCADE"`.
3.  **Soft/Settable Deletes**:
    - `interview_sessions.resume_id` and `interview_sessions.jd_id` are configured with `ondelete="SET NULL"`. This guarantees that deleting a historical resume or job description does not disrupt the user's interview history.
    - Retakes: If a parent interview session is deleted, the child retake sessions have their `parent_session_id` set to `NULL` via `ondelete="SET NULL"` so history is preserved.

### **4.2 Indexes & Optimization**

Database performance is optimized through the use of B-Tree indices on:

- Email fields for rapid login lookups (`users.email`).
- Foreign key dependencies to speed up joins (`user_id` across resumes, sessions, JDs, tokens, and sessions).
- Token validation fields (`expires_at` across `user_sessions`, `email_verification_tokens`, and `password_reset_tokens`) to facilitate automated token clean-up processes.