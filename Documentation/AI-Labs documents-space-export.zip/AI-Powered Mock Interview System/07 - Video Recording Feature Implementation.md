# 07 - Video Recording Feature Implementation

> **Version**: 1.0.0  
> **Last Updated**: April 2026  
> **Status**: Production Ready

---

## **1\. Overview**

The **Video Recording Feature** is designed to capture the candidate's camera and microphone during an interview session. The implementation ensures high reliability even over unstable internet connections by using a chunk-based streaming upload strategy.

### **Key Objectives**

- **Zero Data Loss**: Uploads video in real-time to prevent loss if the browser crashes.
- **Low Memory Overhead**: Processes video in small chunks rather than keeping the entire recording in RAM.
- **Production Performance**: Uses background processing for heavy tasks like video merging and transcoding.

---

## **2\. Technical Architecture**

The recording pipeline follows a three-stage lifecycle:

```mermaid
graph TD
    A[Browser: MediaRecorder] -->|5s WebM Chunks| B[FastAPI: /upload-chunk]
    B -->|Streaming Save| C[Local Storage: /chunks]
    D[Browser: Stop Recording] -->|POST /finalize| E[FastAPI: /finalize]
    E -->|Background Task| F[Worker: Merge & Transcode]
    F -->|FFmpeg| G[Final MP4 Output]
    G -->|Cleanup| H[Remove Temp Chunks]
```

---

## **3\. Frontend Implementation (**`VideoRecorder.tsx`**)**

The frontend utilizes the native browser **MediaRecorder API** to capture media streams.

### **Recording Specifications**

- **Format**: Video/WebM
- **Resolution**: 1280x720 (720p)
- **Chunk Duration**: 5 seconds
- **Audio**: Enabled

### **Upload Strategy**

The component maintains an internal upload queue with the following logic:

- **Concurrency**: Up to **3 concurrent uploads** are allowed to maximize bandwidth without saturating the connection.
- **Idempotency**: Each chunk is indexed (0, 1, 2...).
- **Retry Logic**: Implements **exponential backoff** (up to 5 retries) for failed chunk uploads.
- **State Management**: Tracks `isRecording` and `uploadStatus` ("idle", "uploading", "success", "error") to provide visual feedback to the user.

---

## **4\. Backend Implementation**

### **4.1 API Layer (**`routes.py`**)**

| Endpoint | Method | Input | Description |
| --- | --- | --- | --- |
| `/upload-chunk` | POST | `session_id`, `chunk_index`, `video` (file) | Saves a chunk to the session directory. |
| `/finalize` | POST | `session_id`, `max_index` | Triggers the background merge process. |

### **4.2 Session Management & Locking**

To ensure data integrity, **Redis** is used to manage session states:

- **Locking**: When a session is "finalizing", new chunk uploads are rejected (HTTP 409).
- **Concurrency**: Prevents multiple merge tasks from running for the same session.

### **4.3 Storage Service**

Chunks are stored in a structured directory tree: `storage/video/{user_id}/{session_id}/chunk_{index}.webm`

---

## **5\. Merging & Transcoding (**`service.py`**)**

Once the interview ends, the system orchestrates a multi-step merge process in the background.

1.  **Gap Analysis**: Verifies all chunks from `0` to `max_index` are present on disk.
2.  **Binary Append**: Performs a high-speed binary concatenation of WebM chunks into a single temporary file.
3.  **Transcoding (FFmpeg)**: Converts the WebM stream to a standard **MP4 (H.264)** container to ensure maximum compatibility across all devices and browsers.
    - **Video Codec**: `libx264` (Preset: `ultrafast`)
    - **Audio Codec**: `aac` (Bitrate: `128k`)
4.  **Validation**: Uses `ffprobe` to verify the final file's duration and integrity.
5.  **Cleanup**: Automatically purges all temporary WebM chunks and temporary files after successful validation.

---

## **6\. Error Handling & Reliability**

- **Missing Chunks**: If chunks are missing during finalization, the system logs an error and halts the merge to prevent generating a corrupted video.
- **File System Robustness**: Uses streaming writes (`shutil.copyfileobj`) to handle large files safely.
- **FFmpeg Timeouts**: Transcoding tasks have dynamic timeouts based on the number of chunks to prevent zombie processes.