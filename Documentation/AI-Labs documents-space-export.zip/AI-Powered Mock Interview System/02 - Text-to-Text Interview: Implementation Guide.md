# 02 - Text-to-Text Interview: Implementation Guide

> **Feature**: AI-powered text-based mock interview  
> **Mode**: Candidate types answers → AI generates next question as streamed text  
> **Stack**: FastAPI (SSE) · LangChain LCEL · Google Gemini 2.5 Flash · React (SSE consumer)

---

## **Table of Contents**

1.  [Feature Overview](https://file+.vscode-resource.vscode-cdn.net/home/root495/Inexture/mock_interview/documents/02_TEXT_TO_TEXT_INTERVIEW_IMPLEMENTATION.md#1-feature-overview)
2.  [End-to-End Flow Diagram](https://file+.vscode-resource.vscode-cdn.net/home/root495/Inexture/mock_interview/documents/02_TEXT_TO_TEXT_INTERVIEW_IMPLEMENTATION.md#2-end-to-end-flow-diagram)
3.  [Phase 1 — Session Setup (Frontend)](https://file+.vscode-resource.vscode-cdn.net/home/root495/Inexture/mock_interview/documents/02_TEXT_TO_TEXT_INTERVIEW_IMPLEMENTATION.md#3-phase-1--session-setup-frontend)
4.  [Phase 2 — Start Interview (Backend)](https://file+.vscode-resource.vscode-cdn.net/home/root495/Inexture/mock_interview/documents/02_TEXT_TO_TEXT_INTERVIEW_IMPLEMENTATION.md#4-phase-2--start-interview-backend)
5.  [Phase 3 — Active Interview Turn (Frontend)](https://file+.vscode-resource.vscode-cdn.net/home/root495/Inexture/mock_interview/documents/02_TEXT_TO_TEXT_INTERVIEW_IMPLEMENTATION.md#5-phase-3--active-interview-turn-frontend)
6.  [Phase 4 — Answer Processing & Streaming (Backend)](https://file+.vscode-resource.vscode-cdn.net/home/root495/Inexture/mock_interview/documents/02_TEXT_TO_TEXT_INTERVIEW_IMPLEMENTATION.md#6-phase-4--answer-processing--streaming-backend)
7.  [Phase 5 — Topic Switching Logic](https://file+.vscode-resource.vscode-cdn.net/home/root495/Inexture/mock_interview/documents/02_TEXT_TO_TEXT_INTERVIEW_IMPLEMENTATION.md#7-phase-5--topic-switching-logic)
8.  [Phase 6 — End & Evaluation](https://file+.vscode-resource.vscode-cdn.net/home/root495/Inexture/mock_interview/documents/02_TEXT_TO_TEXT_INTERVIEW_IMPLEMENTATION.md#8-phase-6--end--evaluation)
9.  [Prompt Engineering Details](https://file+.vscode-resource.vscode-cdn.net/home/root495/Inexture/mock_interview/documents/02_TEXT_TO_TEXT_INTERVIEW_IMPLEMENTATION.md#9-prompt-engineering-details)
10. [LLM Fallback Strategy](https://file+.vscode-resource.vscode-cdn.net/home/root495/Inexture/mock_interview/documents/02_TEXT_TO_TEXT_INTERVIEW_IMPLEMENTATION.md#10-llm-fallback-strategy)
11. [State Management](https://file+.vscode-resource.vscode-cdn.net/home/root495/Inexture/mock_interview/documents/02_TEXT_TO_TEXT_INTERVIEW_IMPLEMENTATION.md#11-state-management)
12. [Key Design Decisions](https://file+.vscode-resource.vscode-cdn.net/home/root495/Inexture/mock_interview/documents/02_TEXT_TO_TEXT_INTERVIEW_IMPLEMENTATION.md#12-key-design-decisions)

---

## **1\. Feature Overview**

The Text-to-Text interview is the core interview mode of the application. It works as follows:

- The candidate uploads a **resume** (PDF or DOCX), enters their **job role** and **years of experience**.
- The backend extracts structured data from the resume using an LLM.
- An interview session begins with a fixed opening question.
- The candidate types their answer; the AI streams the next question back token-by-token (like a real-time typing effect).
- The AI adapts each question based on the candidate's answer and can switch topics if the candidate doesn't know something.
- At the end, the AI produces a detailed evaluation report with per-question feedback and category scores.

---

## **2\. End-to-End Flow Diagram**

```
┌──────────────────────────────────────────────────────────────────────┐
│  NewSession.tsx (React)                                               │
│  • User uploads resume + enters job_role + experience                │
│  • POST /api/v1/interview/start  (multipart/form-data)               │
└──────────────────────────────┬───────────────────────────────────────┘
                               │
                               ▼
┌──────────────────────────────────────────────────────────────────────┐
│  routes.py → start_interview()                                        │
│  1. Extract text from PDF/DOCX  (helper.resume_text_from_pdf)        │
│  2. LLM: extract resume JSON    (resume_extraction_chain → Gemini)   │
│  3. Create InterviewState       (session_id, chains, memory)         │
│  4. Return session_id + first_question                                │
└──────────────────────────────┬───────────────────────────────────────┘
                               │  {session_id, first_question}
                               ▼
┌──────────────────────────────────────────────────────────────────────┐
│  Interview.tsx (React)                                                │
│  • Displays first_question as AI message bubble                      │
│  • Candidate types answer → clicks Send (or presses Enter)           │
│  • POST /api/v1/interview/answer/stream  (JSON)                      │
└──────────────────────────────┬───────────────────────────────────────┘
                               │
                               ▼
┌──────────────────────────────────────────────────────────────────────┐
│  routes.py → submit_answer_stream()                                   │
│  → services.process_answer_stream()  [generator]                     │
│                                                                       │
│  1. Append Q/A to chat_history + LangChain memory                    │
│  2. Format prompt (inject resume_data if switch_topic=True)          │
│  3. Gemini stream_prompt() → yield SSE tokens                        │
│     data: {"token": "..."}\n\n   (per chunk)                         │
│     data: {"done": true, "question": "..."}\n\n  (final)             │
│  4. Parse full response → update switch_topic + current_question     │
└──────────────────────────────┬───────────────────────────────────────┘
                               │  SSE stream
                               ▼
┌──────────────────────────────────────────────────────────────────────┐
│  Interview.tsx — SSE Consumer                                         │
│  • ReadableStream reader reads chunks                                 │
│  • token events → appended to last message bubble (live typing)      │
│  • done event  → replaces bubble with clean parsed question          │
│  • Repeat until candidate clicks "End Session"                        │
└──────────────────────────────────────────────────────────────────────┘
```

---

## **3\. Phase 1 — Session Setup (Frontend)**

**File:** `frontend/src/pages/NewSession.tsx`

The user configures their interview session through a two-panel form:

### **What the user provides**

| Field | Input type | Validation |
| --- | --- | --- |
| Resume | File upload (PDF / DOCX / DOC) | Required, max 5MB |
| Target Job Role | Text input | Required, non-empty |
| Experience | Number input | 0–50 years, defaults to 2 |

### **What happens on "Start Interview Session"**

```typescript
const formData = new FormData();
formData.append("resume", resumeFile);
formData.append("job_role", jobRole);
formData.append("experience", experience.toString());

const response = await fetch("http://127.0.0.1:8000/api/v1/interview/start", {
  method: "POST",
  body: formData,   // multipart/form-data — no Content-Type header needed
});

const data = await response.json();

// Navigate to the interview page, passing session state via React Router
navigate("/interview", {
  state: {
    sessionId: data.session_id,
    initialQuestion: data.first_question,
  },
});
```

- A loading spinner (`Loader2`) is shown while the request is in-flight.
- On success, the user is navigated to `/interview` with `sessionId` and `initialQuestion` passed via React Router's location state.
- On failure, a destructive toast notification is shown.

---

## **4\. Phase 2 — Start Interview (Backend)**

**Files:** `routes.py` → `services.py` → `chain.py` → `gemini_client.py`

### **Step-by-step inside** `InterviewService.start_interview()`

#### **Step 1: Generate session UUID**

```python
session_id = str(uuid.uuid4())
```

#### **Step 2: Extract resume text → structured JSON**

The resume plain text (already extracted from PDF/DOCX by `helper.resume_text_from_pdf`) is sent to the **resume extraction chain**:

```python
extraction_chain = create_resume_extraction_chain(self.primary_llm.get_llm_instance())
response = extraction_chain.invoke({"resume_text": resume_text}).content.strip()
extracted_data = parse_resume_data(response)
```

The chain uses this system prompt (from `templates.py`):

> _"You are an expert resume parser. Extract key information... return ONLY a valid JSON object."_

Expected output:

```json
{
  "Projects": ["Project A", "Project B"],
  "Skills": ["Python", "Django", "React"],
  "Work Experience": ["Software Engineer at XYZ"],
  "Education": ["B.Tech Computer Science"],
  "Certifications": ["AWS Certified"]
}
```

`parse_resume_data()` tries 5 fallback strategies if the LLM returns malformed JSON (see Section 10).

#### **Step 3: Build the question chain**

```python
question_chain = create_question_chain(self.primary_llm.get_llm_instance())
# = interview_question_template | llm
```

#### **Step 4: Initialise LangChain memory**

```python
memory = ConversationBufferMemory(memory_key="chat_history", return_messages=True)
```

#### **Step 5: Create and store** `InterviewState`

```python
state = InterviewState(
    session_id=session_id,
    resume_text=resume_text,
    job_role=job_role,
    experience=experience,
    extracted_data=extracted_data,
    question_chain=question_chain,
    memory=memory,
)
state.current_question = "Can you please tell me a bit about your technical skills?"
active_interviews[session_id] = state
```

The **first question is fixed** — no LLM call needed. This avoids latency on session start and ensures a consistent, friendly opening.

#### **Response returned to frontend**

```json
{
  "session_id": "550e8400-e29b-41d4-a716-446655440000",
  "message": "Interview started successfully",
  "first_question": "Can you please tell me a bit about your technical skills?"
}
```

---

## **5\. Phase 3 — Active Interview Turn (Frontend)**

**File:** `frontend/src/pages/Interview.tsx`

### **UI Layout**

```
┌─────────────────────────────────────────────┐
│  Header: AI Mock Interview Session          │
│  [Bot icon] Live • Session ID: 550e8400...  │  [End Session]
├─────────────────────────────────────────────┤
│                                             │
│  🤖 AI Interviewer                          │
│  ┌─────────────────────────────────────┐   │
│  │ Can you tell me about your skills?  │   │
│  └─────────────────────────────────────┘   │
│                                             │
│                          You               │
│          ┌──────────────────────────────┐  │
│          │ I have 3 years of Python...  │  │
│          └──────────────────────────────┘  │
│                                             │
│  🤖 AI Interviewer                          │
│  ┌─────────────────────────────────────┐   │
│  │ Can you describe a challenging...   │   │  ← streams in live
│  └─────────────────────────────────────┘   │
│                                             │
├─────────────────────────────────────────────┤
│  [Type your response here...]    [→ Send]   │
│              ⌘ Enter to send                │
└─────────────────────────────────────────────┘
```

### **Message state**

```typescript
interface Message {
  role: "interviewer" | "user";
  content: string;
  time: string;   // HH:MM format
}

const [messages, setMessages] = useState<Message[]>([]);
```

Messages are rendered in a scrollable list. AI messages are left-aligned with a Bot icon; user messages are right-aligned.

### **Sending an answer (**`handleSend`**)**

```typescript
const handleSend = async () => {
  // 1. Add user message to chat immediately (optimistic update)
  setMessages(prev => [...prev, userMessage]);
  setInput("");
  setIsSending(true);

  // 2. Add an empty AI bubble — this will be filled by the stream
  setMessages(prev => [...prev, { role: "interviewer", content: "", time: ... }]);

  // 3. Open SSE stream
  const response = await fetch(".../answer/stream", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ session_id: sessionId, answer: userMessage.content }),
  });

  // 4. Read the stream
  const reader = response.body.getReader();
  const decoder = new TextDecoder();

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;

    const text = decoder.decode(value, { stream: true });
    const lines = text.split("\n").filter(l => l.startsWith("data: "));

    for (const line of lines) {
      const payload = JSON.parse(line.slice(6));  // strip "data: "

      if (payload.token) {
        // Append token to the last (streaming) message bubble
        setMessages(prev => {
          const updated = [...prev];
          updated[updated.length - 1].content += payload.token;
          return updated;
        });
      }

      if (payload.done) {
        // Replace streaming content with the clean parsed question
        setMessages(prev => {
          const updated = [...prev];
          updated[updated.length - 1].content = payload.question;
          return updated;
        });
      }
    }
  }
};
```

**Key UX details:**

- The empty AI bubble appears immediately, giving instant visual feedback.
- Tokens are appended character-by-character, creating a live "typing" effect.
- The `done` event replaces the accumulated raw tokens with the clean parsed question (strips any JSON wrapper the LLM may have included).
- On error, the empty bubble is removed and a toast is shown.
- `Enter` key triggers send (when not already sending).

---

## **6\. Phase 4 — Answer Processing & Streaming (Backend)**

**File:** `services.py` → `process_answer_stream()`

### **Step-by-step**

#### **Step 1: Validate session**

```python
if session_id not in active_interviews:
    raise ValueError("Session not found")  # → HTTP 404
```

#### **Step 2: Record the completed Q/A pair**

```python
state.chat_history.append((state.current_question, answer))
state.memory.chat_memory.add_ai_message(state.current_question)
state.memory.chat_memory.add_user_message(answer)
```

Both stores are updated:

- `chat_history` — raw list of tuples, used for evaluation formatting
- `memory` — LangChain `ConversationBufferMemory`, passed to the question chain for full context

#### **Step 3: Decide whether to inject resume data**

```python
resume_data_str = (
    self._format_resume_data(state.extracted_resume_data)
    if state.switch_topic   # set by LLM on the PREVIOUS turn
    else ""
)
```

#### **Step 4: Format the prompt string directly**

```python
from app.ai.prompts.templates import interview_question_template
prompt_str = interview_question_template.format(
    chat_history=state.memory.chat_memory.messages,
    resume_data=resume_data_str,
    experience=state.experience,
    job_role=state.job_role,
)
```

The streaming path formats the prompt as a plain string and calls `stream_prompt()` directly, bypassing LangChain's `chain.invoke()` (which doesn't support streaming in this setup).

#### **Step 5: Stream from Gemini**

```python
gemini_wrapper = self.primary_llm.get_llm_instance()
for chunk in gemini_wrapper.stream_prompt(prompt_str):
    full_response += chunk
    yield f"data: {json.dumps({'token': chunk})}\n\n"
```

`stream_prompt()` calls the Gemini SDK's `generate_content_stream()`:

```python
def stream_prompt(self, prompt: str):
    for chunk in _client.models.generate_content_stream(
        model=self.model_name,
        contents=prompt,
        config=types.GenerateContentConfig(temperature=self.temperature),
    ):
        if chunk.text:
            yield chunk.text
```

#### **Step 6: Parse full response and emit final event**

```python
parsed = self._parse_chain_response(full_response)
state.switch_topic = bool(parsed.get("switch_topic", False))
next_question = parsed.get("question", full_response)
state.current_question = next_question

yield f"data: {json.dumps({'done': True, 'question': next_question})}\n\n"
```

### **SSE Response format**

```
HTTP/1.1 200 OK
Content-Type: text/event-stream
Cache-Control: no-cache
X-Accel-Buffering: no

data: {"token": "Can "}\n\n
data: {"token": "you "}\n\n
data: {"token": "describe "}\n\n
data: {"token": "a challenging Django project?"}\n\n
data: {"done": true, "question": "Can you describe a challenging Django project?"}\n\n
```

The `X-Accel-Buffering: no` header prevents Nginx from buffering the stream, ensuring tokens reach the browser immediately.

---

## **7\. Phase 5 — Topic Switching Logic**

One of the key intelligence features of the interview is **adaptive topic switching**.

### **How it works**

The LLM is instructed to return a JSON object on every turn:

```json
{"switch_topic": true, "question": "Tell me about a project from your resume."}
```

The `switch_topic` flag is **one turn behind by design**:

```
Turn N:   Candidate says "I don't know"
          → LLM returns switch_topic: true
          → state.switch_topic = True  (stored, not used yet)

Turn N+1: resume_data is injected into the prompt
          → LLM picks a NEW topic from resume
          → LLM returns switch_topic: false (or true again)
          → state.switch_topic updated for Turn N+2
```

### **Why one turn behind?**

The LLM decides on turn N whether the topic should switch. The resume data is injected on turn N+1 so the LLM has the full context (including the candidate's answer) when making the decision, and the switch takes effect cleanly on the next question.

### **When does the LLM switch topics?**

From the prompt template:

> _"Set switch_topic to true if the candidate expressed they don't know, asked to skip, gave a completely irrelevant or empty answer, or showed no understanding of the topic."_

### **Resume data injection**

When `switch_topic=True`, the formatted resume data is injected:

```
Projects: Project A, Project B
Skills: Python, Django, React
Work Experience: Software Engineer at XYZ
Education: B.Tech Computer Science
Certifications: AWS Certified
```

The LLM is instructed to pick a **new topic not yet discussed** from this data.

### **Difficulty calibration**

The prompt also calibrates question difficulty based on experience:

```
- 0-2 years: Easy (foundational concepts)
- 2-5 years: Medium (real-world application)
- 5+ years:  Hard (system design, architecture)
```

---

## **8\. Phase 6 — End & Evaluation**

When the candidate clicks **"End Session"**, the frontend currently navigates back to `/new-session`. The evaluation endpoint exists on the backend and can be called explicitly:

`POST /api/v1/interview/end?session_id=<uuid>`

### **Backend:** `evaluate_interview()`

```python
# Format conversation as Q/A pairs
formatted_history = "\n".join([f"Q: {q}\nA: {a}" for q, a in state.chat_history])

# Run evaluation chain
eval_chain = create_evaluation_chain(self.primary_llm.get_llm_instance())
evaluation = eval_chain.invoke({"conversation": formatted_history}).content

# Clean up session
del active_interviews[session_id]
return evaluation
```

### **Evaluation prompt output format**

The LLM returns a structured text report:

```
Q1: Can you tell me about your technical skills?
A1: I have 3 years of Python experience...
F1: Good overview. Consider mentioning specific frameworks like Django or FastAPI...

Q2: Describe a challenging project you worked on.
A2: I built a REST API for...
F2: Strong answer. Could elaborate on scalability considerations...

Final Evaluation:
1. Technical Accuracy: 7/10 — Solid understanding of core concepts...
2. Problem-Solving Approach: 6/10 — Good logical thinking...
3. Communication Clarity: 8/10 — Clear and concise answers...
4. Depth of Knowledge: 6/10 — Could go deeper on system design...
5. Overall Coherence: 7/10 — Well-structured responses...
```

---

## **9\. Prompt Engineering Details**

### **Question Generation Prompt (**`interview_question_template`**)**

**Variables:** `chat_history`, `resume_data`, `experience`, `job_role`

**Key instructions to the LLM:**

1.  Read the candidate's **last answer** carefully.
2.  Decide `switch_topic` based on the answer quality.
3.  If switching: pick a **new topic** from `resume_data` (not previously discussed).
4.  If continuing: build on the candidate's answer.
5.  Match difficulty to `experience` level.
6.  Keep the question **under 20 words**, focused on ONE aspect.
7.  **Return ONLY valid JSON** — no extra text.

**Why strict JSON output?**

The backend parses the LLM response as JSON to extract both `switch_topic` and `question`. If the LLM wraps the JSON in a markdown code fence (` ```json ... ``` `), `_parse_chain_response()` strips it before parsing.

### **Resume Extraction Prompt (**`resume_extraction_system_prompt`**)**

**Variable:** `resume_text`

**Key rules enforced:**

- Return ONLY the JSON object, no other text.
- Use empty arrays `[]` for missing sections.
- Extract 3–5 most relevant items per section.
- Use simple strings, no nested objects.
- Ensure all quotes are double quotes, no trailing commas.

### **Evaluation Prompt (**`evaluation_template`**)**

**Variable:** `conversation`

**Key instruction:**

> _"You are in evaluation mode. Do NOT use any tools or search functions. Base your evaluation ONLY on the conversation provided below."_

This prevents the LLM from hallucinating external information.

---

## **10\. LLM Fallback Strategy**

Every LLM call follows a **try-primary → fallback** pattern:

### **For streaming (**`process_answer_stream`**)**

```
1. Try Gemini streaming (stream_prompt)
   ├── Success → yield tokens one by one
   └── Exception → log warning
       2. Try Groq non-streaming (fallback_chain.invoke)
          ├── Success → yield full response as single token event
          └── Exception → log error
              3. Yield FALLBACK_QUESTION as single token event
```

The client receives the same SSE format regardless of which path was taken — it always gets token events followed by a `done` event.

### **For resume extraction (**`start_interview`**)**

```
1. Try Gemini extraction chain
   ├── Success → parse JSON
   └── Exception → log warning
       2. Try Groq extraction chain
          ├── Success → parse JSON
          └── Exception → log error
              3. Use empty dict {} (generic questions, no resume context)
```

### **For evaluation (**`evaluate_interview`**)**

```
1. Try Gemini evaluation chain
   ├── Success → return evaluation text
   └── Exception → log warning
       2. Try Groq evaluation chain (no further fallback)
```

---

## **11\. State Management**

### **Backend —** `InterviewState`

All session state lives in a module-level dict:

```python
active_interviews: dict[str, InterviewState] = {}
```

| Field | Type | Purpose |
| --- | --- | --- |
| `session_id` | `str` | UUID key |
| `job_role` | `str` | Passed to every question prompt |
| `experience` | `int` | Controls difficulty calibration |
| `extracted_resume_data` | `dict` | Injected when `switch_topic=True` |
| `question_chain` | `Runnable` | LCEL chain for question generation |
| `memory` | `ConversationBufferMemory` | Full conversation context for LLM |
| `chat_history` | `list[tuple]` | Raw Q/A pairs for evaluation |
| `current_question` | `str` | The question awaiting an answer |
| `switch_topic` | `bool` | One-turn-behind topic switch flag |

Session is deleted from `active_interviews` after `evaluate_interview()` is called.

### **Frontend — React State**

| State | Type | Purpose |
| --- | --- | --- |
| `messages` | `Message[]` | Full chat history displayed in UI |
| `input` | `string` | Current text in the input field |
| `isSending` | `boolean` | Disables input + shows spinner during API call |
| `sessionId` | `string` | From React Router location state |
| `initialQuestion` | `string` | From React Router location state |

---

## **12\. Key Design Decisions**

| Decision | Rationale |
| --- | --- |
| **SSE over WebSockets** | SSE is simpler (HTTP, unidirectional), sufficient for server→client streaming. No need for bidirectional communication. |
| **Fixed first question** | Avoids LLM latency on session start. The opening question is always appropriate regardless of resume content. |
| `switch_topic` **one turn behind** | Allows the LLM to make the decision with full context (including the candidate's answer) before the switch takes effect. |
| **Streaming bypasses LangChain chain** | LangChain's `chain.invoke()` doesn't support streaming in this setup. `stream_prompt()` calls the Gemini SDK directly for true token-by-token streaming. |
| `done` **event replaces streamed content** | The streamed tokens may include raw JSON wrapper text. The `done` event provides the clean, parsed question string. |
| `temperature=0.7` **for Gemini** | Balanced creativity — questions feel natural and varied, not robotic. |
| `temperature=0` **for Groq** | Deterministic fallback — consistent, predictable output for evaluation tasks. |
| **Dual memory stores** | `chat_history` (raw tuples) is used for evaluation formatting. `memory` (LangChain) is passed to the LLM for conversation context. Both are needed. |
| **In-memory session store** | Simple and fast for single-process development. Replace with Redis for production multi-worker deployments. |