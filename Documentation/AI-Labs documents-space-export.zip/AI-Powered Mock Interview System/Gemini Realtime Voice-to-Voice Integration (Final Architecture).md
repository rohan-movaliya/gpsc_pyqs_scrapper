# Gemini Realtime Voice-to-Voice Integration (Final Architecture)

## **1.  Overview**

This document describes the implementation of a **low-latency voice-to-voice interview system** using:

- **LiveKit** → real-time audio transport
- **Gemini Realtime (Multimodal Live API)** → voice understanding + speech generation
- **Backend (FastAPI + LLM)** → interview logic  
    

The goal is to achieve:

- Natural conversation (like a real interviewer)
- Controlled interview logic (no hallucination)
- Low latency (~2–3 seconds)  
    

## **2.  Core Design Principle**

We separate responsibilities:

|     |     |
| --- | --- |
| **Component** | **Responsibility** |
| **Gemini Realtime** | Voice input, intent detection, voice output |
| **Backend (InterviewService)** | Interview logic, question generation, evaluation |

Gemini **does NOT control interview flow**  
Backend **fully controls question progression**

## **3.  System Architecture**

User (Mic)

  ↓

LiveKit (WebRTC streaming)

  ↓

Gemini Realtime (Audio processing)

  ↓

Decision Layer (inside Gemini):

  ├── Clarification → handled locally

  └── Answer → call backend tool

  ↓

Backend (FastAPI /answer API)

  ↓

LLM (Gemini Flash / Groq)

  ↓

Next Question

  ↓

Gemini Realtime (TTS)

  ↓

LiveKit

  ↓

User (Speaker)

---

## **4.  Interaction Flow**

### **4.1 Case 1 — Candidate Gives Answer**

**User Input:**

“Django ORM is used to interact with database using models”

### **Flow:**

1.  Gemini detects → **Answer**
2.  Calls tool:  
    submit_answer_and_get_next_question(answer)
3.  Backend:
    - Evaluates answer
    - Updates state (topic, follow-ups)
    - Generates next question
4.  Gemini speaks:  
    “Can you explain how Django ORM translates queries into SQL?”

### **4.2 Case 2 — Candidate Asks Clarification**

**User Input:**

“Can you repeat the question?”

### **Flow:**

1.  Gemini detects → **Clarification**
2.  No backend call
3.  Gemini responds:

“Sure! I’m asking how Django ORM works internally.”

### **4.3 Case 3 — Weak / Partial Answer**

**User Input:**

“It is used for database”

### **Flow:**

1.  Gemini detects → **Answer**
2.  Calls backend (MANDATORY)
3.  Backend decides next question

## **5\. Tool Design**

Only **ONE tool is required**:

class InterviewTools:

   @llm.function_tool

   async def submit_answer_and_get_next_question(

       self,

       candidate_answer_summary: str,

   ) -> str:

       """

       MUST be called whenever the user provides ANY meaningful answer.

  

       Includes:

       - Partial answers

       - Weak answers

       - Incorrect answers

       - Full answers

  

       DO NOT call if:

       - User asks for clarification

       - User asks to repeat

       - User is not answering

       """

  

       response = await api_client.submit_answer(

           session_id,

           candidate_answer_summary

       )

  

       return response\["current_question"\]

## **6.  System Instructions (Gemini)**

You are a senior technical interviewer.

Rules:

1\. Ask only ONE question at a time.

2\. Never generate your own next question.

3\. If the candidate:

  - asks for clarification → explain simply

  - asks to repeat → repeat question

4\. If the candidate gives ANY answer:

  → MUST call submit_answer_and_get_next_question

5\. Do NOT:

  - evaluate answers

  - skip the tool

  - generate follow-up questions yourself

Your first question is:

"{first_question}"

## **7.  Latency Breakdown**

|     |     |
| --- | --- |
| **Step** | **Time** |
| Speech detection | 300–800 ms |
| Gemini processing (STT) | 200–500 ms |
| Backend API call | 50–150 ms |
| LLM processing | 500–1500 ms |
| TTS generation | 300–700 ms |

## **Total Latency**

|     |     |
| --- | --- |
| **Scenario** | **Latency** |
| Best case | ~1.2 – 2 sec |
| Average | ~2 – 3.5 sec |
| Worst case | ~4+ sec |

---

## **8.  Performance Optimization**

### **Recommended**

- Use **Gemini Flash / Groq** for fast LLM
- Keep prompt small (recent_history, current_topic)
- Use streaming TTS
- Optimize silence detection

### **Avoid**

- Sending full chat history
- Heavy models (slow)
- Letting Gemini control interview logic

## **9.  Key Rules (Very Important)**

### **Rule 1:**

Gemini handles conversation, NOT logic

### **Rule 2:**

Backend ALWAYS decides next question

### **Rule 3:**

Tool MUST be called for every answer

---

## **10.  Final Mental Model**

User speaks

  ↓

Gemini understands

  ↓

IF clarification:

  → Gemini responds

IF answer:

  → Backend decides next question

  → Gemini speaks it

## **11.  Benefits of This Architecture**

-  Natural voice conversation
-  No hallucination
-  Controlled interview flow
-  Scalable (Redis session support)
-  Production-ready design

## **12.  Conclusion**

This approach provides the **best of both worlds**:

- Gemini → human-like interaction
- Backend → strict interview control

Result: **Realistic AI interviewer with low latency and high accuracy**