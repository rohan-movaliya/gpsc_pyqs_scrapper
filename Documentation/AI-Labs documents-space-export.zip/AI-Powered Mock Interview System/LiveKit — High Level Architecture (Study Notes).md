# LiveKit — High Level Architecture (Study Notes)

## 1\. What LiveKit Is

**LiveKit** is an open-source platform for **real-time audio and video communication**.

It is commonly used for:

- Voice AI assistants
- Real-time interview bots
- Video meetings
- Customer support agents
- AI copilots

The key capability of LiveKit is **low-latency media streaming**.

Instead of sending complete audio files, LiveKit streams **small audio packets continuously**.

---

# 2\. Traditional Voice AI Architecture

Before understanding LiveKit, we need to understand the **traditional pipeline**.

### Normal Voice Processing

```
User speaks
     ↓
Audio recording completes
     ↓
Audio file uploaded
     ↓
Speech-to-Text (STT)
     ↓
LLM generates response
     ↓
Text-to-Speech (TTS)
     ↓
Audio returned
```

### Problems

1.  Recording must finish first
2.  Entire audio file must upload
3.  STT starts only after upload

Example latency:

```
User speaking        3s
Upload audio         1s
STT processing       1s
LLM response         0.5s
TTS generation       0.5s

Total delay ≈ 6 seconds
```

This feels **slow and unnatural**.

---

# 3\. LiveKit Real-Time Architecture

LiveKit solves this using **streaming media with WebRTC**.

### High-Level Architecture

```
User Microphone
        ↓
WebRTC audio stream
        ↓
LiveKit Server (media router)
        ↓
AI Worker
   ├─ Speech-to-Text
   ├─ LLM reasoning
   └─ Text-to-Speech
        ↓
Audio streamed back to user
```

---

# 4\. Key Technologies Used

## WebRTC

LiveKit uses **WebRTC** for real-time communication.

Features:

- UDP transport (low latency)
- adaptive bitrate
- real-time streaming
- peer optimized routing

Typical latency:

```
200ms – 500ms
```

---

# 5\. Audio Streaming Mechanism

Microphones capture audio in **small frames**.

Typical frame size:

```
20 ms
```

Example timeline:

```
Frame 1 → 20ms
Frame 2 → 20ms
Frame 3 → 20ms
Frame 4 → 20ms
```

These frames are continuously streamed to the server.

Pipeline:

```
Microphone
     ↓
20ms audio frames
     ↓
LiveKit stream
     ↓
Speech-to-Text engine
```

---

# 6\. Streaming Speech-to-Text (STT)

The STT engine processes audio **while the user is speaking**.

Example sentence:

> “I have overall 3 years experience in python”

Streaming STT output:

```
I
I have
I have overall
I have overall 3
I have overall 3 years
I have overall 3 years experience
I have overall 3 years experience in python
```

These are called **partial transcripts**.

They update continuously.

---

# 7\. Voice Activity Detection (VAD)

The system must know **when the user stops speaking**.

This is done using **Voice Activity Detection (VAD)**.

Typical rule:

```
400–700 ms silence → speech ended
```

When silence is detected:

1.  STT finalizes the transcript
2.  LLM is triggered

---

# 8\. Final Processing Pipeline

After speech ends:

```
Final transcript
       ↓
LLM reasoning
       ↓
Text-to-Speech
       ↓
Audio streamed to user
```

---

# 9\. Timeline Example

User says:

> “I have overall 3 years experience in python”

User speaking time:

```
3 seconds
```

Timeline:

```
0.0s  user starts speaking
0.1s  STT begins processing audio
1.0s  partial transcript available
2.0s  transcript almost complete
3.0s  user stops speaking
3.2s  STT finalizes transcript
3.5s  LLM generates response
3.8s  TTS begins speaking
```

Perceived delay:

```
~700 ms
```

---

# 10\. Why LiveKit Feels Faster

The main improvement is **parallel processing**.

Traditional system:

```
Speech → STT → LLM → TTS
```

LiveKit system:

```
Speech
  └─ STT already running
```

So when speech ends:

```
STT is almost finished
```

Only a small **finalization step (~200 ms)** remains.

---

# 11\. Streaming Text-to-Speech

The response audio is also streamed.

Instead of generating full audio first:

```
text → full audio → send
```

LiveKit streams chunks:

```
audio chunk 1
audio chunk 2
audio chunk 3
```

The user hears the response **while it is being generated**.

---

# 12\. Key Components in LiveKit

### Room

A room is a communication session.

Example:

```
room_id = interview_session_123
```

Participants:

```
Candidate
AI interviewer
```

---

### Participant

Any entity inside the room.

Examples:

```
User
AI agent
```

---

### Media Track

A track represents a stream.

Types:

```
audio track
video track
data track
```

---

# 13\. Voice AI Pipeline Summary

Complete pipeline:

```
User microphone
      ↓
20ms audio frames
      ↓
LiveKit WebRTC stream
      ↓
Streaming STT
      ↓
Voice Activity Detection
      ↓
Final transcript
      ↓
LLM reasoning
      ↓
Streaming TTS
      ↓
Audio response
```

---

# 14\. Why LiveKit Is Useful for Interview System

Your project already includes:

- Speech-to-Text
- LLM interview logic
- Text-to-Speech

LiveKit adds:

- real-time audio streaming
- low latency
- natural conversation
- interruption handling

This makes the system behave like a **real interviewer conversation**.