# GitLab Link

https://gitlab.inexture.com/ai.inexture/cover_letter_humanizer/-/tree/dev/JD_Humanizer?ref_type=heads#installation--setup