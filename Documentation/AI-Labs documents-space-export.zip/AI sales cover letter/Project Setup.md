# Project Setup

### Installation & Setup

1.  **Clone the repository**
    
    ```
    git clone <repository-url>
    cd JD_Humanizer
    ```
    
2.  **Backend Setup**
    
    ```
    cd backend
    python -m venv ../venv
    source ../venv/bin/activate  # On Windows: ..\venv\Scripts\activate
    pip install -r requirements.txt
    ```
    
3.  **Environment Configuration**
    
    ```
    cp example_env.txt .env
    # Edit .env with your Groq API key
    ```
    
4.  **Run the Application**
    
    ```
    # From backend directory
    python main.py
    
    # Or with uvicorn
    uvicorn main:app --host 0.0.0.0 --port 8000 --reload
    ```
    
5.  **Frontend Setup** (Optional)
    
    ```
    cd frontend/UI
    npm install
    npm run dev
    ```