# RBAC Implementation Plan - AI Hospital Assistant

## Executive Summary

This document outlines a phased implementation plan for Role-Based Access Control (RBAC) in the AI Hospital Assistant application. The implementation will introduce Admin, Doctor, and Nurse user types alongside the existing Patient module, with a unified authentication system and role-based permissions.

## Current State Analysis

### Existing Components

- **Patient Module**: Fully implemented with authentication, CRUD operations, and self-registration
- **Doctor Model**: Exists in `app/apis/doctors/models.py` but lacks authentication and role integration
- **Roles & Permissions**: Infrastructure exists in `app/apis/roles/` and `app/apis/permissions/` but not fully integrated
- **Authentication**: Currently only supports Patient login/registration
- **User Model**: Referenced but not implemented (`app/apis/auth/models.py` missing)

### Key Gaps

1.  No unified User model for all user types
2.  Doctor model exists but lacks authentication capabilities
3.  No Admin or Nurse models
4.  Role assignment not integrated with user creation
5.  Permission system exists but not connected to user authentication
6.  No role-based route protection for different user types

## Implementation Strategy

### Design Decisions

1.  **Unified User Model**: Single User model that all roles (Admin, Doctor, Nurse, Patient) will use
2.  **Role Assignment**:
    - Admin assigns roles to Doctor and Nurse during creation
    - Patient self-registers and automatically gets "patient" role
3.  **Doctor Model Integration**: Merge existing Doctor model with User model (add authentication fields)
4.  **Unified Authentication**: Single login endpoint that detects user type from assigned role
5.  **Standardized API Response Format**: All API endpoints must return responses in the following format:

JSON

```
{
  "data": "string | object | array",
  "response": "string",
  "status_code": 0
}
```

- `data`: The actual response data (can be string, object, array, or null)
- `response`: Human-readable message describing the result
- `status_code`: HTTP status code (integer)

---

## Phase 1: Foundation - User Model and Database Schema

### Objectives

- Create unified User model
- Create UserRole junction table
- Migrate existing Patient data to User model
- Update database schema

### Tasks

#### 1.1 Create User Model (app/apis/auth/models.py)

- Create User model with:
    - `user_id` (UUID, primary key)
    - `email` (unique, indexed)
    - `password_hash` (for authentication)
    - `full_name`
    - `phone`
    - `is_active` (account status)
    - `user_type` (admin, doctor, nurse, patient) - for quick filtering
    - `created_at`, `updated_at` timestamps
- Add relationships:
    - `user_role` (one-to-one with UserRole)
    - `patient_profile` (one-to-one with Patient, optional)
    - `doctor_profile` (one-to-one with Doctor, optional)
    - `nurse_profile` (one-to-one with Nurse, optional)

#### 1.2 Create UserRole Junction Table

- Create UserRole model:
    - `id` (primary key)
    - `user_id` (UUID, foreign key to users)
    - `role_id` (Integer, foreign key to roles)
    - `created_at` timestamp
    - Unique constraint on `(user_id, role_id)`
- Add relationships to User and Role models

#### 1.3 Create Nurse Model (app/apis/nurses/models.py)

- Create Nurse model with:
    - `nurse_id` (UUID, primary key)
    - `user_id` (UUID, foreign key to users, unique)
    - `employee_id` (unique identifier)
    - `department_id` (foreign key to departments, optional)
    - `shift_type` (day/night)
    - `specialization` (optional)
    - `created_at`, `updated_at` timestamps
- Add relationship to User model

#### 1.4 Update Doctor Model (app/apis/doctors/models.py)

- Add `user_id` field (UUID, foreign key to users, unique, nullable initially)
- Add relationship to User model
- Keep existing fields:
    - `department_id` (foreign key to departments)
    - `specialization` (doctor's medical specialization)
    - `experience_years` (years of experience)
    - `consultation_fee`, `gender`, `status`, etc.
    - Note: Doctor model already has specialization and experience_years fields
- Add migration to handle existing doctor records

#### 1.5 Update Patient Model (app/apis/patients/models.py)

- Add `user_id` field (UUID, foreign key to users, unique, nullable initially)
- Add relationship to User model
- Keep existing fields:
    - `date_of_birth` (patient's date of birth)
    - `gender` (patient's gender)
    - `address` (patient's address)
- **Add new field**: `blood_type` (String, nullable, use BloodTypeEnum: A+, A-, B+, B-, AB+, AB-, O+, O-)
    - This field is referenced in schemas but missing from the model
- Add CheckConstraint for valid blood types
- Add migration to handle existing patient records

#### 1.6 Database Migration Script

- Create Alembic migration:
    - Create `users` table
    - Create `user_roles` table
    - Create `nurses` table
    - Add `user_id` to `doctors` table
    - Add `user_id` to `patients` table
    - **Add blood_type column to patients table** (String, nullable)
    - Add CheckConstraint for valid blood types: A+, A-, B+, B-, AB+, AB-, O+, O-
    - Migrate existing patient data to `users` table
    - Create foreign key constraints
    - Create indexes on `user_id`, `email`, `user_type`

### Deliverables

- `app/apis/auth/models.py` with User and UserRole models
- `app/apis/nurses/models.py` with Nurse model
- Updated `app/apis/doctors/models.py`
- Updated `app/apis/patients/models.py`
- Alembic migration file
- Database schema documentation

### Testing

- Unit tests for User model creation
- Integration tests for UserRole relationships
- Migration tests to verify data integrity

---

## Phase 2: Authentication System Refactoring

### Objectives

- Refactor authentication to support all user types
- Implement unified login endpoint
- Update JWT token to include role information
- Create role-based authentication dependencies

### Tasks

#### 2.1 Update Auth Schemas (app/apis/auth/schemas.py)

- Create `UserRegisterRequest` (base schema with common fields: email, password, full_name, phone)
- Create `AdminCreateRequest` (for admin creating staff)
- Create `DoctorCreateRequest` (extends UserRegisterRequest, includes: specialization, experience_years, department_id)
- Create `NurseCreateRequest` (extends UserRegisterRequest, includes: employee_id, department_id, shift_type)
- Create `PatientRegisterRequest` (extends UserRegisterRequest, includes: date_of_birth, gender, address, blood_type)
    - Note: blood_type should use BloodTypeEnum (A+, A-, B+, B-, AB+, AB-, O+, O-)
- Create `UserLoginRequest` (unified login schema)
- Update `AuthResponse` to include role information
- Update `UserInfo` to include role and user_type

#### 2.2 Refactor Auth Service (app/apis/auth/services.py)

- Update AuthService class:
    - `register_user()` - unified registration method
    - `register_patient()` - patient self-registration:
        - Creates User record (email, password, full_name, phone, user_type="patient")
        - Creates Patient record (date_of_birth, gender, address, blood_type) linked via user_id
        - Auto-assigns "patient" role via UserRole table
        - Returns combined User and Patient data
    - `create_staff_user()` - admin creates doctor/nurse (assigns role):
        - Creates User record
        - Creates Doctor/Nurse profile record with role-specific fields
        - Assigns appropriate role (doctor/nurse) via UserRole table
    - `login_user()` - unified login that detects user type from role
    - `get_user_by_email()` - retrieve user by email
    - `get_user_by_id()` - retrieve user by ID
    - `assign_role_to_user()` - assign role to existing user
    - `get_user_roles()` - get all roles for a user
- Update password hashing/verification methods

#### 2.3 Update JWT Token Generation (app/security/auth.py)

- Update `create_access_token()` to include:
    - `user_id`
    - `email`
    - `user_type` (admin, doctor, nurse, patient)
    - `role_id` (primary role ID)
    - `role_name` (primary role name)
    - `permissions` (list of permission names for quick access)
- Update `verify_token()` to validate and extract role information
- Create `get_current_user()` dependency that:
    - Validates JWT token
    - Loads user with role and permissions
    - Returns User object with role information

#### 2.4 Create Role-Based Dependencies (app/apis/auth/dependencies.py)

- Create dependency functions:
    - `require_role(role_name: str)` - require specific role
    - `require_any_role(role_names: List[str])` - require any of the roles
    - `require_permission(resource: str, action: str)` - require specific permission
    - `get_current_admin()` - get current admin user
    - `get_current_doctor()` - get current doctor user
    - `get_current_nurse()` - get current nurse user
    - `get_current_patient()` - get current patient user

#### 2.5 Update Auth Routes (app/apis/auth/routes.py)

- **Ensure all endpoints return standardized response format: {data, response, status_code}**
- Update `/register` endpoint:
    - Keep for patient self-registration
    - Auto-assign "patient" role
    - Return response in standardized format
- Create `/login` endpoint:
    - Unified login for all user types
    - Detects user type from role
    - Returns appropriate user profile data
    - Return response in standardized format
- Update `/me` endpoint:
    - Returns user info with role and permissions
    - Returns role-specific profile (doctor/nurse/patient)
    - Return response in standardized format
- Create `/admin/create-staff` endpoint:
    - Admin-only endpoint
    - Creates doctor or nurse user
    - Assigns appropriate role
    - Returns user credentials
    - Return response in standardized format

### Deliverables

- Updated `app/apis/auth/schemas.py`
- Updated `app/apis/auth/services.py`
- Updated `app/security/auth.py`
- New `app/apis/auth/dependencies.py`
- Updated `app/apis/auth/routes.py`
- Updated authentication documentation

### Testing

- Unit tests for unified login
- Unit tests for role assignment
- Integration tests for JWT token with roles
- Test patient self-registration
- Test admin creating staff

---

## Phase 3: Admin Module Implementation

### Objectives

- Create Admin module with CRUD operations
- Implement staff management (create/update/delete doctors and nurses)
- Implement appointment management views
- Implement patient management views
- Add role-based permissions for admin actions

### Tasks

#### 3.1 Create Admin Models (app/apis/admins/models.py)

- Create Admin model (if needed for admin-specific data):
    - `admin_id` (UUID, primary key)
    - `user_id` (UUID, foreign key to users, unique)
    - `employee_id` (unique identifier)
    - `admin_level` (super_admin, admin) - for future hierarchy
    - `created_at`, `updated_at` timestamps
- Add relationship to User model

#### 3.2 Create Admin Schemas (app/apis/admins/schemas.py)

- `AdminBase` - base admin schema
- `AdminCreateRequest` - for creating admin (by another admin)
- `AdminResponse` - admin response schema
- `AdminListResponse` - paginated admin list
- `AdminUpdate` - update admin schema
- `StaffCreateRequest` - for creating doctor/nurse (includes role assignment):
    - For doctors: includes specialization, experience_years, department_id, consultation_fee, gender
    - For nurses: includes employee_id, department_id, shift_type, specialization (optional)
- `StaffResponse` - staff member response
- `StaffListResponse` - paginated staff list

#### 3.3 Create Admin Services (app/apis/admins/services.py)

- `AdminService` class with methods:
    - `create_admin()` - create new admin user
    - `get_admin_by_id()` - get admin by ID
    - `get_all_admins()` - list all admins (paginated)
    - `update_admin()` - update admin information
    - `delete_admin()` - deactivate admin account
    - `create_doctor()` - create doctor user with role assignment:
        - Creates User record
        - Creates Doctor record with: specialization, experience_years, department_id, consultation_fee, gender, etc.
        - Assigns "doctor" role
    - `create_nurse()` - create nurse user with role assignment
    - `get_all_staff()` - list all staff (doctors and nurses)
    - `update_staff()` - update staff information
    - `delete_staff()` - deactivate staff account
    - `get_all_appointments()` - view all appointments
    - `get_appointments_by_date()` - filter appointments by date
    - `get_all_patients()` - list all patients
    - `get_patient_by_id()` - get patient details
    - `update_patient_status()` - activate/deactivate patient

#### 3.4 Create Admin Routes (app/apis/admins/routes.py)

- **All endpoints must return standardized response format: {data, response, status_code}**
- Admin Management:
    - `POST /admins/` - create admin (admin only)
    - `GET /admins/` - list admins (admin only)
    - `GET /admins/{admin_id}` - get admin details
    - `PUT /admins/{admin_id}` - update admin
    - `DELETE /admins/{admin_id}` - deactivate admin
- Staff Management:
    - `POST /admins/staff/doctors` - create doctor (admin only)
    - `POST /admins/staff/nurses` - create nurse (admin only)
    - `GET /admins/staff/` - list all staff (admin only)
    - `GET /admins/staff/doctors` - list all doctors
    - `GET /admins/staff/nurses` - list all nurses
    - `PUT /admins/staff/{staff_id}` - update staff
    - `DELETE /admins/staff/{staff_id}` - deactivate staff
- Appointment Management:
    - `GET /admins/appointments/` - view all appointments (admin only)
    - `GET /admins/appointments/by-date` - filter by date
    - `GET /admins/appointments/{appointment_id}` - get appointment details
- Patient Management:
    - `GET /admins/patients/` - list all patients (admin only)
    - `GET /admins/patients/{patient_id}` - get patient details
    - `PUT /admins/patients/{patient_id}/status` - update patient status

#### 3.5 Update Permissions (app/apis/roles/permissions.py)

- Add admin-specific permissions:
    - `create_admin`, `read_admin`, `update_admin`, `delete_admin`
    - `create_staff`, `read_staff`, `update_staff`, `delete_staff`
    - `read_all_appointments`, `read_all_patients`
    - `manage_patient_status`
- Update `ROLE_PERMISSIONS` dictionary:
    - Add "admin" role with all permissions
    - Ensure admin has all user, role, permission management permissions

#### 3.6 Initialize Admin Role

- Update `init_permissions()` function to:
    - Create "admin" role if not exists
    - Assign all permissions to admin role
    - Create first admin user (seed script)

### Deliverables

- `app/apis/admins/models.py`
- `app/apis/admins/schemas.py`
- `app/apis/admins/services.py`
- `app/apis/admins/routes.py`
- Updated permissions configuration
- Admin seed script
- Admin module documentation

### Testing

- Unit tests for admin CRUD operations
- Unit tests for staff creation
- Integration tests for appointment viewing
- Integration tests for patient management
- Permission tests for admin-only endpoints

---

## Phase 4: Doctor Module Enhancement

### Objectives

- Integrate Doctor model with User authentication
- Add doctor-specific endpoints
- Implement patient assignment logic
- Add prescription management
- Add medical report upload/viewing

### Tasks

#### 4.1 Update Doctor Model Integration

- Ensure `user_id` is properly linked
- Add method to get doctor from `user_id`
- Update doctor creation to create User first

#### 4.2 Create Doctor Schemas (app/apis/doctors/schemas.py - update)

- Add `DoctorUserCreateRequest` - for creating doctor with user account
    - Includes: specialization, experience_years, department_id (these fields already exist in Doctor model)
- Add `DoctorProfileResponse` - includes user info and doctor-specific fields (specialization, experience_years, etc.)
- Add `AssignedPatientResponse` - patient assigned to doctor
- Add `PrescriptionCreate` - prescription schema
- Add `PrescriptionResponse` - prescription response
- Add `MedicalReportUpload` - report upload schema
- Add `MedicalReportResponse` - report response

#### 4.3 Create Prescription Model (app/apis/prescriptions/models.py)

- Create Prescription model:
    - `prescription_id` (UUID, primary key)
    - `doctor_id` (UUID, foreign key to doctors)
    - `patient_id` (UUID, foreign key to patients)
    - `appointment_id` (UUID, foreign key to appointments, optional)
    - `medication_name` (string)
    - `dosage` (string)
    - `frequency` (string)
    - `duration` (string)
    - `instructions` (text)
    - `prescribed_date` (date)
    - `status` (active, completed, cancelled)
    - `created_at`, `updated_at` timestamps

#### 4.4 Create Medical Report Model (app/apis/reports/models.py)

- Create MedicalReport model:
    - `report_id` (UUID, primary key)
    - `doctor_id` (UUID, foreign key to doctors)
    - `patient_id` (UUID, foreign key to patients)
    - `appointment_id` (UUID, foreign key to appointments, optional)
    - `report_type` (lab_result, imaging, diagnosis, other)
    - `report_title` (string)
    - `file_path` (string, for uploaded files)
    - `file_url` (string, for cloud storage)
    - `description` (text)
    - `report_date` (date)
    - `created_at`, `updated_at` timestamps

#### 4.5 Update Doctor Services (app/apis/doctors/services.py)

- Add methods:
    - `get_doctor_by_user_id()` - get doctor from user_id
    - `get_assigned_patients()` - get patients assigned to doctor
    - `get_doctor_appointments()` - get doctor's appointments
    - `get_upcoming_appointments()` - get upcoming appointments
    - `create_prescription()` - add prescription for patient
    - `get_patient_prescriptions()` - get prescriptions for patient
    - `upload_medical_report()` - upload report for patient
    - `get_patient_reports()` - get reports for patient

#### 4.6 Create Prescription Services (app/apis/prescriptions/services.py)

- `PrescriptionService` class:
    - `create_prescription()`
    - `get_prescription_by_id()`
    - `get_prescriptions_by_patient()`
    - `get_prescriptions_by_doctor()`
    - `update_prescription()`
    - `delete_prescription()`

#### 4.7 Create Report Services (app/apis/reports/services.py)

- `ReportService` class:
    - `upload_report()` - handle file upload
    - `get_report_by_id()`
    - `get_reports_by_patient()`
    - `get_reports_by_doctor()`
    - `delete_report()`
    - `download_report()` - serve file

#### 4.8 Update Doctor Routes (app/apis/doctors/routes.py)

- **All endpoints must return standardized response format: {data, response, status_code}**
- Add doctor-specific endpoints:
    - `GET /doctors/me/patients` - get assigned patients (doctor only)
    - `GET /doctors/me/appointments` - get my appointments
    - `GET /doctors/me/appointments/upcoming` - get upcoming appointments
    - `POST /doctors/prescriptions/` - create prescription (doctor only)
    - `GET /doctors/prescriptions/patient/{patient_id}` - get patient prescriptions
    - `POST /doctors/reports/upload` - upload medical report (doctor only)
    - `GET /doctors/reports/patient/{patient_id}` - get patient reports
    - `GET /doctors/reports/{report_id}/download` - download report

#### 4.9 Update Permissions

- Add doctor permissions:
    - `read_assigned_patients`
    - `read_own_appointments`
    - `create_prescription`
    - `read_prescription`
    - `upload_report`
    - `read_report`
- Update `ROLE_PERMISSIONS` for "doctor" role

### Deliverables

- Updated `app/apis/doctors/models.py`
- Updated `app/apis/doctors/schemas.py`
- Updated `app/apis/doctors/services.py`
- Updated `app/apis/doctors/routes.py`
- `app/apis/prescriptions/models.py`
- `app/apis/prescriptions/services.py`
- `app/apis/prescriptions/routes.py`
- `app/apis/reports/models.py`
- `app/apis/reports/services.py`
- `app/apis/reports/routes.py`
- Updated permissions
- Doctor module documentation

### Testing

- Unit tests for doctor-user integration
- Unit tests for prescription management
- Unit tests for report upload
- Integration tests for patient assignment
- Permission tests for doctor endpoints

---

## Phase 5: Nurse Module Implementation

### Objectives

- Create Nurse module with CRUD operations
- Implement patient assignment logic
- Add observation/note logging
- Add report viewing capabilities

### Tasks

#### 5.1 Create Nurse Schemas (app/apis/nurses/schemas.py)

- `NurseBase` - base nurse schema
- `NurseCreateRequest` - for creating nurse (admin only)
- `NurseResponse` - nurse response schema
- `NurseListResponse` - paginated nurse list
- `NurseUpdate` - update nurse schema
- `PatientObservationCreate` - observation schema
- `PatientObservationResponse` - observation response
- `AssignedPatientResponse` - patient assigned to nurse

#### 5.2 Create Observation Model (app/apis/observations/models.py)

- Create PatientObservation model:
    - `observation_id` (UUID, primary key)
    - `nurse_id` (UUID, foreign key to nurses)
    - `patient_id` (UUID, foreign key to patients)
    - `room_number` (string, optional)
    - `observation_type` (vital_signs, general, medication, other)
    - `observation_text` (text)
    - `vital_signs` (JSON, for structured vital data)
    - `observation_date` (datetime)
    - `created_at`, `updated_at` timestamps

#### 5.3 Create Nurse Services (app/apis/nurses/services.py)

- `NurseService` class:
    - `create_nurse()` - create nurse user (admin only)
    - `get_nurse_by_id()`
    - `get_nurse_by_user_id()` - get nurse from user_id
    - `get_all_nurses()` - list all nurses
    - `update_nurse()` - update nurse information
    - `delete_nurse()` - deactivate nurse
    - `get_assigned_patients()` - get patients assigned to nurse
    - `add_observation()` - log patient observation
    - `get_patient_observations()` - get observations for patient
    - `get_patient_reports()` - view patient reports (read-only)

#### 5.4 Create Observation Services (app/apis/observations/services.py)

- `ObservationService` class:
    - `create_observation()`
    - `get_observation_by_id()`
    - `get_observations_by_patient()`
    - `get_observations_by_nurse()`
    - `update_observation()`
    - `delete_observation()`

#### 5.5 Create Nurse Routes (app/apis/nurses/routes.py)

- **All endpoints must return standardized response format: {data, response, status_code}**
- Nurse Management (Admin only):
    - `POST /nurses/` - create nurse
    - `GET /nurses/` - list all nurses
    - `GET /nurses/{nurse_id}` - get nurse details
    - `PUT /nurses/{nurse_id}` - update nurse
    - `DELETE /nurses/{nurse_id}` - deactivate nurse
- Nurse Operations (Nurse only):
    - `GET /nurses/me/patients` - get assigned patients
    - `POST /nurses/observations/` - add observation
    - `GET /nurses/observations/patient/{patient_id}` - get patient observations
    - `GET /nurses/reports/patient/{patient_id}` - view patient reports (read-only)

#### 5.6 Update Permissions

- Add nurse permissions:
    - `read_assigned_patients`
    - `create_observation`
    - `read_observation`
    - `update_observation`
    - `read_patient_reports` (read-only)
- Update `ROLE_PERMISSIONS` for "nurse" role

### Deliverables

- `app/apis/nurses/models.py`
- `app/apis/nurses/schemas.py`
- `app/apis/nurses/services.py`
- `app/apis/nurses/routes.py`
- `app/apis/observations/models.py`
- `app/apis/observations/services.py`
- `app/apis/observations/routes.py`
- Updated permissions
- Nurse module documentation

### Testing

- Unit tests for nurse CRUD operations
- Unit tests for observation logging
- Integration tests for patient assignment
- Permission tests for nurse endpoints
- Test report viewing permissions

---

## Phase 6: Patient Module Updates

### Objectives

- Update Patient module to use User model
- Ensure patient can view own prescriptions and reports
- Update appointment booking to work with new structure

### Tasks

#### 6.1 Update Patient Model Integration

- Ensure `user_id` is properly linked
- Update patient creation to create User first
- Update patient queries to join with User

#### 6.2 Update Patient Services (app/apis/patients/services.py)

- Update methods to use User model
- Add methods:
    - `get_patient_by_user_id()` - get patient from user_id
    - `get_my_prescriptions()` - get patient's own prescriptions
    - `get_my_reports()` - get patient's own reports
    - `get_my_appointments()` - get patient's appointments

#### 6.3 Update Patient Routes (app/apis/patients/routes.py)

- **All endpoints must return standardized response format: {data, response, status_code}**
- Update existing routes to use User authentication
- Add patient-specific endpoints:
    - `GET /patients/me/prescriptions` - get my prescriptions (patient only)
    - `GET /patients/me/reports` - get my reports (patient only)
    - `GET /patients/me/appointments` - get my appointments
    - `GET /patients/me/appointments/upcoming` - get upcoming appointments

#### 6.4 Update Patient Permissions

- Ensure patient has:
    - `read_own_prescriptions`
    - `read_own_reports`
    - `read_own_appointments`
    - `create_appointment`
- Update `ROLE_PERMISSIONS` for "patient" role

### Deliverables

- Updated `app/apis/patients/models.py`
- Updated `app/apis/patients/services.py`
- Updated `app/apis/patients/routes.py`
- Updated permissions
- Patient module update documentation

### Testing

- Unit tests for patient-user integration
- Integration tests for prescription viewing
- Integration tests for report viewing
- Permission tests for patient endpoints

---

## Phase 7: Permission System Integration

### Objectives

- Fully integrate permission system with all modules
- Add permission checks to all routes
- Create permission initialization script
- Add permission-based route protection

### Tasks

#### 7.1 Update All Routes with Permission Checks

- Update all admin routes to use `require_create_admin()`, etc.
- Update all doctor routes to use `require_create_prescription()`, etc.
- Update all nurse routes to use `require_create_observation()`, etc.
- Update all patient routes to use `require_read_own_prescriptions()`, etc.

#### 7.2 Create Permission Initialization Script

- Create `scripts/init_permissions.py`:
    - Initialize all permissions
    - Create default roles (admin, doctor, nurse, patient)
    - Assign permissions to roles
    - Create first admin user
    - Log initialization results

#### 7.3 Update Permission Dependencies

- Ensure all permission dependencies are properly implemented
- Add permission caching for performance
- Add permission validation in middleware

#### 7.4 Create Permission Testing Utilities

- Create test helpers for permission testing
- Add permission test fixtures
- Create permission validation tests

### Deliverables

- Updated all route files with permission checks
- `scripts/init_permissions.py`
- Updated permission dependencies
- Permission testing utilities
- Permission integration documentation

### Testing

- Permission tests for all endpoints
- Integration tests for role-based access
- Performance tests for permission checking

---

## Phase 8: Database Migrations and Data Migration

### Objectives

- Create comprehensive database migrations
- Migrate existing data to new schema
- Ensure data integrity
- Create rollback procedures

### Tasks

#### 8.1 Create Migration Scripts

- Create Alembic migration for Phase 1 (User model)
- Create migration for Phase 3 (Admin model)
- Create migration for Phase 4 (Prescription, Report models)
- Create migration for Phase 5 (Observation model)
- Create data migration script for existing patients
- Create data migration script for existing doctors

#### 8.2 Data Migration Strategy

- Migrate existing patients:
    - Create User record for each patient
    - Link patient to user via `user_id`
    - Assign "patient" role
    - Preserve all existing data
- Migrate existing doctors:
    - Create User record for each doctor
    - Link doctor to user via `user_id`
    - Assign "doctor" role
    - Preserve all existing data

#### 8.3 Create Rollback Procedures

- Document rollback steps
- Create rollback migration scripts
- Test rollback procedures

### Deliverables

- All Alembic migration files
- Data migration scripts
- Rollback procedures documentation
- Migration testing results

### Testing

- Test migrations on development database
- Test data integrity after migration
- Test rollback procedures
- Performance tests for large data sets

---

## Phase 9: API Integration and Route Registration

### Objectives

- Register all new routes in main application
- Update API documentation
- Create API versioning if needed
- Update CORS and middleware configuration
- Ensure all endpoints follow standardized response format

### Tasks

#### 9.1 Update Response Schema (app/core/response_schemas.py)

- Update or create response schema to match required format:

JSON

```
{
  "data": "string | object | array | null",
  "response": "string",
  "status_code": 0
}
```

- Create helper functions:
    - `create_standard_response(data, response, status_code)` - main helper
    - `create_success_response(data, response, status_code)` - for success responses
    - `create_error_response(response, status_code, data=None)` - for error responses
    - `Notes_response(items, response, status_code)` - for list responses
    - `create_paginated_response(items, total, page, size, response, status_code)` - for paginated responses
- Update existing response helpers if they use "message" instead of "response"
- Ensure all response schemas use `response` field (not message)

#### 9.2 Update Main Application (main.py)

- Register admin router: `app.include_router(admin_router, prefix="/api/admins", tags=["admins"])`
- Register nurse router: `app.include_router(nurse_router, prefix="/api/nurses", tags=["nurses"])`
- Register prescription router: `app.include_router(prescription_router, prefix="/api/prescriptions", tags=["prescriptions"])`
- Register report router: `app.include_router(report_router, prefix="/api/reports", tags=["reports"])`
- Register observation router: `app.include_router(observation_router, prefix="/api/observations", tags=["observations"])`
- Register roles router: `app.include_router(role_router, prefix="/api/roles", tags=["roles"])`
- Register permissions router: `app.include_router(permission_router, prefix="/api/permissions", tags=["permissions"])`

#### 9.3 Update API Documentation

- Update OpenAPI/Swagger documentation
- Add role-based endpoint descriptions
- Add permission requirements to endpoint docs
- **Document standardized response format** with examples
- Create API usage examples showing response format
- Add response format to API documentation header/overview

#### 9.4 Update Constants (app/core/constants.py)

- Add new user type constants
- Add new role constants
- Add new permission constants
- Add error messages for RBAC

### Deliverables

- Updated `app/core/response_schemas.py` with standardized format
- Updated `main.py`
- Updated API documentation with response format examples
- Updated constants file
- API integration documentation
- Response format validation tests

### Testing

- Test all routes are accessible
- Test API documentation accuracy
- **Test all endpoints return standardized response format**
- **Validate response structure matches {data, response, status_code}**
- Test CORS configuration
- Test middleware functionality

---

## Phase 10: Testing and Quality Assurance

### Objectives

- Comprehensive testing of all modules
- Performance testing
- Security testing
- User acceptance testing

### Tasks

#### 10.1 Unit Testing

- Test all models
- Test all services
- Test all schemas
- Test authentication flows
- Test permission checking

#### 10.2 Integration Testing

- Test user registration flows
- Test login flows for all user types
- Test role assignment
- Test permission enforcement
- Test CRUD operations for all modules
- Test file uploads (reports)

#### 10.3 Security Testing

- Test authentication bypass attempts
- Test permission escalation attempts
- Test SQL injection prevention
- Test XSS prevention
- Test CSRF protection
- Test JWT token security

#### 10.4 Performance Testing

- Test database query performance
- Test permission checking performance
- Test concurrent user access
- Test large data set handling

#### 10.5 User Acceptance Testing

- Test admin workflows
- Test doctor workflows
- Test nurse workflows
- Test patient workflows
- Test error handling

### Deliverables

- Complete test suite
- Test coverage report
- Security audit report
- Performance test results
- UAT results

### Testing

- All tests passing
- Minimum 80% code coverage
- No critical security vulnerabilities
- Performance benchmarks met

---

## Phase 11: Documentation and Deployment

### Objectives

- Complete all documentation
- Create deployment guides
- Create user guides
- Prepare for production deployment

### Tasks

#### 11.1 Technical Documentation

- Update `README.md` with new structure
- Create API documentation
- Create database schema documentation
- Create deployment guide
- Create migration guide

#### 11.2 User Documentation

- Create admin user guide
- Create doctor user guide
- Create nurse user guide
- Create patient user guide
- Create API usage examples

#### 11.3 Deployment Preparation

- Create production environment configuration
- Create deployment scripts
- Create health check endpoints
- Create monitoring setup
- Create backup procedures

#### 11.4 Training Materials

- Create training slides
- Create video tutorials
- Create FAQ document
- Create troubleshooting guide

### Deliverables

- Complete documentation set
- Deployment guides
- User guides
- Training materials
- Production deployment checklist

---

## Implementation Timeline

### Estimated Duration: 8-10 weeks

- **Phase 1**: 1 week
- **Phase 2**: 1 week
- **Phase 3**: 1.5 weeks
- **Phase 4**: 1.5 weeks
- **Phase 5**: 1 week
- **Phase 6**: 0.5 weeks
- **Phase 7**: 1 week
- **Phase 8**: 0.5 weeks
- **Phase 9**: 0.5 weeks
- **Phase 10**: 1 week
- **Phase 11**: 0.5 weeks

## Risk Mitigation

### Identified Risks

1.  **Data Migration Complexity**: Migrating existing patient/doctor data to User model
    - Mitigation: Create comprehensive migration scripts, test on staging first
2.  **Permission Performance**: Permission checking may slow down API
    - Mitigation: Implement permission caching, optimize queries
3.  **Role Assignment Errors**: Incorrect role assignment during user creation
    - Mitigation: Add validation, create audit logs
4.  **Breaking Changes**: Changes may break existing functionality
    - Mitigation: Maintain backward compatibility where possible, comprehensive testing

## Success Criteria

1.  All user types (Admin, Doctor, Nurse, Patient) can authenticate
2.  Role-based permissions are enforced on all endpoints
3.  Admin can create and manage staff (doctors and nurses)
4.  Doctors can manage prescriptions and upload reports
5.  Nurses can log observations and view reports
6.  Patients can view their own prescriptions and reports
7.  All existing functionality remains intact
8.  Test coverage > 80%
9.  All security vulnerabilities addressed
10. Documentation is complete and accurate

## Post-Implementation

### Future Enhancements

1.  Multi-role support (users with multiple roles)
2.  Role hierarchy (senior doctor, junior doctor)
3.  Department-based permissions
4.  Audit logging for all admin actions
5.  Two-factor authentication
6.  Password reset functionality
7.  Email notifications for role assignments
8.  Advanced reporting and analytics

## API Response Format Standard

### Mandatory Response Structure

**All API endpoints must return responses in the following standardized format:**

JSON

```
{
  "data": "string | object | array | null",
  "response": "string",
  "status_code": 0
}
```

### Field Descriptions

- **data**: The actual response data. Can be:
    - A string (for simple messages)
    - An object (for single resource responses)
    - An array (for list responses)
    - A nested object (for paginated responses with metadata)
    - `null` (for error responses without data)
- **response**: Human-readable message describing the result (e.g., "User created successfully", "Invalid credentials")
- **status_code**: HTTP status code as integer (e.g., 200, 201, 400, 401, 404, 500)

### Examples

**Success Response (Single Resource):**

JSON

```
{
  "data": {
    "user_id": "123e4567-e89b-12d3-a456-426614174000",
    "email": "user@example.com",
    "full_name": "John Doe"
  },
  "response": "User retrieved successfully",
  "status_code": 200
}
```

**Success Response (List):**

JSON

```
{
  "data": [
    {"user_id": "...", "email": "..."},
    {"user_id": "...", "email": "..."}
  ],
  "response": "Users retrieved successfully",
  "status_code": 200
}
```

**Error Response:**

JSON

```
{
  "data": null,
  "response": "User not found",
  "status_code": 404
}
```

### Implementation Requirements

- All endpoints must use this response format
- Update existing endpoints to match this format (if different)
- Use helper functions from `app/core/response_schemas.py` or create new ones if needed
- Ensure consistent error responses follow the same format
- All route handlers should return `StandardResponse` or equivalent schema

## Notes

- All code should follow existing project structure and conventions
- Use existing logging and error handling patterns
- Maintain backward compatibility where possible
- All database changes should be through Alembic migrations
- **All API endpoints must follow the standardized response format: {data, response, status_code}**
- All new models should include proper relationships and constraints
- All services should include proper error handling
- All routes should include proper permission checks