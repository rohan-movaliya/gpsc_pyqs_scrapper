# Questions And Reminders

- Do admin have permission to change the status of a patient to inactive and active?
- Can doctor and nurse update their own profile, because the admin created their profile.
- Change project settings to fast forward merger to enable rebase(https://gitlab.inexture.com/ai.inexture/chatbot-voice-agent)