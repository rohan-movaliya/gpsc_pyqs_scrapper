# Technical Document

### 🖥️ **Backend Technologies**

| Component | Description |
| --- | --- |
| **Framework** | FastAPI with Uvicorn (ASGI) |
| **Real-Time Transport** | Twilio Voice API (HTTP webhooks + TwiML) |
| **Cache / Rate Limiting** | Redis with optional in-memory fallback |
| **Database** | PostgreSQL (structured) + MongoDB (conversational data) |
| **ORM Layer** | SQLAlchemy 2.0 (sync) for PostgreSQL, Motor (async) for MongoDB |
| **Security Layer** | JWT authentication, RBAC policies, audit logging |
| **Configuration** | Environment settings via python-dotenv + Pydantic |
| **Artificial Intelligence** | LangGraph multi-agent system, OpenAI/Groq LLMs |
| **Voice Integration** | Twilio speech-to-text, text-to-speech, call management |
| **Vector Search** | pgvector extension for semantic symptom-doctor matching |

---

### 🧪 **Testing & Configuration**

| Component | Purpose |
| --- | --- |
| **pytest / pytest-asyncio / pytest-cov** | Unit + integration testing |
| **httpx** | Async API testing client |
| **python-dotenv** | Environment variable management |
| **Structured Constants** | Centralized configuration in `app/core/constants.py` |
| **Alembic** | PostgreSQL schema migrations |
| **Motor** | Async MongoDB interaction and pooling |

---

### 🗄️ **Data Storage**

| Store | Usage |
| --- | --- |
| **PostgreSQL (SQLAlchemy)** | Appointments, doctors, patients, roles, permissions, schedules |
| **MongoDB (Motor)** | Chat sessions, messages, histories, metadata |
| **Redis** | Caching, rate limiting, transient sessions, optional pub/sub |
| **pgvector** | Doctor-specialization embeddings + semantic search |

---

## **Core Features**

---

### 🔐 **Authentication & Authorization**

- Secure login with token issuance + validation
- JWT-based access tokens with configurable TTL
- RBAC permission enforcement via role mapping
- Protected API access via FastAPI dependencies
- Audit logging for compliance and traceability
- Session scoping for voice and chat interactions

---

### 🎤 **Voice & Call Management**

- Unified call lifecycle via `app/apis/voice/services.py`
- Inbound/outbound call handling through Twilio
- Transcription-driven speech events routed to backend
- Multi-agent AI processing for contextual replies
- In-memory session tracking (call_sid → history)
- Resilient Twilio API interactions with retry policies

---

### 🤖 **Multi-Agent AI System**

- **Supervisor Agent** for intent detection and routing
- **Booking Agent** for appointment lifecycle operations
- **Patient Agent** for patient-centric information queries
- **Doctor Agent** for search, schedules, and department insights
- **State management** through LangGraph StateGraph
- **Controlled tool access** via permission-bound utilities

---

### 💬 **Session & Chat Management**

- Conversation lifecycle managed via MongoDB
- Session creation, message persistence, history retrieval
- Indexed queries for performance (user_id, session_id, timestamps)
- AI-powered conversation title generation
- Voice-chat synchronization via thread mapping

---

### 📅 **Appointment Management**

- CRUD operations for appointments
- Slot availability enforcement with business hour checks
- Doctor–patient relationship mapping
- Appointment statuses: scheduled, completed, canceled, rescheduled
- Notifications infrastructure ready for reminders
- Multi-department scheduling support

---

### 👨‍⚕️ **Doctor & Patient Management**

- Doctor profiles, schedules, departments
- Patient data with emergency contacts and insurance
- Semantic doctor recommendation via vector embeddings
- Filtering, search, and pagination support
- Department-level routing for specialty matching

---

### ✉️ **Message Processing**

- Store-and-forward architecture backed by MongoDB
- AI responses generated via multi-agent execution
- Pydantic-based message validation
- Multilingual pipeline ready for future enablement
- Context-aware, history-driven response generation

---

### 🔒 **Security & Compliance**

- JWT token validation
- Redis-based rate limiting
- Pydantic schema validation
- Standardized error handling
- Audit logging for compliance
- Secure handling of sensitive data (PII-safe logs)

---

## ⚡ **System Workflow**

1.  User authenticates and receives JWT token
2.  Voice call initiated (inbound/outbound) → Twilio webhook triggers
3.  Twilio transcribes speech → Backend receives speech event
4.  Supervisor Agent classifies intent → Routes to specialized agent
5.  Agent performs operations via database tools
6.  LLM generates response → Twilio converts to speech
7.  Conversation history stored in MongoDB
8.  Appointment operations executed in PostgreSQL
9.  Session cleanup on disconnect

---

## 🔁 **Realtime Processing Flow**

| Layer | Responsibility |
| --- | --- |
| **Voice Gateway** | Handles Twilio webhooks, validates signatures, generates TwiML |
| **Voice Service** | Manages call lifecycle, speech events, Twilio operations |
| **Agent Graph** | Orchestrates multi-agent execution and state transitions |
| **Supervisor Agent** | Intent detection + agent routing |
| **Specialized Agents** | Booking/Doctor/Patient domain execution |
| **Database Tools** | Controlled PostgreSQL operations |
| **Chat Service** | MongoDB session + message persistence |
| **Appointment Service** | Appointment CRUD, slot checks |
| **Auth Service** | Token lifecycle + identity management |
| **Patient/Doctor Services** | Healthcare entity CRUD and search |

---

## 🧱 **Key Architectural Highlights**

- Modular, layered service architecture
- Fully asynchronous FastAPI + Motor stack
- Supervisor-driven multi-agent coordination
- Enterprise security posture: JWT, RBAC, rate limiting
- Hybrid database model (PostgreSQL + MongoDB)
- Vector semantic search via pgvector
- Twilio-native voice-first design
- Dockerized, environment-driven configuration
- Stateful, context-aware conversation management
- Tool-based agent design with controlled operations