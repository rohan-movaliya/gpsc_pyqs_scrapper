# Deadlines for each module

Admin:- dec 9

doctor:- dec 10 to dec 12

nurse:- dec 15 to 16

patient:- dec 17 to 19