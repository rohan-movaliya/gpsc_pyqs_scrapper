# AI_Kosh : Problem statement-1

#   
<br/>**AI-ENABLED VIRTUAL NEGOTIATION ASSISTANCE** 

**Process Documentation & Transformation Narrative** 

_(Problem Statement 1 – MSME ODR)_ 

### **Index**

1. Purpose of This Document

2\. Background: MSME Delayed Payment Disputes 

3\. Current Working Process (As-Is State) 

4\. Key Problems in the Current Process

5\. AI-Enabled Target Working Process (To-Be State) 

6\. AI-Enabled End-to-End Workflow  \[Still in assumption\]

7\. Impact Assessment 

8\. Governance, Compliance & Trust 

9\. Summary: Process Transformation 

10\. Final Statement 

## **1\. Purpose of This Document** 

This document describes: 

- The **current operational process** for delayed payment disputes faced by MSMEs 

- The **structural inefficiencies** in the existing workflow 

- The **AI-enabled target process** 

- How AI introduces **speed, accuracy, and early resolution** 

- Why the proposed system is **scalable, compliant, and trustworthy** 

 

## **2\. Background: MSME Delayed Payment Disputes** 

Micro, Small, and Medium Enterprises (MSMEs) frequently experience delayed payments from buyers due to administrative delays, power asymmetry, and lack of enforceability.   
While statutory mechanisms exist, practical resolution remains slow and resource intensive. 

To address this, the Government introduced an **Online Dispute Resolution (ODR)** portal with an optional **pre-MSEFC digital negotiation stage**. 

However, the current ODR process remains largely manual and reactive. 

 

## **3\. Current Working Process (As-Is State)** 

**3.1 Step-by-Step Workflow** 

**Step 1: Payment Delay Occurs** 

- MSME delivers goods or services 

- Invoice is raised with agreed payment terms 

- Buyer fails to make payment within agreed or statutory period 

 

**Step 2: MSME Files Complaint on ODR Portal** 

- MSME manually fills digital forms 

- Uploads supporting documents (invoices, contracts, emails, etc.) 

- Inputs are often: 

- Incomplete 

- Unstructured 

- Written in local languages or informal terms 

 

**Step 3: Optional Digital Negotiation Stage** 

- Platform allows buyer and MSME to exchange messages 

- Negotiation is: 

- Unguided 

- Non-standardized 

- Dependent on user understanding of law 

 

**Step 4: Manual Review by Officials / Mediators** 

- Human reviewers: 

- Read claims and documents 

- Identify missing information 

- Classify dispute types manually 

 

**Step 5: Escalation to MSEFC (If No Settlement)** 

- Case moves to formal conciliation or arbitration 

- Requires additional documentation and hearings 

- Resolution timelines increase significantly 

 

## **4\. Key Problems in Current Process** 

**4.1 Input Quality Issues** 

- MSMEs struggle with legal drafting 

- Errors at submission stage weaken valid claims 

- Missing documents cause repeated back-and-forth 

 

**4.2 Absence of Case Intelligence** 

- System does not understand: 

- Dispute nature 

- Legal strength 

- Completeness of evidence 

- All cases treated uniformly, regardless of merit 

 

**4.3 Ineffective Negotiation** 

- Parties negotiate without: 

- Legal guidance 

- Precedent awareness 

- Realistic settlement expectations 

- Leads to deadlocks and escalation 

 

**4.4 High Human Dependency** 

- Manual verification does not scale 

- Inconsistent handling across cases 

- Administrative backlogs increase 

 

**4.5 Delayed Containment** 

- Disputes that could settle early escalate unnecessarily 

- MSMEs suffer liquidity stress 

- Government resources are over-utilized 

 

## **5\. AI-Enabled Target Working Process (To-Be State)** 

**Objective** 

Transform ODR from a **digital filing system** into an **intelligent dispute processing and negotiation containment platform**. 

 

## **6\. AI-Enabled End-to-End Workflow** 

**Step 1: Intelligent Dispute Intake** 

**Current** 

- Manual form filling 

- High error rate 

**With AI** 

- MSME can: 

- Speak in preferred language 

- Upload documents in any format 

- AI automatically: 

- Converts voice to text 

- Translates to standard legal language 

- Extracts key entities 

- Auto-populates forms 

**Outcome** 

- Faster filing 

- Higher accuracy 

- Reduced literacy barriers 

 

**Step 2: Automated Case Structuring** 

**Current** 

- No automated validation 

- Human review required 

**With AI** 

- System: 

- Classifies dispute type 

- Detects missing or inconsistent documents 

- Flags legal and procedural gaps 

- Scores case completeness 

**Outcome** 

- Clean, standardized cases 

- Reduced manual scrutiny 

 

**Step 3: Legal & Outcome Intelligence** 

**Current** 

- No predictive support 

- Users negotiate blindly 

**With AI** 

- Rule engine applies statutory provisions 

- ML models: 

- Estimate settlement likelihood 

- Predict escalation risk 

- Suggest realistic settlement ranges 

**Outcome** 

- Fact-based negotiation 

- Reduced unrealistic claims 

 

**Step 4: AI-Guided Negotiation** 

**Current** 

- Free-text, unstructured messaging 

**With AI** 

- Structured negotiation flow: 

- Guided options 

- Legal prompts 

- Risk alerts 

- AI: 

- Tracks offer/counter-offer patterns 

- Detects deadlocks 

- Nudges toward early settlement 

**Outcome** 

- Faster negotiations 

- Lower escalation rate 

 

**Step 5: Automated Output Generation** 

**Current** 

- Re-documentation needed at each stage 

**With AI** 

- System auto-generates: 

- Settlement agreements 

- Case summaries 

- Escalation-ready dossiers 

**Outcome** 

- Zero rework 

- Seamless transition if escalation is required 

 

## **7\. Impact Assessment** 

**7.1 Efficiency Gains** 

- Reduced filing time 

- Shorter negotiation cycles 

- Lower officer workload 

 

**7.2 MSME Benefits** 

- Easier access to justice 

- Reduced legal cost 

- Faster cash flow recovery 

 

**7.3 Government Benefits** 

- Scalable dispute handling 

- Reduced MSEFC burden 

- Improved trust in digital governance 

 

## **8\. Governance, Compliance & Trust** 

- AI operates within legal boundaries 

- Human oversight at all decision points 

- Full audit logs maintained 

- Data stored and processed within Government-approved infrastructure 

- Explainable and reviewable AI outputs 

 

## **9\. Summary: Process Transformation** 

|     |     |     |
| --- | --- | --- |
| **Aspect** | **Current Process** | **AI-Enabled Process** |
| Data Entry | Manual | Voice + Automated |
| Case Understanding | Human-dependent | AI-driven |
| Negotiation | Unguided | Structured & Legal |
| Resolution Speed | Slow | Accelerated |
| Scalability | Limited | National-scale |

 

## **10\. Final Statement** 

This AI-enabled system does not replace legal authorities.   
It **strengthens the ODR framework** by converting informal disputes into **structured, legally sound, settlement-ready cases**, enabling faster and fairer outcomes for MSMEs and efficient governance for the State.