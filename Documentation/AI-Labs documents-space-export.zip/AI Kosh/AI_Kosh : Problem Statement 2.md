# AI_Kosh : Problem Statement 2

## **AI-Powered MSE Agent Mapping Tool**

### **Clear Explanation of Terms, Current Flow, and Problem Needs**

---

## **1\. Purpose of the Problem Statement**

The objective of **Problem Statement 2** is to **streamline and scale the onboarding of Micro and Small Enterprises (MSEs) onto ONDC** by reducing manual effort, incorrect data entry, and verification delays through intelligent, AI-driven assistance.

This problem focuses on improving how MSEs are:

- Registered on ONDC
- Categorised by sector and product
- Mapped to suitable Seller Network Participants (SNPs)
- Verified by NSIC under the TEAM initiative

---

## **2\. Key Terms and Their Meaning**

### **Micro and Small Enterprise (MSE)**

An MSE is a micro or small business registered under the MSME framework. Most MSEs:

- Operate offline
- Have limited digital literacy
- Are unfamiliar with online marketplaces

---

### **Open Network for Digital Commerce (ONDC)**

ONDC is a government-backed open digital commerce network that allows buyers and sellers to transact through multiple applications instead of a single private platform.

MSEs **cannot directly onboard** to ONDC without technical and operational support.

---

### **Seller Network Participant (SNP)**

An SNP is an intermediary organisation that helps MSEs:

- Register on ONDC
- Create digital product catalogues
- Enable digital payments
- Integrate logistics and delivery

SNPs act as the **operational interface** between MSEs and ONDC.

---

### **National Small Industries Corporation (NSIC)**

NSIC is the government entity responsible for:

- Verifying MSE authenticity
- Validating product categorisation
- Ensuring correct SNP–MSE mapping under the TEAM initiative  
    

NSIC acts as the **final verification authority** before an MSE is considered properly onboarded.

---

### **TEAM Initiative**

The Trade Enablement and Marketing (TEAM) initiative is a government program to onboard MSEs onto ONDC in a structured and trusted manner.

---

## **3\. Traditional (Current) Onboarding Flow**

The existing onboarding process is **multi-step and time-distributed**, involving multiple stakeholders.

---

## **4\. How the Process Starts – Role of the SNP**

When an MSE decides to sell online, it **first approaches an SNP**.  
The MSE does not interact directly with ONDC systems.

The SNP then handles the complete onboarding process on behalf of the MSE.

---

## **5\. Detailed SNP Registration Workflow (As-Is Process)**

### **Step 1: Basic Business Information Collection**

The SNP collects:

- Business name
- Owner name
- Contact details
- Business address
- Type of business (manufacturer or trader)  
    <br/>

This information is usually:

- Verbal
- Shared informally
- Unstructured  
    <br/>

---

### **Step 2: Business Identity and Financial Details**

The SNP manually enters and uploads:

- Udyam registration number
- PAN
- GST (if applicable)
- Bank account details

---

### **Step 3: MSE Category and Sector Selection**

The SNP selects:

- MSE classification (Micro or Small)
- Business sector such as handicrafts, textiles, or engineering goods  
    

This decision is based on:

- Interpretation of informal descriptions
- SNP staff understanding
- No system-driven guidance  
    

This step is a **major source of errors**.

---

### **Step 4: Product Catalogue Creation**

The SNP converts informal product details into a structured catalogue:

- Product names
- Product categories (ONDC taxonomy)
- Attributes (material, size, usage, etc.)
- Images
- Pricing and inventory

This is the **most error-prone step**, as incorrect categorisation or missing attributes often occur.

---

### **Step 5: Logistics and Payment Setup**

The SNP configures:

- Digital payment methods
- Logistics partners
- Return and cancellation policies  
    <br/>

This step is relatively standardized and less problematic.

---

### **Step 6: Submission for Verification**

The completed application is submitted and sent to NSIC for verification under the TEAM workflow.

---

## **6\. Problems Faced by SNPs**

SNPs face the following challenges:

- Heavy dependence on manual data entry
- Difficulty in identifying correct MSE categories
- Challenges in creating accurate product catalogues
- Errors are detected only after submission
- High rework due to rejections  
    <br/>

---

## **7\. NSIC Verification Workflow (As-Is Process)**

After submission, NSIC conducts a **manual verification process**.

---

### **Step 1: Application Intake**

- Application is received
- Case ID is created
- Assigned to a verification officer

---

### **Step 2: Business Authenticity Verification**

NSIC verifies:

- Udyam registration validity
- Consistency of business details
- Address and MSE classification

---

### **Step 3: Product Catalogue Review**

The officer manually reviews:

- Product categories
- Attributes and descriptions
- Claimed manufacturing or trading capability

This step relies heavily on human judgement.

---

### **Step 4: Sector and SNP Mapping Validation**

NSIC checks:

- Whether the MSE is mapped to a suitable SNP
- Whether the SNP has experience in that product domain

This step exists because:

- MSEs choose SNPs without knowing their expertise
- SNPs may onboard businesses outside their specialization

If a mismatch is found, the application is flagged or rejected.

---

### **Step 5: Decision Making**

NSIC:

- Approves
- Rejects
- Or sends back for correction

Rejected applications usually return to the **same SNP**, creating repeated correction cycles.

---

## **8\. Problems Faced by NSIC**

NSIC faces several operational challenges:

- Entire verification process is manual
- Product catalogues are often unclear or misclassified
- SNP–MSE mapping is frequently incorrect
- High volume of rejections and resubmissions
- Verification is slow and inconsistent  
    <br/>

---

## **9\. What the Problem Statement Wants**

Problem Statement 2 calls for an **AI-powered system** that can:

- Reduce manual data entry during onboarding
- Automatically understand MSE business descriptions
- Suggest correct MSE categories and product taxonomies
- Intelligently match MSEs to suitable SNPs
- Assist NSIC with faster, consistent, and explainable verification

The goal is to:

- Minimize errors before submission
- Reduce NSIC workload
- Eliminate rejection loops
- Enable faster and smoother onboarding of MSEs onto ONDC

---

## **10\. Core Summary**

The current TEAM onboarding process is manual, interpretation-heavy, and inefficient.  
Errors during SNP-led registration lead to high verification effort at NSIC, repeated rejections, and delayed digital onboarding of genuine MSEs.

**Problem Statement 2 seeks an AI-driven solution to make this process accurate, scalable, and efficient.**