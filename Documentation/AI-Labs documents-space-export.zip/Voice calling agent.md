# Voice calling agent

This project is an AI Voice IVR (Interactive Voice Response) system designed to automate appointment booking, rescheduling, and cancellation. It leverages Twilio for voice communication, FastAPI for the web server, and a sophisticated agentic AI powered by LangChain and LangGraph for intelligent conversational flow and appointment management.

## Features

- **Voice-Enabled Appointment Management**: Users can interact with the AI assistant via voice to schedule, reschedule, or cancel appointments.
- **Real-Time Voice Streaming**: Advanced bi-directional audio streaming using Twilio Media Streams with WebSocket connections for low-latency voice interactions.
- **Intelligent Conversational Agent**: Powered by LangChain and LangGraph, the AI understands natural language queries related to appointments.
- **Multi-Language Support**: Enhanced with Sarvam AI for Hindi and Indian language Text-to-Speech (TTS) and Speech-to-Text (STT) capabilities.
- **WebSocket-Based Real-Time Communication**: Supports real-time chat and voice streaming through WebSocket connections for immediate response and interaction.
- **Advanced Audio Processing**: Intelligent speech activity detection, automatic silence handling, and optimized audio buffering for natural conversation flow.
- **Appointment Availability Check**: The system can check for available time slots based on user-specified dates and times.
- **Database Integration**: Seamlessly manages appointment data (creation, updates, cancellations) through a dedicated database tool.
- **Input Validation**: Robust validation for dates, times, emails, names, and appointment types ensures data integrity.
- **Business Hour & Slot Granularity Enforcement**: Appointments can only be booked within defined business hours and at specific time granularities (e.g., on the hour or half-hour).
- **Twilio Integration**: Handles incoming and outgoing calls, converting speech to text and text to speech for a natural voice interaction.
- **Scalable Web Server**: Built with FastAPI and Uvicorn for high-performance asynchronous operations.
- **Modern Web Interface**: Beautiful React-based frontend with real-time chat, voice call initiation, and responsive design.

## Real-Time Voice Streaming Architecture

The system implements advanced real-time voice streaming capabilities using **Twilio Media Streams** for bi-directional audio communication:

### WebSocket-Based Audio Streaming

- **Low-Latency Communication**: Direct WebSocket connection between Twilio and the application for minimal audio delay
- **Bi-Directional Audio Flow**: Simultaneous audio input (user speech) and output (AI responses) through the same connection
- **Real-Time Processing**: Audio is processed in 20ms chunks for natural conversation flow
- **Connection Management**: Automatic connection lifecycle management with graceful error handling

### Advanced Audio Processing Pipeline

- **Format Conversion**: Automatic conversion between Twilio's μ-law format and PCM16 for speech processing
- **Sample Rate Adaptation**: Intelligent resampling from 8kHz (Twilio) to 16kHz (Sarvam AI STT) and back
- **Speech Activity Detection**: Smart detection of actual speech vs. silence to prevent processing empty audio
- **Intelligent Buffering**: Dynamic audio buffering with configurable duration (500ms-10s) and silence detection
- **Turn-Taking Management**: Automatic prevention of audio feedback and conversation overlap

### Media Stream Integration Features

- **Automatic Session Management**: Each call gets a unique streaming session with conversation history
- **Silence Handling**: Generates appropriate silence to maintain Twilio connection stability
- **Error Recovery**: Robust error handling with automatic reconnection and fallback mechanisms
- **Audio Chunking**: Optimized 160-byte chunks (20ms) for smooth audio streaming
- **Real-Time Transcription**: Immediate speech-to-text conversion using Sarvam AI's Hindi/English STT
- **Instant TTS Synthesis**: Real-time text-to-speech conversion with streaming audio output

## AI Agent Architecture

The system employs a sophisticated **LangGraph ReAct (Reasoning and Acting) Agent** architecture for intelligent appointment management:

### LangGraph Agent Framework

- **ReAct Agent Pattern**: Implements the ReAct (Reasoning and Acting) paradigm where the AI agent reasons about user requests and takes appropriate actions
- **Stateful Conversations**: Maintains conversation history and context across multiple interactions within a session
- **Tool Integration**: Seamlessly integrates with database tools for appointment operations (create, read, update, delete)
- **Memory Management**: Uses LangGraph's memory system to maintain conversation state and user context
- **Multi-Actor Capability**: Designed to handle complex multi-step appointment workflows with decision-making capabilities

### Intelligent Conversation Flow

- **Intent Recognition**: Automatically identifies user intent (book, check, reschedule, cancel appointments)
- **Context Awareness**: Maintains conversation context to handle follow-up questions and clarifications
- **Natural Language Processing**: Processes both English and Hindi inputs with contextual understanding
- **Response Sanitization**: Automatically cleans AI responses to remove markdown and formatting for TTS compatibility
- **Error Handling**: Graceful handling of unclear requests with appropriate clarification questions

### Hindi/Indian Language Support via Sarvam AI

- **Native Hindi Processing**: Full support for Hindi speech recognition and synthesis using Sarvam AI's specialized models
- **Bilingual Capabilities**: Handles mixed Hindi-English (Hinglish) conversations naturally
- **Cultural Context**: Optimized for Indian communication patterns and appointment booking preferences
- **Regional Language Support**: Extensible architecture for additional Indian languages through Sarvam AI
- **Voice Quality**: High-quality, natural-sounding Hindi TTS with female voice (Anushka) and male voice options

### Advanced AI Features

- **Appointment Validation**: Intelligent validation of dates, times, and appointment types with business rule enforcement
- **Availability Intelligence**: Smart scheduling that considers business hours, existing appointments, and time slot availability
- **Conversation Memory**: Persistent memory across voice calls and chat sessions for seamless user experience
- **Multi-Modal Support**: Consistent AI behavior across voice calls, chat interface, and streaming voice interactions
- **Configurable LLM Backend**: Flexible support for OpenAI GPT models and Groq's high-performance LLMs with automatic failover

## Technologies Used

- _Backend:_\*
- **Python**: The core programming language.
- **FastAPI**: A modern, fast (high-performance) web framework for building APIs.
- **Uvicorn**: An ASGI server for running FastAPI applications.
- **Twilio**: For programmable voice and SMS capabilities.
- **LangChain**: Framework for developing applications powered by language models, providing tools and utilities for AI agent development.
- **LangGraph**: A library for building stateful, multi-actor applications with LLMs, enabling complex agentic behaviors. Used to create a ReAct (Reasoning and Acting) agent architecture for appointment management with conversation memory and tool integration.
- **Groq**: High-performance LLM provider used for fast inference and natural language processing.
- **OpenAI**: Alternative LLM provider for language model capabilities, used as backup or alternative to Groq.
- **Sarvam AI SDK**: Primary Text-to-Speech (TTS) and Speech-to-Text (STT) provider with specialized support for Hindi and other Indian languages, enabling natural voice interactions for Indian users.
- `python-dotenv`: For managing environment variables.
- `pytz` **&** `tzdata`: For timezone handling.
- `websockets`: For WebSocket communication.
- `requests` **&** `httpx`: For HTTP client operations.
- `pydantic`: For data validation and settings management.

- _Frontend:_\*
- **React**: Modern UI library for building interactive user interfaces.
- **TypeScript**: Type-safe JavaScript for better code quality.
- **Vite**: Fast build tool and development server.
- **Tailwind CSS**: Utility-first CSS framework for rapid UI development.
- **shadcn/ui**: Beautiful, accessible React components built on Radix UI.
- **Framer Motion**: Animation library for smooth transitions.
- **Axios**: HTTP client for API communication.
- **date-fns**: Date utility library.

## Setup and Installation

1.  **Clone the repository**:
    
    ```bash
    git clone https://github.com/your-username/appointment_voice_chatbot_twilio.git
    cd appointment_voice_chatbot_twilio
    ```
    
2.  **Create and activate a virtual environment**:
    
    ```bash
    python -m venv venv
    # On Windows
    venv\Scripts\activate
    # On macOS/Linux
    source venv/bin/activate
    ```
    
3.  **Install backend dependencies**:
    
    ```bash
    cd backend
    pip install -r requirements.txt
    ```
    
    - _Key Dependencies Installed:_\*
    
    - `sarvamai` - Sarvam AI SDK for Hindi/Indian language TTS and STT
    - `fastapi` - Modern web framework for building APIs
    - `langchain` & `langgraph` - AI agent framework and workflow management
    - `twilio` - Voice communication and telephony services
    - `openai` & `groq` - LLM providers for natural language processing
    - `hypothesis` - Property-based testing framework
    
    - _Note:_\* The requirements.txt file excludes deprecated dependencies (chatterbox-tts, pydub, numpy, torch, torchaudio) that are no longer used in the current implementation.
4.  **Environment Variables**:  
    Copy the example environment file and configure your settings:
    
    ```bash
    cd backend
    cp .env.example .env
    ```
    
    Then edit the `.env` file with your actual credentials and configuration:
    
    - _Required Variables:_\*
    
    ```env
    # Twilio Configuration (Required)
    TWILIO_ACCOUNT_SID=ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
    TWILIO_AUTH_TOKEN=your_twilio_auth_token
    TWILIO_PHONE_NUMBER=+1234567890
    
    # AI Provider API Keys (At least one required)
    OPENAI_API_KEY=sk-xxxxxxxxxxxxxxxxxxxxxxxxxxxxx
    GROQ_API_KEY=gsk_xxxxxxxxxxxxxxxxxxxxxxxxxxxxx
    
    # Sarvam AI for Hindi/Indian Language Support (Required for TTS/STT)
    SARVAM_API_KEY=your_sarvam_api_key
    ```
    
    - _Service Setup Instructions:_\*
    
    - **Twilio**: Sign up at [twilio.com](https://www.twilio.com/), get your Account SID and Auth Token, purchase a phone number with voice capabilities
    - **OpenAI**: Sign up at [platform.openai.com](https://platform.openai.com/signup), create an API key, add billing information if required
    - **Groq** (Optional): Sign up at [console.groq.com](https://console.groq.com/), create an API key for alternative LLM provider
    - **Sarvam AI**: Sign up at [sarvam.ai](https://www.sarvam.ai/), get your API key for Hindi/Indian language support
    
    - _Optional Configuration Variables:_\*
    
    ```env
    # Server Settings
    HOST=0.0.0.0                    # Server host (default: 0.0.0.0)
    PORT=8000                       # Server port (default: 8000)
    DEBUG=false                     # Debug mode (default: false)
    
    # Database Configuration
    DATABASE_URL=sqlite:///./appointments.db  # Database URL (default: SQLite)
    
    # Twilio Webhook URLs (for production deployment)
    TWILIO_WEBHOOK_URL=https://your-domain.com/api/voice/incoming-call
    TWILIO_VOICE_URL=https://your-domain.com/api/voice/voice-response
    
    # AI Model Configuration
    LLM_PROVIDER=openai             # AI provider: "openai" or "groq" (default: openai)
    MODEL_NAME=gpt-4                # Specific model name (takes precedence)
    LLM_MODEL=gpt-4                 # Alternative model name variable
    OPENAI_MODEL=gpt-5-nano-2025-08-07      # Default OpenAI model
    GROQ_MODEL=llama-3.3-70b-versatile      # Default Groq model
    AI_TEMPERATURE=0.7              # Model temperature (default: 0.7)
    
    # Business Configuration
    TIMEZONE=Asia/Kolkata           # Application timezone (default: Asia/Kolkata)
    BUSINESS_START_HOUR=9           # Business start hour (default: 9 AM)
    BUSINESS_END_HOUR=17            # Business end hour (default: 5 PM)
    ```
    
    See the `.env.example` file for complete configuration details and setup instructions.
5.  **Database Setup**:  
    The `backend/db_tool` module uses an in-memory SQLite database for demonstration purposes. For persistent storage, you would need to modify `backend/db_tool/db_manager.py` to connect to a more robust database (e.g., PostgreSQL, MySQL).
6.  **Ngrok (or similar tunneling service)**:  
    Twilio needs a publicly accessible URL to send incoming call webhooks and for Media Stream integration. You can use `ngrok` for this.  
    Download `ngrok.exe` (or the appropriate version for your OS) and place it in the project root or `backend/` directory.  
    Run ngrok to expose your local server:
    
    ```bash
    ngrok http 8000
    ```
    
    Copy the `https` forwarding URL provided by ngrok (e.g., `https://your-ngrok-url.ngrok-free.app`). You will use this URL in your Twilio webhook configuration for both voice calls and Media Stream endpoints.

## Usage

### Backend Setup

1.  **Navigate to backend directory and start the FastAPI server**:
    
    ```bash
    cd backend
    python -m uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
    ```
    
    - _Alternative startup methods:_\*
    
    ```bash
    # Using the main.py entry point
    python app/main.py
    
    # For production (without reload)
    python -m uvicorn app.main:app --host 0.0.0.0 --port 8000
    ```
    
    The server will run on `http://localhost:8000` and will be accessible for Twilio webhooks.
    
    - _Backend API Endpoints:_\*
    
    - `http://localhost:8000/docs` - Interactive API documentation (Swagger UI)
    - `http://localhost:8000/api/chat/` - Chat interface endpoints
    - `http://localhost:8000/api/voice/` - Voice call endpoints
    - `http://localhost:8000/api/voice/stream` - Real-time voice streaming endpoint

### Frontend Setup

1.  **Navigate to the frontend directory**:
    
    ```bash
    cd frontend
    ```
    
2.  **Install dependencies** (first time setup):
    
    ```bash
    npm install
    ```
    
3.  **Start the development server**:
    
    ```bash
    npm run dev
    ```
    
    The frontend will run on `http://localhost:5173` by default (Vite's default port).
    
    - _Alternative development commands:_\*
    
    ```bash
    # Start with specific port
    npm run dev -- --port 3000
    
    # Start with host binding for external access
    npm run dev -- --host 0.0.0.0
    ```
    
4.  **Build for production**:
    
    ```bash
    npm run build
    ```
    
    This creates optimized production files in the `dist/` directory.
5.  **Preview production build**:
    
    ```bash
    npm run preview
    ```
    
    This serves the production build locally for testing.
    
    - _Complete Startup Sequence:_\*
    
    For full application functionality, start both backend and frontend:
    
    - _Terminal 1 (Backend):_\*
    
    ```bash
    cd backend
    python -m uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
    ```
    
    - _Terminal 2 (Frontend):_\*
    
    ```bash
    cd frontend
    npm run dev
    ```
    
    - _Terminal 3 (Ngrok for Twilio webhooks):_\*
    
    ```bash
    ngrok http 8000
    ```
    
    Then access the application at `http://localhost:5173` (or the port shown in your terminal).

### Twilio Configuration

6.  **Configure Twilio Webhook**:
    - Go to your Twilio Phone Numbers dashboard.
    - Select the Twilio phone number you want to use for this application.
    - Under the "Voice & Fax" section, configure the "A CALL COMES IN" webhook to "Webhook" and paste your ngrok `https` forwarding URL followed by `/api/voice/incoming-call`.  
        Example: `https://your-ngrok-url.ngrok-free.app/api/voice/incoming-call`
    - Set the HTTP method to `POST`.
7.  **Configure Media Streams (for real-time voice streaming)**:
    - In your Twilio Console, navigate to Voice > TwiML > TwiML Bins or create a new TwiML application.
    - Configure the Media Stream webhook URL to point to your streaming endpoint:  
        Example: `https://your-ngrok-url.ngrok-free.app/api/voice/stream`
    - This enables bi-directional real-time audio streaming between Twilio and your application.
    - The system uses WebSocket connections for real-time voice data processing and Sarvam AI integration.
8.  **Make an Outbound Call (Optional)**:  
    You can initiate an outbound call via the web interface (recommended) or using the API directly.
    
    - _Using the Web Interface:_\*
    - Open `http://localhost:5173` in your browser (Vite default port)
    - Enter your phone number in the voice call panel
    - Click "Get Voice Call" to initiate a call
    - _Using the API directly:_\*
    - Make a POST request to `http://localhost:8000/api/voice/initiate-call`
    - Include a JSON body with `phone_number` field
    - Example:
    
    ```bash
    curl -X POST http://localhost:8000/api/voice/initiate-call \
      -H "Content-Type: application/json" \
      -d '{"phone_number": "+1234567890"}'
    ```
    

### Interacting with the Application

8.  **Interact with the AI**:
    - _Via Web Interface:_\*
    - Open `http://localhost:5173` in your browser (Vite default port).
    - Use the chat interface to interact with the AI assistant.
    - Type messages to schedule, check, update, or cancel appointments.
    - Click "Get Voice Call" to initiate a phone call to your number.
    - _Via Voice Call:_\*
    - Call your Twilio phone number.
    - The AI assistant will greet you and prompt you to state your request regarding appointments.
    - Speak naturally to schedule, reschedule, or cancel appointments.

### Real-Time Voice Streaming Interaction

The system uses **Twilio Media Streams** for advanced real-time voice interactions:

- _How Voice Streaming Works:_\*

1.  **Call Connection**: When you call the Twilio number, the system immediately connects to a WebSocket-based Media Stream
2.  **Real-Time Audio Processing**: Your voice is processed in 20ms chunks for natural conversation flow
3.  **Intelligent Speech Detection**: The system detects when you're speaking vs. when you're silent
4.  **Immediate Transcription**: Speech is converted to text using Sarvam AI's Hindi/English STT in real-time
5.  **AI Processing**: Your request is processed by the LangGraph agent with conversation memory
6.  **Instant Response**: AI responses are synthesized to speech and streamed back immediately

- _Voice Interaction Features:_\*

- **Bi-Directional Streaming**: Simultaneous listening and speaking capabilities
- **Turn-Taking Management**: Automatic prevention of audio feedback and conversation overlap
- **Silence Detection**: Smart detection of speech pauses (3-second silence threshold)
- **Buffer Management**: Intelligent audio buffering (500ms-10s) for natural conversation
- **Hindi/English Support**: Native support for both languages through Sarvam AI
- **Low Latency**: Minimal delay between speaking and AI response (typically <2 seconds)

- _Voice Call Flow:_\*

```text
1. Dial Twilio Number → 2. Media Stream Connection → 3. Hindi Greeting
4. Speak Your Request → 5. Real-Time Transcription → 6. AI Processing
7. TTS Synthesis → 8. Audio Streaming Back → 9. Continue Conversation
```

- _Supported Voice Commands (Hindi/English):_\*

- "मुझे कल 2 बजे अपॉइंटमेंट बुक करना है" (Book appointment tomorrow at 2 PM)
- "I want to schedule an appointment for next Monday"
- "मेरा अपॉइंटमेंट कैंसल करना है" (Cancel my appointment)
- "What appointments do I have this week?"
- "Reschedule my appointment to Friday at 3 PM"

- _Technical Implementation:_\*

- **WebSocket Protocol**: Uses WSS (WebSocket Secure) for encrypted real-time communication
- **Audio Format**: Twilio μ-law (8kHz) ↔ PCM16 (16kHz) conversion for Sarvam AI
- **Session Management**: Each call maintains conversation history and context
- **Error Recovery**: Automatic reconnection and graceful error handling
- **Connection Stability**: Automatic silence generation to maintain Twilio connection

### API Endpoints

The backend provides several REST API endpoints for different types of interactions:

- _Chat API Endpoints (_`/api/chat/`_):_\*

```http
# Send a message to the AI assistant
POST http://localhost:8000/api/chat/message
Content-Type: application/json

{
  "content": "I want to book an appointment for tomorrow at 2 PM",
  "session_id": "optional-session-id"
}

# Get conversation history for a session
GET http://localhost:8000/api/chat/history/{session_id}

# Clear conversation history
DELETE http://localhost:8000/api/chat/history/{session_id}

# Get all active chat sessions
GET http://localhost:8000/api/chat/sessions

# Create a new chat session
POST http://localhost:8000/api/chat/new-session
```

- _Voice Call API Endpoints (_`/api/voice/`_):_\*

```http
# Initiate an outbound voice call
POST http://localhost:8000/api/voice/initiate-call
Content-Type: application/json

{
  "phone_number": "+1234567890",
  "message": "Optional message"
}

# Get status of a specific call
GET http://localhost:8000/api/voice/call-status/{call_sid}

# Get list of active voice calls
GET http://localhost:8000/api/voice/active-calls

# Twilio webhook for incoming calls (configured in Twilio Console)
POST http://localhost:8000/api/voice/incoming-call
```

- _Real-Time Voice Streaming (_`/api/voice/`_):_\*

```http
# WebSocket endpoint for Twilio Media Streams (real-time bi-directional audio)
WSS wss://your-domain.com/api/voice/stream

# Get active streaming sessions
GET http://localhost:8000/api/voice/active-streams
```

- _Interactive API Documentation:_\*

- Visit `http://localhost:8000/docs` for Swagger UI with interactive API testing
- Visit `http://localhost:8000/redoc` for ReDoc documentation

- _Example Chat API Usage:_\*

```bash
# Start a new conversation
curl -X POST http://localhost:8000/api/chat/message \
  -H "Content-Type: application/json" \
  -d '{"content": "Hello, I need to schedule an appointment", "session_id": null}'

# Continue the conversation
curl -X POST http://localhost:8000/api/chat/message \
  -H "Content-Type: application/json" \
  -d '{"content": "Tomorrow at 3 PM would be perfect", "session_id": "your-session-id-from-previous-response"}'
```

- _Example Voice Call API Usage:_\*

```bash
# Initiate a call to a phone number
curl -X POST http://localhost:8000/api/voice/initiate-call \
  -H "Content-Type: application/json" \
  -d '{"phone_number": "+1234567890"}'

# Check call status
curl -X GET http://localhost:8000/api/voice/call-status/CA1234567890abcdef
```

## Project Structure

```text
.
├── README.md                           # Project documentation
├── project_analysis.md                # Project analysis documentation
├── backend/                            # Backend application
│   ├── requirements.txt               # Python backend dependencies
│   ├── appointments.db                # SQLite database file
│   ├── appointment_tools.log          # Application logs
│   ├── twilio_pipeline_app.py         # Twilio pipeline application
│   ├── test_sarvam_flow.py            # Sarvam AI integration test
│   ├── PROJECT_OVERVIEW_PROMPT.md     # Project overview documentation
│   ├── SARVAM_AI_DOCUMENTATION.md     # Sarvam AI integration documentation
│   ├── app/                           # FastAPI backend application
│   │   ├── main.py                    # FastAPI application entry point
│   │   ├── routers/                   # API route handlers
│   │   │   ├── chat.py                # Chat API endpoints
│   │   │   ├── voice.py               # Voice call API endpoints
│   │   │   └── voice_stream.py        # Real-time voice streaming endpoints
│   │   ├── core/                      # Core configuration and utilities
│   │   │   ├── config.py              # Application configuration and environment variables
│   │   │   ├── sarvam_client.py       # Sarvam AI TTS/STT client integration
│   │   │   └── websocket_manager.py   # WebSocket connection manager for real-time communication
│   │   └── audio/                     # Audio processing utilities
│   │       └── audio_utils.py         # Audio manipulation and conversion functions
│   ├── agentic_graph/                 # LangGraph AI agent implementation
│   │   ├── agent_graph.py             # LangGraph ReAct agent setup and workflow
│   │   └── prompts.py                 # AI agent system prompts and templates
│   ├── db_tool/                       # Database abstraction layer
│   │   ├── db_manager.py              # SQLite database operations and schema
│   │   └── db_tools.py                # LangChain-compatible database tools
│   ├── tests/                         # Test suite
│   │   └── test_readme_properties.py  # Property-based tests for README validation
│   └── archive/                       # Archived legacy files
│       └── legacy_files/              # Deprecated implementation files
│           ├── answer_phone.py        # Legacy phone answering implementation
│           ├── legacy_make_call.py    # Old call initiation logic
│           ├── make_call.py           # Previous call handling implementation
│           ├── run_agent_cli.py       # Command-line agent runner (deprecated)
│           ├── start_app.py           # Legacy application starter
│           └── test_integration.py    # Old integration tests
├── frontend/                          # React frontend application
│   ├── package.json                   # Frontend dependencies and scripts
│   ├── package-lock.json              # Dependency lock file
│   ├── vite.config.ts                 # Vite build tool configuration
│   ├── tsconfig.json                  # TypeScript configuration
│   ├── tsconfig.node.json             # TypeScript config for Node.js
│   ├── tailwind.config.js             # Tailwind CSS configuration
│   ├── postcss.config.js              # PostCSS configuration
│   ├── components.json                # shadcn/ui component configuration
│   ├── index.html                     # HTML entry point
│   ├── public/                        # Static assets
│   │   └── vite.svg                   # Vite logo
│   └── src/                           # Frontend source code
│       ├── main.tsx                   # React application entry point
│       ├── App.tsx                    # Main application component
│       ├── counter.ts                 # Counter utility (development)
│       ├── components/                # React components
│       │   ├── ui/                    # shadcn/ui base components
│       │   │   ├── alert.tsx          # Alert component
│       │   │   ├── alert-dialog.tsx   # Alert dialog component
│       │   │   ├── avatar.tsx         # Avatar component
│       │   │   ├── badge.tsx          # Badge component
│       │   │   ├── button.tsx         # Button component
│       │   │   ├── card.tsx           # Card component
│       │   │   ├── dialog.tsx         # Dialog component
│       │   │   ├── input.tsx          # Input component
│       │   │   ├── scroll-area.tsx    # Scroll area component
│       │   │   ├── separator.tsx      # Separator component
│       │   │   ├── skeleton.tsx       # Loading skeleton component
│       │   │   └── sonner.tsx         # Toast notification component
│       │   ├── chat/                  # Chat interface components
│       │   │   ├── ChatInterface.tsx  # Main chat interface
│       │   │   ├── ChatInput.tsx      # Chat message input
│       │   │   └── MessageBubble.tsx  # Individual message display
│       │   ├── voice/                 # Voice call components
│       │   │   ├── VoiceCallPanel.tsx # Voice call control panel
│       │   │   ├── VoiceCallDialog.tsx # Voice call dialog
│       │   │   ├── CallStatusCard.tsx # Call status display
│       │   │   └── PhoneInput.tsx     # Phone number input
│       │   ├── sidebar/               # Sidebar components
│       │   │   ├── Sidebar.tsx        # Main sidebar component
│       │   │   ├── CallStatusSection.tsx # Call status in sidebar
│       │   │   ├── QuickActions.tsx   # Quick action buttons
│       │   │   └── AboutSection.tsx   # About information section
│       │   └── layout/                # Layout components
│       │       ├── Header.tsx         # Application header
│       │       └── Footer.tsx         # Application footer
│       ├── services/                  # API service layer
│       │   ├── api.ts                 # Axios HTTP client configuration
│       │   ├── chat.ts                # Chat API service functions
│       │   ├── voice.ts               # Voice call API service functions
│       │   └── websocket.ts           # WebSocket client implementation
│       ├── hooks/                     # Custom React hooks
│       │   ├── useChat.ts             # Chat state management hook
│       │   ├── useVoiceCall.ts        # Voice call management hook
│       │   ├── useSession.ts          # Session management hook
│       │   └── useWebSocket.ts        # WebSocket connection hook
│       ├── store/                     # State management
│       │   └── context/               # React Context providers
│       │       ├── AppContext.tsx     # Application-level state
│       │       ├── ChatContext.tsx    # Chat state management
│       │       ├── VoiceContext.tsx   # Voice call state management
│       │       └── index.ts           # Context provider exports
│       ├── types/                     # TypeScript type definitions
│       │   ├── api.ts                 # API response and request types
│       │   ├── chat.ts                # Chat-related types
│       │   └── voice.ts               # Voice call types
│       ├── utils/                     # Utility functions
│       │   ├── constants.ts           # Application constants
│       │   ├── helpers.ts             # Helper utility functions
│       │   └── index.ts               # Utility function exports
│       ├── lib/                       # Library utilities
│       │   └── utils.ts               # shadcn/ui utility functions
│       └── styles/                    # Global styles
│           └── globals.css            # Tailwind CSS and global styles
```