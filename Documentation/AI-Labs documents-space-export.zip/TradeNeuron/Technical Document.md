# Technical Document

**Technical Specification Document**  

**Project: TradeNeuron – AI-Powered Financial Assistant & Trading Bot** 

**1\. System Overview** 

TradeNeuron is a web-based, microservice-oriented application that integrates AI, financial data, and trading automation.   
It consists of a React.js frontend, a FastAPI backend, and a PostgreSQL database, with background workers for real-time data processing and trade execution. 

**2\. Technology Stack** 

|     |     |     |
| --- | --- | --- |
| **Layer** | **Technology** | **Purpose** |
| **Frontend** | React.js, Tailwind CSS | User interface and charts |
| **Backend** | FastAPI (Python) | Business logic, APIs |
| **Database** | PostgreSQL | Persistent storage |
| **AI Layer** | Lang Chain, OpenAI/Gemini APIs, ARIMA | Chatbot, Prediction, Advisor |
| **Queue System** | Celery + Redis | Background processing and async tasks |
| **Broker API** | Zerodha Kite Connect | Real-time trading execution |
| **Data Source** | yFinance, News APIs | Market and news data |
| **Deployment** | Docker, Nginx, AWS EC2 | Hosting and scaling |
| **Authentication** | OAuth2, JWT | Secure user management |

 

**3\. Data Flow Summary** 

**3.1 User Flow** 

1.  User logs in → Auth Service validates via JWT/OAuth. 

2.  User requests data → FastAPI fetches from yFinance or DB. 

3.  User executes strategy → Script service runs logic on data. 

4.  The back test engine returns metrics and charts. 

5.  Trading bot executes trades via Zerodha. 

6.  Chatbot or advisor module handles financial queries. 

**3.2 AI Model Workflow** 

- **Stock Prediction:** ARIMA → Short-term forecasting 

- **Chatbot:** LangChain + LLM (OpenAI/Gemini) → Response generation 

- **Advisor:** Document embedding → LangChain agent → Insight extraction 

**4\. Database Design (High-Level)** 

**Tables:** 

- users → id, email, password hash, role, created_at 

- stocks → id, symbol, name, price, favorite by 

- scripts → id, name, code, owner_id, created_at 

- backtests → id, strategy_id, stock_symbol, result_json 

- trades → id, bot_id, stock_symbol, side, qty, price, timestamp 

ORM: **SQLAlchemy**  

**5\. APIs (Example Endpoints)** 

|     |     |     |
| --- | --- | --- |
| **Endpoint** | **Method** | **Description** |
| /auth/register | POST | Create new user |
| /auth/login | POST | Login and generate JWT |
| /stocks/favorites | GET/POST/DELETE | Manage favorite stocks |
| /scripts | POST/GET/PUT | Manage trading scripts |
| /backtest/run-backtesting | POST | Execute backtest |
| /bot/start | POST | Start trading bot |
| /bot/stop | POST | Stop trading bot |
| /predict | POST | Run stock prediction |
| /chat | POST | Query financial chatbot |
| /advisor/upload | POST | Upload financial document |

 

**6\. Security Design** 

- OAuth2.0 + JWT for user sessions. 

- HTTPS for all communications. 

- Database encryption for sensitive data. 

- Role-based access control (user/admin). 

- Regular token refresh and expiry enforcement. 

 

**7\. Future Technical Enhancements** 

- Multi-broker adapters (Grow, Kucoin). 

- Real-time WebSocket-based price streaming. 

- Sentiment analysis model integration. 

- Strategy sharing marketplace (with versioning).