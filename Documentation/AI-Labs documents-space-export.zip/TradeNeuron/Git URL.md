# Git URL

Backend: https://gitlab.inexture.com/ai.inexture/tradeneuron-backend.git

Frontend: https://gitlab.inexture.com/ai.inexture/tradeneuron-frontend.git