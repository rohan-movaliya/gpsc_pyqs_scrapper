# Celery Import Issue – Root Cause & Standard Solution

## 1\. Problem Statement

When running the Celery worker:

```
celery -A app.core.celery_app worker --loglevel=info
```

Celery fails with the error:

```
ModuleNotFoundError: No module named 'ai'
```

However, the **FastAPI application runs without any issue**.

---

## 2\. Project Structure

```
tradeneuron-backend/
├── app/
│   ├── core/
│   │   └── celery_app.py
│   ├── tasks/
│   ├── apis/
│   └── main.py
│
├── ai/
│   ├── llm.py
│   └── __init__.py
│
└── requirements.txt
```

Import used in code:

```
from ai.llm import get_gemini_llm
```

---

## 3\. Why Celery Is Not Running

### 3.1 How Celery Starts

When you run:

```
celery -A app.core.celery_app worker
```

Celery does the following:

1.  Imports `app.core.celery_app`
2.  Initializes the Celery app
3.  **Auto-discovers tasks**
4.  Imports all task modules eagerly at startup
5.  Fails immediately if **any import is invalid**

During task discovery, Celery executes:

```
app/tasks/bot.py
 → app/apis/bot/services.py
   → app/apis/scripts/services.py
     → from ai.llm import get_gemini_llm ❌
```

At this point, Python raises:

```
ModuleNotFoundError: No module named 'ai'
```

---

### 3.2 The Core Issue

**Python cannot find the** `ai` **module because the project root is not in** `PYTHONPATH` **When Celery runs.**

Celery only knows about:

- Standard library
- Installed packages
- The module passed via `-A` (`app`)

It does **not automatically include the project root directory**.

---

## 4\. Why FastAPI Runs Successfully

FastAPI is usually started as:

```
uvicorn app.main:app
```

Key difference:

- `uvicorn` is executed **from the project root**
- Python automatically adds the **current working directory** to `sys.path`

So Python sees:

```
tradeneuron-backend/
```

Which allows:

```
from ai.llm import get_gemini_llm
```

### In short:

| Component | Root in PYTHONPATH | Result |
| --- | --- | --- |
| FastAPI | ✅ Yes | Works |
| Celery | ❌ No | Fails |

This is a **very common Celery + FastAPI issue**.

---

## 5\. Why This Happens Specifically With Celery

- Celery is a **separate process**
- It runs **independently of FastAPI**
- It **eagerly imports all tasks**
- Any missing import causes **startup failure**

FastAPI imports modules lazily when endpoints are hit.  
Celery imports everything at startup.

---

## 6\. Standard & Recommended Solutions

### 🥇 Solution 1: Set `PYTHONPATH` to Project Root (Industry Standard)

This is the **most widely used and recommended solution**.

#### Temporary (for testing)

```
export PYTHONPATH=$(pwd)
celery -A app.core.celery_app worker --loglevel=info
```

#### Permanent (Recommended)

##### Option A: `.env` file

```
PYTHONPATH=/home/root482/tradeneuron-backend
```

##### Option B: Shell/service config

```
PYTHONPATH=. celery -A app.core.celery_app worker --loglevel=info
```

##### Option C: Docker (Best for production)

```
ENV PYTHONPATH=/app
```

✅ Clean imports  
✅ Works for FastAPI & Celery  
✅ No code changes required

---

### 🥈 Solution 2: Convert Project into an Installable Package

If `ai` is a shared module, making the project installable:

```
pip install -e .
```

Requires:

- `pyproject.toml` or `setup.py`

This is common in **large monorepos**.

---

### 🥉 Solution 3: Move `ai` Inside `app` (Structural Fix)

```
app/
├── ai/
│   └── llm.py
```

Change import to:

```
from app.ai.llm import get_gemini_llm
```

✅ No PYTHONPATH dependency  
❌ Less flexible if `ai` is shared across services

---

## 7\. What NOT to Do ❌

Avoid these anti-patterns:

- ❌ `sys.path.append()` in code
- ❌ Relative imports like `../../../ai`
- ❌ Different import paths for FastAPI and Celery

These lead to **deployment and debugging issues**.

---

## 8\. Final Recommended Approach

For **FastAPI + Celery + Redis** projects:

✅ Keep shared modules (like `ai`) at project root  
✅ Set `PYTHONPATH` to project root  
✅ Use clean absolute imports

```
from ai.llm import get_gemini_llm
```

This approach:

- Scales well
- Works in Docker, CI/CD, systemd
- Matches real-world production setups

---

## 9\. Quick Verification

To confirm Celery sees the correct path:

```
import sys
print(sys.path)
```

The project root **must be present** in the list.

---

## 10\. Summary

| Topic | Explanation |
| --- | --- |
| Issue | Celery can’t find `ai` |
| Root Cause | Project root not in PYTHONPATH |
| Why FastAPI works | Runs from root |
| Why Celery fails | Separate process, strict imports |
| Best Fix | Set PYTHONPATH |
| Production Ready | Yes |

---