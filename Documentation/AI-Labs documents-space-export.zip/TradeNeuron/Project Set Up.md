# Project Set Up

## **Quick Setup Summary**

Follow these steps to set up and run the **TradeNeuron Backend** locally.

### **1\. Clone and Setup Environment**

```
# Clone the repository
git clone <your-repo-url>
cd tradeneuron-backend

# Create and activate virtual environment
python -m venv .venv
source .venv/bin/activate      # On Windows: .venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

### **2\. Configure Environment Variables**

Copy the example environment file and update values:

```
cp env.example .env
```

**Configure the following sections:**

- **Database:** PostgreSQL credentials and connection details
- **JWT Auth:** Secret key, algorithm, and expiry time
- **Email & OTP:** SMTP settings for sending verification codes
- **Google OAuth:** Client ID, secret, and redirect URIs
- **App Settings:** Timezone, storage paths, and limits

### **3\. Database Setup**

```
# Start PostgreSQL service
sudo systemctl start postgresql
sudo systemctl enable postgresql

# Create database
sudo -u postgres psql
CREATE DATABASE tradeneuron_db;
\q
```

### **4\. Run the Server**

```
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

This automatically initializes the database, permissions, and roles.

### **5\. Access API Documentation**

- **Swagger UI:** http://0.0.0.0:8000/docs
- **ReDoc:** [http://0.0.0.0:8000/redoc](http://localhost:8000/redoc)
- **API Root:** [http://0.0.0.0:8000/](http://localhost:8000/)