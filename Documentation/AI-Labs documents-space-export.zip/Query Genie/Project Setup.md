# Project Setup

## **Quick Setup Summary**

Follow these steps to set up and run the **Query Genie** locally.

  
Prerequisites

```markdown
- **Python**: 3.10 or higher
- **Node.js**: 18 or higher
- **npm**: 8 or higher
- **Git**: For cloning the repository
- **Redis** (Optional): For caching - improves performance 7,640x
- **Database** (Optional): PostgreSQL, MySQL, or use the default SQLite
```

### **1\. Clone and Setup Environment**

```bash
git clone https://gitlab.inexture.com/ai.inexture/connect_database.git
cd connect_database
```

### **2\.** Backend Setup

Step 2.1: Navigate to Backend Directory

```bash
cd backend
```

Step 2.2: Create Virtual Environment

````bash
**On Linux/macOS:**
```bash
python3 -m venv venv
source venv/bin/activate
```

**On Windows:**
```cmd
python -m venv venv
venv\Scripts\activate
```
````

Step 2.3: Install Dependencies

```bash
pip install --upgrade pip
pip install -r requirements.txt
```

Step 2.4: Create Environment File

Create a \`.env\` file in the \`backend/\` directory with the following content:

```bash
APP_NAME=Database Connection Validator API
VERSION=1.0.0
ENVIRONMENT=development
DEBUG=True

# Server Settings
HOST=0.0.0.0
PORT=8000

# Security Settings
SECRET_KEY=your-super-secret-key-at-least-32-characters-long-change-in-production
ALLOWED_ORIGINS=http://localhost:3000,http://127.0.0.1:3000

# Database Settings (SQLAlchemy - for user management)
DATABASE_URL=sqlite:///./users.db

# Redis Cache Settings (Optional - for performance boost)
REDIS_ENABLED=False
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_PASSWORD=
REDIS_DB=0
REDIS_TTL=600
REDIS_SSL=False

# Logging Settings
LOG_LEVEL=INFO
```

Note: Replace placeholder values with your actual credentials. See \[section 4\](#4-configure-environment-variables) for detailed configuration.

Step 2.5: Initialize Database

The database will be automatically created when you first run the server. No manual setup required!

```bash
python main.py
```

### 3\. Frontend Setup

Step 3.1: Navigate to Frontend Directory

Open a new terminal window and navigate to the frontend directory:

```bash
cd connect_database/frontend
```

Step 3.2: Install Dependencies

```bash
npm install
```

Step 3.3: Create Environment File

Create a \`.env\` file in the \`frontend/\` directory:

```bash
# API Configuration
NEXT_PUBLIC_API_URL=http://localhost:8000
NEXT_PUBLIC_APP_NAME=Database Connection Validator
NEXT_PUBLIC_ENVIRONMENT=development
```

.

4.  **Run the Application**

Terminal 1 - Run Backend:

```bash
cd backend
source venv/bin/activate  # On Windows: venv\Scripts\activate
python main.py
```

Terminal 2 - Run Frontend:

```bash
cd frontend
npm run dev
```

**5\. Access the Application**  
<br/>Once both servers are running, you can access:  
Frontend Application  
\- **URL**: http://localhost:3000  
\- **Description**: Modern, responsive UI with glass morphism design  
<br/>Backend API Documentation  
\- **Swagger UI**: http://localhost:8000/docs  
\- **ReDoc**: http://localhost:8000/redoc  
\- **API Root**: http://localhost:8000/  
\- **Health Check**: http://localhost:8000/health