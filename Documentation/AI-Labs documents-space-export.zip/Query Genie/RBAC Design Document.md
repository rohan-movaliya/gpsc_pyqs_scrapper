# RBAC Design Document

## 1\. Overview

This document describes the design and structure for introducing Role-Based Access Control (RBAC) into the system. The goal is to manage access to multiple database systems (PostgreSQL, MySQL, SQLite, ElasticSearch, Neo4j) through clearly defined roles and permissions.

## 2\. Objectives

\- Provide secure and scalable access control.

\- Enable fine-grained permissions (CRUD — Create/Insert, Read, Update, Delete).

\- Support multi-database access restrictions.

\- Allow easy extension for future roles and databases.

## 3\. Roles Hierarchy

|     |     |     |
| --- | --- | --- |
| Role | Description | Permissions Scope |
| Super Admin | Has full access to all databases and permissions. Can create, edit, and delete any role. | All databases, all permissions. |
| Admin | Manages users and controls their access within specific databases. Cannot modify Super Admin or global settings. | Assigned databases only, full CRUD. |
| User | Limited access to specific databases and permissions as assigned. | Restricted CRUD per database. |

## 4\. Databases Supported

|     |     |
| --- | --- |
| Database | Description |
| PostgreSQL | Relational database for structured data. |
| MySQL | Relational database for application data. |
| SQLite | Lightweight local storage. |
| ElasticSearch | Search and analytics engine. |
| Neo4j | Graph database for relationships. |

## 5\. Permissions Matrix

|     |     |
| --- | --- |
| Permission | Description |
| READ | Query or fetch data. |
| INSERT | Add new records or nodes. |
| UPDATE | Modify existing data. |
| DELETE | Remove records or nodes. |

## 6\. Access Control Model

Each role has access to one or more databases, and within each database, specific permissions are granted.

Example Access Structure:

  
{  
"roles": {  
"super_admin": {  
"databases": \["postgres", "mysql", "sqlite", "elastic", "neo4j"\],  
"permissions": \["read", "insert", "update", "delete"\]  
},  
"admin": {  
"databases": \["postgres", "mysql"\],  
"permissions": \["read", "insert", "update", "delete"\]  
},  
"user": {  
"databases": {  
"postgres": \["read", "insert"\],  
"mysql": \["read"\],  
"neo4j": \[\]  
}  
}  
}  
}  
<br/><br/>

## 7\. Security Considerations

\- All API endpoints protected via JWT authentication.

\- Role updates logged in an audit trail.

\- Super Admin role cannot be deleted or demoted.

\- Access checks must occur before every database operation.

## 8\. Example User Scenarios

|     |     |     |     |
| --- | --- | --- | --- |
| User | Role | Accessible Databases | Permissions |
| Alice | Super Admin | All | All |
| Bob | Admin | PostgreSQL, MySQL | CRUD |
| Charlie | User | PostgreSQL | Read, Insert |
| Diana | User | MySQL | Read Only |