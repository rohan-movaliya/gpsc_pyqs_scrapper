# Limitation

1\. Neon Database (PostgreSQL Serverless)

   - Issue: Initial server-side connection response time exceeds 10 seconds.

   - Limitation: Connection latency cannot be reduced further due to Neon cold start behavior.

   - Impact: connection establishment after inactivity.

2\. Schema Fetch and Caching

   - Issue: After user login, schema metadata must be pre-fetched and loaded.

   - Limitation: On a cache miss, schema reload from the server's side increases query execution time.

.

3\. Elasticsearch (Free Trial)

   - Issue: Update queries fail during execution.

   - Limitation: Free-tier restrictions prevent update operations.

   - Impact: Only read/search/insert queries are supported under the current plan.

4\. Neo4j Aura Database

   - Issue: The Instance automatically disables after a period of inactivity.

   - Limitation: Database instance must be manually restarted when inactive.

   - Impact: Temporary unavailability until reactivation.

5\. Database Environment Coverage

   - Tested Databases:

       • PostgreSQL → Neon DB (serverless)

       • MySQL → SkySQL

       • SQLite → Local DB file

       • Elasticsearch → Bonsai Search

       • Neo4j → Neo4j Aura

   - Limitation:

       • All databases tested only under local or free-tier environments.

       • No AWS RDS, GCP Cloud SQL, or other serverless paid DB credentials available for testing.

   - Impact:

       • Production-level scalability and performance not fully verified.

       • Authentication and connection behavior may vary under paid/serverless deployments.

  
<br/>