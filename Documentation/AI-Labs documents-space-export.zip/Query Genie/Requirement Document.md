# Requirement Document

# **Query Genie**  

**1\. Introduction** 

 

This document outlines the detailed requirements for the development of an AI-powered Query Genie. The system's objective is to automate database connectivity management, schema introspection, and natural language to SQL query conversion, enabling users to interact with multiple database systems through an intuitive web interface without requiring deep SQL expertise. 

 

**2\. Project Overview** 

 

The system should intelligently connect to multiple database types (PostgreSQL, MySQL, SQLite, Neo4j, Elasticsearch), validate connections, introspect database schemas, and convert natural language questions into optimised SQL queries. Based on the database schema and the user's natural language input, it should generate executable SQL queries with safety checks, execute them securely, and return formatted results with explanations. The system serves both technical users requiring quick database validation and non-technical users needing data access through conversational interfaces. 

 

**3\. Functional Requirements** 

 

**3.1 Database Connection Management** 

 

The system must provide comprehensive connection management capabilities: 

 

**3.1.1 Multi-Database Support** 

\- Support for **PostgreSQL** (9.0+), including cloud providers: 

- Neon (serverless PostgreSQL) 

\- Support for **MySQL/MariaDB** (5.7+, MariaDB 10.3+), including: 

- MariaDB SkySQL (serverless) 

\- Support for **SQLite** (3.0+) with: 

- File upload functionality (.db, .sqlite, .sqlite3) 
- In-memory caching for repeated queries 
- No credentials required 

\- Support for **Neo4j** (4.0+) with: 

- Bolt protocol support 
- Cypher query generation from natural language 
- Graph relationship visualization 
- Neo4j Aura cloud support (serverless) 

\- Support for **Elasticsearch** (7.0+, 8.0+) with: 

- Document index introspection 
- Query DSL support 
- Full-text search queries 
- Bonsai Search support (serverless) 

 

**3.1.2 Connection Testing and Validation** 

\- Connection testing endpoint without saving credentials 

\- Automatic SSL/TLS detection for cloud database providers 

\- Connection timeout handling (configurable, default 5 seconds) 

\- Connection health monitoring and status reporting 

\- Detailed error messages with specific error codes for troubleshooting 

\- Cloud provider auto-detection based on host patterns 

 

**3.1.3 Schema Introspection** 

\- Automatic table discovery and listing 

\- Column definition retrieval with data types 

\- Foreign key relationship detection 

\- Constraint information (primary keys, unique constraints, check constraints) 

\- View and materialized view detection (PostgreSQL) 

\- Index information retrieval 

\- Table row count estimation (where supported) 

\- Schema caching for improved performance 

 

**3.1.4 SQLite File Management** 

\- File upload interface with validation 

\- File size and format validation 

\- Temporary file storage with automatic cleanup 

\- Database version detection 

\- Table count validation 

\- File metadata extraction 

 

**3.2 Natural Language Query Generation** 

 

The system must convert natural language questions into optimised SQL queries: 

 

**3.2.1 AI-Powered Query Generation** 

\- **Natural Language Processing**: Accept plain English questions (e.g., "Show me all users who signed up last month") 

\- Provider selection based on configuration 

\- Confidence scoring for generated queries 

\- **Context-Aware Generation**:  

- Database schema understanding and integration 
- Relationship inference between tables 
- Constraint validation during generation 
- Data type awareness 

 

**3.2.2 Query Optimization and Analysis** 

- Query optimization suggestions 
- Index recommendations for performance improvement 
- JOIN optimization analysis 
- Performance metrics and execution time prediction 
- Query complexity scoring 

 

**3.2.3 Query Validation** 

- Syntax checking before execution 
- Security scanning (SQL injection prevention) 
- Schema compliance validation 
- Column and table existence verification 
- Query type detection (SELECT, INSERT, UPDATE, DELETE, DDL) 

 

**3.3 Query Execution and Safety** 

 The system must execute queries securely with comprehensive safety checks: 

 

**3.3.1 Safe Query Execution** 

\- **SELECT Query Execution**: Full support with result pagination 

\- INSERT Query Execution:  

- Controlled execution with impact analysis 
- Row count before/after tracking 
- Warning generation for potentially large inserts 

\- **UPDATE Query Execution**: 

- Impact analysis showing affected rows 
- Before/after value comparison (where possible) 
- Cascade effect warnings 

\- **Safety Restrictions**: 

\- Automatic blocking of destructive operations: 

- `DELETE` queries (with impact analysis warnings) 
- `DROP` operations (blocked with warnings) 
- `TRUNCATE` operations (blocked with warnings) 

\- Result size limits to prevent memory issues 

\- Query timeout protection 

\- Transaction rollback on errors 

 

**3.3.2 Query Impact Analysis** 

\- **Delete Impact Analysis**: 

- Affected row count estimation 
- Foreign key cascade effect analysis 
- Dependent table impact assessment 
- Warning messages with detailed impact summary 

\- **Update Impact Analysis**: 

- Row count analysis 
- Column value change impact 
- Constraint violation warnings 

\- **Insert Impact Analysis**: 

- Duplicate key detection 
- Constraint validation warnings 
- Table size growth estimation 

 

**3.3.3 Result Formatting and Pagination** 

- Formatted result display with column names 
- Pagination support (configurable page size) 
- Result export capabilities (future enhancement) 
- Large result set handling 
- Data type-aware formatting 

 

 

**3.4 Web Application Interface** 

 

A React-based frontend should provide a comprehensive user experience: 

 

 

**3.4.1 Connection Management Interface** 

\- Database type selection (PostgreSQL, MySQL, SQLite, Neo4j, Elasticsearch) 

\- Connection form with fields: 

\- Host, port, username, password, database name 

\- SSL/TLS toggle 

\- Connection timeout configuration 

\- SQLite file upload interface with drag-and-drop support 

\- Connection testing with real-time status feedback 

\- Connection status indicators (success, error, warning) 

\- Default credential management for quick testing 

 

**3.4.2 Database Dashboard** 

\- **Table List View**: 

- Responsive table listing with search and filter 
- Table metadata display (row count, size estimates) 
- Expandable schema view for each table 
- Quick action buttons (view data, view schema) 

\- **Schema Visualisation:** 

- Table relationship diagrams (for SQL databases) 
- Graph visualization (for Neo4j) 
- Foreign key relationship mapping 
- Column type and constraint visualization 

\- **Data View**: 

- Paginated table data display 
- Column sorting and filtering 
- Search functionality across data 
- Schema view toggle 

**\- Query explanation**:  

- According to the query, simple language explanations.

**3.4.3 Query Generator Interface** 

\- Natural language input field 

\- Real-time query generation with loading indicators 

\- Generated SQL preview with syntax highlighting 

\- Execution results table with pagination 

\- Safety warning messages for blocked operations 

 

 

**4\. Non-Functional Requirements** 

 

**4.1 Performance** 

\- C**onnection Testing**: Should complete within 2-5 seconds 

\- **Schema Introspection**: Should complete within 3-10 seconds depending on database size 

\- **Query Generation**: AI-powered generation should complete within 5-15 seconds 

\- **Query Execution:** Simple SELECT queries should execute within 1-3 seconds 

\- **API Response Time**: Non-AI endpoints should respond within 200ms average 

\- **Result Pagination**: Support for paginated results up to 10,000 rows per page 

 

**4.2 Scalability** 

\- Support for multiple concurrent database connections 

\- Handle multiple concurrent query generation requests 

\- Connection pooling for database connections 

\- Async/await architecture for high concurrency 

\- Support for horizontal scaling (stateless design) 

 

**4.3 Security** 

\- **Credential Security**: 

- Passwords never logged (masked as `********`) 
- Secure credential handling in memory 
- No credentials in error messages 

 

 

\- **Network Security**: 

- SSL/TLS automatic detection for cloud databases 
- CORS configuration with origin whitelisting 
- Security headers (configured in reverse proxy) 
- Rate limiting ready (to be implemented) 

 

**4.4 Accuracy** 

\- **Query Generation Accuracy**: Should achieve at least 85% contextual accuracy for simple queries 

\- **Schema Introspection Accuracy**: 100% accuracy for supported database features 

\- **Safety Check Accuracy**: 100% detection rate for dangerous operations (DELETE, DROP, TRUNCATE) 

\- **Connection Validation**: 100% accuracy in detecting connection success/failure