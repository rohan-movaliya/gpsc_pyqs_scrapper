# Code Refactor

_Created by: Rohan Movaliya_

- Git URL: [**https://gitlab.inexture.com/ai.inexture/connect_database**](https://gitlab.inexture.com/ai.inexture/connect_database)
- Refactor Branch: **dev_v2**
- Reference Branch: **dev**
- From MR**:** [**https://gitlab.inexture.com/ai.inexture/connect_database/-/merge_requests/131**](https://gitlab.inexture.com/ai.inexture/connect_database/-/merge_requests/131)
- Date**: 20 Apr, 2026**

Before committing, please make sure:

- Format code with Black
- Attach Test Case Coverage screenshot in PR Description.
- No print() statement in the code
- Please make sure there is no single circular import in the code

### To-Do CheckList

- [x] Remove the Unnecessary [README.md](http://README.md) file (**Done - Rohan**)
  
- [x] Remove constants from logging **(Done - Rohan)**
  
- [x] Remove /default api connection from FE. **(Done - Parth)**
  
- [x] **If Redis is disabled, then show an error (Parth Varecha) ==> Priority**
  
- [x] R&D on Refresh Token for LLM Credentials and fix it: Parth Varecha
  
- [ ] Unnecessary code [Setting.py](http://Setting.py)
  
- [ ] Follow a constant way to import classes or Objects
  
- [ ] In the Connection module, move the utils function from the routes directory to the [utils.py](http://utils.py) file ([schemas.py](http://schemas.py))
  
- [ ] Centralized API Response Format
  
- [ ] Reduced DocString (Global)
  
- [ ] APIs always return a 200 code, even in case of error
  
- [ ] Remove commented Test Cases (Last)
  
- [ ] Query Explanation (simple explanation and detailed explanation)
  
- [ ] Create a centralized service for caching
  
- [ ] Optimized AI Services
  
- [ ] Fix Model Config Bug
  
- [ ] Merge the SQLite update and insert API
  
- [ ] Token is generated, no matter whether the credentials are wrong or right
  
- [ ] Implement RSA on the frontend side
  
- [ ] Implement Background Task to delete expire sqlite file from upload directory
  

**NEXT PHASE FEATURE ENHANCEMENT**  

```
Load Page
   ↓
Fetch DB Types
   ↓
User Selects Type
   ↓
Fetch Schema
   ↓
Render Form Dynamically
   ↓
Fetch Public Key
   ↓
Encrypt Payload
   ↓
POST /tokenize-db
```