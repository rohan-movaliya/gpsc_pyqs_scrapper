# Technical Document

# Query Genie   

Query Genie is a **secure, enterprise-grade database intelligence system** that connects to multiple databases, introspects schemas, safely executes queries, and converts natural language into SQL or Cypher with **AI-powered intent detection and safety controls**.

It features a **modern Next.js dashboard**, a **modular FastAPI backend**, **multi-LLM support**, and **production-ready observability and security**.

 

## **Technology Stack** 

### **Backend**

- **Framework**: FastAPI + Uvicorn
- **Language**: Python 3.10+
- **Async Architecture**: asyncio-based, high concurrency

### **AI/LLM Providers**

- **Multi-Provider AI Support**
    - Google Gemini (`gemini-2.0-flash-exp`)
    - Groq (`llama-4-maverick-17b`)
    - OpenAI
- **Automatic Failover**
- **Form-Based Model Configuration** (`/model-config`)
- **Intent Detection Engine**
    - QUERY_EXECUTION
    - RELATIONSHIP_EXPLANATION 

### **Database Drivers**   

- PostgreSQL: psycopg2-binary 

- MySQL/MariaDB: MySQL-connector-python 

- SQLite: built-in sqlite3 

- Graph: neo4j 

- Search: Elasticsearch 

 

### **Security & Auth** 

- Security & Auth 

- python-jose\[cryptography\], passlib\[bcrypt\], bcrypt 

 

### **Testing & Configuration**    

- pytest, pytest-asyncio, pytest-cov, httpx 

- python-dotenv 

 

### **Frontend**

- **Framework**: Next.js 14 (App Router)
- **UI**: shadcn/ui, Radix UI, Tailwind CSS
- **Visualisation:**
    - React Force Graph (Neo4j)
    - Recharts (ER- Diagram)
- **Language**: TypeScript
- **State Management**: React Context + Hooks

 

### **Data Storage** 

External connections: PostgreSQL, MySQL/MariaDB, SQLite, Neo4j, Elasticsearch (target databases managed and queried by the app) 

 

## **Core Features** 

### **Module 1: Connection Management**

- Connection validation (Postgres, MySQL, SQLite, Neo4j, ES)
- SSL auto-detection (Neon, Supabase, RDS, Aura)
- Schema introspection:
    - Tables, columns, PK/FK
    - Indexes & constraints
    - Sample data & row counts
- Redis-backed schema caching (10-min TTL)

### **Module 2: Query Generation**

- NL → SQL / Cypher generation
- Intent detection & routing
- Relationship analyzer (FK-based graph)
- SQL → Natural Language explanation
- Query optimization suggestions
- Usage stats & history

### **Module 3: Query Executor (Safety-First)**

- Read-only execution by default
- Pagination, execution time, row limits
- EXPLAIN support
- Controlled INSERT / UPDATE with manual opt-in 

## **API Endpoints** 

**Health & Status**  

|     |     |     |
| --- | --- | --- |
| **Endpoint** | **Method** | **Description** |
| Root | GET | Service banner |
| Health Check | GET | System readiness and database state |

 

**Connection API** 

|     |     |     |
| --- | --- | --- |
| **Endpoint** | **Method** | **Description** |
| test | POST | Test a database connection |
| tables | POST | List tables for a given connection |
| schema | POST | Get schema for a specific table |
| data/{database_type} | GET | Paginated data fetch for a table/index (SQL/Neo4j/Elasticsearch) |
| Default | GET | Default connection params |
| prefetch-schema-sqlite | POST | Cache SQLite schema |
| prefetch-schema | POST | Cache database schema |
| validate-sqlite-file | GET | Get default connection params from env (Postgres/MySQL/Elasticsearch/Neo4j/SQLite) |
| test-sqlite | POST | Validate uploaded SQLite file (.db/.sqlite/.sqlite3) |
| tables-sqlite | POST | Validate and test SQLite via uploaded file |
| schema-sqlite | POST | Get schema for one table or all tables from SQLite file |
| data-sqlite | POST | Paginated data from SQLite file |
| execute-sqlite | POST | Execute raw SQL on SQLite file |
| generate-and-execute-sqlite | POST | NL→SQL generation and execution on SQLite with safety |
| execute-insert-sqlite | POST | Manual INSERT on SQLite (optionally return modified DB file) |
| execute-update-sqlite | POST | Manual UPDATE on SQLite (optionally return modified DB file) |

 

**Query Generation APIs**   

|     |     |     |
| --- | --- | --- |
| **Endpoint** | **Method** | **Description** |
| generate-and-execute | POST | NL→SQL generation with schema grounding; execute if safe |
| generate-and-execute-sqlite | POST | NL→SQL for uploaded SQLite; execute if safe |
| execute-insert | POST | Manual INSERT execution |
| execute-update | POST | Manual UPDATE execution |
| explain-sql | POST | Explain SQL query |
| validate-model-config | POST | Validate AI model config |
| explain-question | POST | Explain question for Elasticsearch |

 

**Query Execute API** 

|     |     |     |
| --- | --- | --- |
| execute | POST | Execute SQL query with safety checks |

## **Query Safety Mode**

| Query Type | Behavior |
| --- | --- |
| SELECT | ✅ Allowed |
| EXPLAIN | ✅ Allowed |
| INSERT | ❌ Blocked (manual endpoint only) |
| UPDATE | ❌ Blocked (manual endpoint only) |
| DELETE | ❌ Blocked |
| DROP / TRUNCATE | ❌ Hard blocked |

## **System Workflow** 

 

### **Workflow Explanation** 

 

1\. **User enters database credentials** (host, port, username, password) or uploads SQLite file 

2\. **Web Interface** sends connection request to Backend API Server 

3\. **Backend** connects to the database and tests the connection 

4\. **Database Connection** module retrieves schema information and table structure 

5\. **Connection successful** - User can now ask questions in natural language 

6\. **User enters a question** (e.g., "Show me all users from New York") 

7\. **Web Interface** sends question along with database schema to AI Service 

8\. **AI Service** (Gemini/Groq) uses the schema to understand the database structure 

9\. **AI generates SQL query** based on the natural language question 

10.  **Safety Check** module validates the query: 

\- SELECT queries → ALLOWED and executed 

\- DELETE queries → BLOCKED (shows warning, doesn't execute) 

\- UPDATE queries → BLOCKED (shows warning, manually execute) 

\- INSERT queries → BLOCKED (shows warning, manually execute) 

11\. Query Executor executes only safe queries on the Database 

12\. Database returns the query results 

13\. Results displayed to the user in the Web Interface 

 

**Example Flow** 

 

**Step 1: Connect to Database** 

\- User enters PostgreSQL credentials 

\- System connects and retrieves schema (tables: users, orders, products) 

\- Connection successful ✅ 

 

**Step 2: Ask Question** 

\- User asks, "Show me all users from New York." 

\- AI receives: question + schema (users table with columns: id, name, city, email) 

\- AI generates: `SELECT * FROM users WHERE city = 'New York'` 

\- Safety check: ✅ SELECT is allowed 

\- Database executes: Returns all users from New York 

\- User sees: Results displayed in table format 

 

**Step 3: Blocked Query Example** 

\- User asks, "Delete all users from New York." 

\- AI generates: `DELETE FROM users WHERE city = 'New York'` 

\- Safety check: ❌ DELETE is blocked 

\- Query NOT executed 

\- User sees: Warning message + generated SQL for review 

\- Execute button: Manually execute query