# Git URL

Connect Database:- https://gitlab.inexture.com/ai.inexture/connect_database.git