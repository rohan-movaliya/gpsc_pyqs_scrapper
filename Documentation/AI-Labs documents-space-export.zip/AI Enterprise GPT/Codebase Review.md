# Codebase Review

Prepared By: Rohan Movaliya

Data: 29/05/2026

**GitLab URL**:

Backend URI:- https://gitlab.inexture.com/ai.inexture/ai-enterprise-gpt-backend.git (**Dev** Branch)

- print() Statement ()
- The environment file was not loaded properly, directly take the default value![](files/019e7276-d568-7303-8bbc-fd09ea67999e/image.png)
- Added an import statement between code, Also contains unused imports
- Manually write the model name

![](files/019e7279-e051-73a8-8d1b-9c05ff059617/image.png)

- unnecessary code in the utils file

![](files/019e727d-66ed-747e-852e-137d94943571/image.png)

- unnecessary api

![](files/019e727d-66ed-747e-852e-137d94943571/image.png)