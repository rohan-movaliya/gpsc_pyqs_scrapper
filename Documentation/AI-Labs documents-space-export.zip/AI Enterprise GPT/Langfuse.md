# Langfuse

**Langfuse Infrastructure**

_PostgreSQL, ClickHouse, Worker & Redis Requirements_

To run Langfuse effectively, the Docker deployment requires two distinct database engines to handle different types of data loads, supported by a background worker and a Redis-based queue that keep the system responsive under load.

# 1\. PostgreSQL

PostgreSQL stores information that changes occasionally and is essential for the core application logic.

### Examples of Stored Data

- Users
- Projects
- API Keys
- Organizations
- Roles
- Settings
- Prompt versions
- Datasets (metadata)

### Data Profile

_This is relatively small data._

Project: Enterprise AI  
User: [admin@company.com](mailto:admin@company.com)  
API Key: pk-lf-xxxx  
Secret Key: sk-lf-xxxx

# 2\. ClickHouse

ClickHouse stores every AI request and the full context of what occurred during that request.

### Request Example

**User Query: “What is our leave policy?”**

Stored Metadata:

Trace ID: abc123  
User: john  
Session: session_001  
Model: GPT-4.1  
Question: What is our leave policy?  
Started: 10:30:15  
Ended: 10:30:17  
Latency: 2.1 sec  
Input Tokens: 245  
Output Tokens: 132  
Cost: $0.0032  
Status: Success

### RAG & Multi-Model Execution

If you're using RAG, it also stores:

- Retrieved Documents (e.g., HR_Policy.pdf score: 0.94, Employee_Handbook.pdf score: 0.89)

If you call multiple models, each step is stored as a span:

Trace (Search → Embedding → Vector Search → GPT-4 → Gemini → Final Response)

# Comparison and Rationale

## Why not store everything in PostgreSQL?

PostgreSQL is not optimized for large-scale analytics. Consider a system with:

- 1,000 users
- 100 chats per user per day

**This results in 100,000 traces/day, totaling 36,500,000 traces per year.**

ClickHouse is designed for millions or even billions of records and can answer the following questions very quickly:

- Which model is fastest?
- What is the average latency?
- What is the total token usage?
- Who are the most expensive users?
- What is the error rate?

## Data Allocation Overview

|     |     |     |
| --- | --- | --- |
| **Information** | **PostgreSQL** | **ClickHouse** |
|     |     |     |
| User account | ✓   | ✗   |
|     |     |     |
| Project | ✓   | ✗   |
|     |     |     |
| API keys | ✓   | ✗   |
|     |     |     |
| Trace | ✗   | ✓   |
|     |     |     |
| Token usage | ✗   | ✓   |
|     |     |     |
| Model latency | ✗   | ✓   |
|     |     |     |
| Prompt execution | ✗   | ✓   |
|     |     |     |
| Retrieved RAG documents | ✗   | ✓   |
|     |     |     |
| LLM response | ✗   | ✓   |

  
<br/>

# 3\. Langfuse Worker

The Langfuse Worker processes tracing and analytics in the background so the Langfuse server can continue accepting new requests.

### Without a Worker

The Langfuse server has to complete all of the following before it can respond:

1.  Receive the trace
2.  Store the trace
3.  Process spans
4.  Calculate token usage
5.  Calculate latency
6.  Store analytics in ClickHouse
7.  Update metrics

_Only after doing all of this can it finish processing the request._

### With a Worker

The server simply:

1.  Receives the trace.
2.  Places it into a background queue.
3.  Immediately becomes available for the next request.

_The worker then processes the trace asynchronously._

### Example

Imagine two users send requests at almost the same time.

**Without a Worker**

User 1 → Langfuse Server:  
Store trace  
Process spans  
Calculate tokens  
Store in ClickHouse  
Finish  
<br/>(User 2 waits until the server is available. The server is busy  
doing background work before it can fully handle the next request.)

**With a Worker**

User 1 → Langfuse Server:  
Accept trace  
Send job to Worker  
Ready immediately  
(User 2 request)  
<br/>At the same time — Langfuse Worker:  
Store trace  
Process spans  
Calculate token usage  
Calculate latency  
Store analytics  
Update metrics  
<br/>(The server continues serving new users while the worker handles  
the background processing.)

### Real-world Analogy

Think of a restaurant.

_Without a worker: one person must take the customer's order, cook the food, prepare the bill, and serve the customer. If more customers arrive, they have to wait._

_With a worker: the waiter (Langfuse Server) takes the order and immediately serves the next customer, while the chef (Langfuse Worker) prepares the food in the kitchen. This division of work keeps the restaurant running efficiently._

# 4\. Redis

Redis is an in-memory database used as a message queue and cache. For Langfuse, the worker and server use Redis to communicate.

### Without Redis

Langfuse Server:  
Process trace  
Store trace  
Calculate metrics  
<br/>(The server does everything itself.)

### With Redis

1\. Langfuse Server receives trace.  
2\. Server puts job into Redis Queue.  
3\. Server is ready for next request.  
4\. Langfuse Worker takes job from Redis Queue.  
5\. Worker processes trace, calculates metrics, and stores analytics.

### Analogy

_Think of Redis as a waiting line (queue). The server says: “Here's a new job.” The worker says: “I'll take the next job from the queue.”_

#   
<br/>