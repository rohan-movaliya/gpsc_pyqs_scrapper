# GitLab URL's

Frontend URl:- https://gitlab.inexture.com/ai.inexture/ai-enterprise-gpt-frontend.git  
Backend URI:- https://gitlab.inexture.com/ai.inexture/ai-enterprise-gpt-backend.git

Setup guide for the backend and frontend can be founded in the readme of both repositories