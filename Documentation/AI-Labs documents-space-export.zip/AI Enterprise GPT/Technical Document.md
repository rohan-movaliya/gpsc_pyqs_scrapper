# Technical Document

## **1\. System Overview**

AI Enterprise GPT is a web-based, microservice-oriented application designed to provide secure, role-based access to Large Language Models (LLMs) and internal document knowledge. It consists of a **React.js** frontend (using Vite and Shadcn/UI), a **FastAPI** backend (Python 3.10+), a **PostgreSQL** relational database for user/role management, and an **OpenSearch** vector database for RAG operations. Background tasks (like email sending or long-running processing) are handled asynchronously within FastAPI.

## **2\. Technology Stack**

| **Layer** | **Technology** | **Purpose** |
| --- | --- | --- |
| **Frontend** | React.js, TypeScript, Tailwind CSS, Shadcn/UI | Responsive user interface, Chat UI, Admin dashboards |
| **Backend** | FastAPI (Python), Pydantic, Injector | REST API, Business logic, Dependency Injection |
| **Database** | PostgreSQL, SQLAlchemy | Persistent storage for Users, Roles, Permissions, Chats |
| **Vector Store** | OpenSearch | Storing document embeddings for Semantic Search (RAG) |
| **AI Layer** | LlamaIndex, LangChain, OpenAI/Gemini APIs, HuggingFace | LLM orchestration, Embedding generation, Context retrieval |
| **Deployment** | Docker, Docker Compose, Nginx | Containerization, Reverse Proxy, Service Orchestration |
| **Authentication** | OAuth2 (JWT), Passlib (Bcrypt) | Stateless authentication, Password hashing |
| **Testing** | Pytest, Httpx | Backend unit and integration testing |

## **3\. Data Flow Summary**

### **3.1 User Flow**

1.  **Authentication**: User logs in via `/auth/login`. System verifies credentials against PostgreSQL and issues a JWT Access Token.
2.  **Authorization**: Every subsequent request includes the JWT. The backend's `Depend(require_permission(...))` checks if the user's Role has the necessary Permission.
3.  **Chat Interaction**: User sends a message via `/api/v1/llm/completions`.
    - Backend checks `can_chat` permission.
    - User's message is sent to the LLM service (OpenAI/Anthropic/Local).
    - Response is streamed back to the frontend event-by-event.
4.  **Admin Management**: Admin accesses `/users` or `/roles`.
    - Backend checks `can_manage_users` permission.
    - Admin creates a new Role or updates User permissions.

### **3.2 AI Model Workflow (RAG)**

1.  **Ingestion**: User uploads a PDF via `/api/v1/ingest`.
    - File is parsed using `Docling` or `Unstructured`.
    - Text chunks are converted to vectors using an Embedding Model (e.g., `text-embedding-3-small`).
    - Vectors are stored in **OpenSearch**.
2.  **Retrieval**: User asks a question in "RAG Mode".
    - Query is converted to a vector.
    - System searches **OpenSearch** for the top-k most similar text chunks.
    - Chunks are injected into the LLM context window ("Context: ... Answer: ...").
    - LLM generates a grounded response with citations.

## **4\. Database Design (High-Level)**

The system uses **SQLAlchemy** ORM. Key tables include:

### **Core Tables**

- **users**:**id**,**email**, `password_hash`, `first_name`, `is_verified`
- **roles**:**id**, `name`, `description` ("Admin", "Employee", etc.)
- **permissions**:**id**, `resource` (e.g., "chat", "users"), `action` (e.g., "read", "create")
- **user_roles**: User-to-Role many-to-many link.
- **role_permissions**: Role-to-Permission many-to-many link.

### **Chat & AI Tables**

- **conversations**:**id**, `user_id`, `title`, `created_at`
- **messages**:**id**, `conversation_id`,**role** ("user"/"assistant"), `content`
- **models**:**id**, `name`, `provider` (OpenAI, Local), `api_key` (encrypted)

## **5\. Key APIs**

### **Authentication**

- `POST /auth/register`: Register a new user account.
- `POST /auth/login`: Authenticate and receive JWT.
- `POST /auth/email/verify-email`: Verify account via OTP.
- `GET /auth/me`: Get current user profile and permissions.

### **Role-Based Access Control**

- `POST /roles/`: Create a new role (Admin only).
- `POST /permissions/assign`: Assign permissions to a role.
- `GET /users`: List all users (Admin only).

### **AI & Chat**

- `POST /api/v1/llm/completions`: Send a prompt to the LLM (Streaming).
- `GET /api/v1/llm/conversations`: List user's past chats.
- `POST /api/v1/rag/ingest`: Upload and index a document.
- `POST /api/v1/search/`: Semantic search across uploaded documents.

## **6\. Security Design**

- **JWT-Based Auth**: Stateless sessions; tokens expire and must be refreshed.
- **Password Security**: All passwords are hashed with **Bcrypt** before storage.
- **Dependency Injection**: Security logic is injected into routes, making it impossible to "forget" a permission check.
- **Environment Variables**: API keys and secrets are loaded from**.env** files, never hardcoded.
- **Token Blacklisting**: Logout action invalidates the current token by adding it to a Redis/DB blacklist.

## **7\. Future Technical Enhancements**

- **Redis Caching**: Implement Redis for caching frequent permission checks and user sessions to reduce DB load.
- **WebSocket Support**: Upgrade chat from HTTP Streaming to full WebSockets for bi-directional communication (interrupting generation).
- **Celery Workers**: Offload heavy document ingestion tasks to a dedicated worker queue (currently running as background tasks).
- **GraphRAG**: Implement Knowledge Graph extraction to improve multi-hop reasoning on complex documents.