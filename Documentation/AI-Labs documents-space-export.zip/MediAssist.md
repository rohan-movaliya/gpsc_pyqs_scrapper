# MediAssist

# 🏥 **Hospital AI Voice Chatbot — Multi-Agent Architecture**

---

## 🧠 **What**

An AI-powered, voice-enabled IVR system built on FastAPI that automates healthcare appointment workflows through natural, conversational interactions. The platform leverages a multi-agent architecture, supervised orchestration, and enterprise-grade security to deliver seamless appointment booking, symptom-based doctor routing, and lifecycle management.

---

## 🎯 **Why**

### Unlock operational efficiency with:

- 🗣️ Natural voice-driven patient engagement
- 🤖 Multi-agent intelligence for intent routing and task specialization
- ⚡ Automated appointment lifecycle from symptoms → booking → confirmation
- 🔐 Hardened security: JWT, RBAC, audit logs, and rate limiting
- 💬 Contextual conversation management via LangChain/LangGraph
- 📊 Hybrid storage strategy using PostgreSQL (structured) + MongoDB (chat sessions)

---

## ⚙️ **How It Works**

1.  **Patient Auth** → User registers/logs in, receives JWT
2.  **Voice Call** → Inbound/outbound via Twilio
3.  **Speech-to-Text** → Twilio transcribes and forwards text
4.  **Intent Routing** → Supervisor agent classifies request
5.  **Task Execution** → Booking/Patient/Doctor agents run required operations
6.  **Response Generation** → LLM produces human-like conversational output
7.  **Voice Output** → Twilio plays the synthesized voice
8.  **Session Logging** → MongoDB stores full conversation history

---

# 🧱 **Tech Stack Overview**

---

## 🖥️ Backend Framework

| Technology | Purpose |
| --- | --- |
| **FastAPI** | Async REST API framework |
| **Uvicorn** | ASGI server |
| **Python 3.x** | Core application logic |

---

## 🗄️ Database & Storage

| Technology | Purpose |
| --- | --- |
| **PostgreSQL + SQLAlchemy** | Appointments, patients, doctors, roles |
| **pgvector** | Doctor-symptom semantic matching |
| **MongoDB (Motor)** | Chat history, session logs |
| **Alembic** | Schema migrations |

---

## 🔐 Authentication & Security

| Technology | Purpose |
| --- | --- |
| **JWT** | Token-based authentication |
| **bcrypt** | Password hashing |
| **RBAC** | Access control |
| **Audit Logging** | Compliance trail |
| **Redis Rate Limiting** | Abuse prevention |

---

## 🤖 AI Services & Frameworks

| Service | Purpose |
| --- | --- |
| **LangChain** | LLM orchestration |
| **LangGraph** | Multi-agent state management |
| **OpenAI API** | NLP, embeddings |
| **Groq API** | Low-latency inference |
| **Vector Embeddings** | Semantic doctor search |

---

## 🎤 Voice Integration

| Technology | Purpose |
| --- | --- |
| **Twilio Voice** | Phone call handling |
| **TwiML** | Voice response formatting |

---

## 🔧 Utilities & Support

| Tool | Purpose |
| --- | --- |
| **Pydantic** | Data validation |
| **python-dotenv** | Env configuration |
| **Redis** | Caching, sessions |
| **Async/Await** | High throughput |
| **pytest** | Automated testing |

---

## 🚀 Deployment

| Tool | Purpose |
| --- | --- |
| **Docker / Docker Compose** | Containerized deployment |
| **pgvector** | Embedded vector search |
| **Health Checks** | Observability & uptime |

---

# 🧭 **Architecture Summary**

| Component | Role |
| --- | --- |
| **FastAPI** | Core API for auth, appointments, voice |
| **LangGraph Supervisor** | Intent routing |
| **Booking Agent** | Appointment lifecycle |
| **Patient Agent** | Patient queries, history |
| **Doctor Agent** | Doctor search & schedule insights |
| **PostgreSQL** | Structured data |
| **MongoDB** | Conversation logs |
| **Redis** | Performance optimization |
| **Twilio** | Voice pipeline |
| **OpenAI / Groq** | Natural language understanding |
| **pgvector** | Symptom-to-doctor semantic matching |

---

# ✨ **Key Highlights**

- 🤖 Supervisor-driven multi-agent system
- 🗣️ Voice-first patient experience
- 🧠 Intelligent doctor matching via vector embeddings
- ⚡ Fully asynchronous & scalable
- 🔒 Enterprise-grade authentication, RBAC, and audit trails
- 💬 Context-aware conversations with LangChain/LangGraph
- 📊 Hybrid database (SQL + NoSQL)
- 🧩 Pluggable, modular architecture
- 🚀 Production-ready Docker setup

---

# 💡 **Ideal Use Cases**

- 🏥 Hospital Appointment Automation
- 📞 Healthcare IVR Systems
- 🤖 AI-Powered Patient Assistants
- 💊 Clinic Management Solutions
- 🏥 Multi-Department Scheduling Platforms
- 🩺 Telemedicine Coordination Systems