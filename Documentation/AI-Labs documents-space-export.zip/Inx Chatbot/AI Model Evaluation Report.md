# AI Model Evaluation Report

## **1\. Models Overview**

### **1\. meta-llama/llama-4-maverick-17b-128e-instruct**

**Type:** Chat / Reasoning

**Why We Chose It:**  
Open-source, fast performance, and a low-cost option for experimentation.

**Observations:**

- Good speed and decent reasoning
- Struggles with long-context accuracy
- Not reliable with tool calling
- Sometimes triggers tools even when not required

**Why We Stopped:**  
Hallucinations, unstable outputs in production flows, and unreliable tool usage.

**Summary:**  
Good for experimentation, but not reliable enough for enterprise workflows.

### **2\. openai/gpt-oss-120b**

**Type:** Chat / Reasoning

**Why We Chose It:**  
Large open-source model designed for strong reasoning tasks.

**Observations:**

- Strong and detailed responses
- Very high latency and heavy resource usage
- Asks too many clarifying questions
- After tool calling, it often takes too long to decide the next step
- Heavy resource load causes confusion in multi-step agent flows

**Why We Stopped:**  
Too slow, expensive to run, and inconsistent in long tool-agent loops.

**Summary:**  
High-quality responses and good at tool calling, but not practical for fast conversational workloads.

### **3\. openai/gpt-oss-20b**

**Type:** General Chat

**Why We Chose It:**  
A smaller and more affordable version of the 120B model.

**Observations:**

- Faster than 120B
- Significant drop in response quality
- Weak reasoning and low accuracy
- Often takes too long to respond
- When a tool returns an error, it repeatedly calls the tool in a loop
- Struggles with dates and times
- Poor multilingual performance

**Why We Stopped:**  
Not fully stopped, still used in two agents, including a common agent, but not preferred for production-critical workflows.

**Summary:**  
Useful for limited internal agents, but not suitable for production-grade tasks due to inconsistency.

### **4\. gpt-5.1-mini**

**Type:** Lightweight Chat Model

**Why We Chose It:**  
Very cost-effective for high-volume requests.

**Observations:**

- Extremely fast
- Good for small, simple tasks
- Limited reasoning abilities
- Not suitable for complex agent behavior

**Why We Stopped:**  
Does not meet the depth required for enterprise conversations or multi-step workflows.

**Summary:**  
Best for very simple tasks, not complex dialogs.

### **5\. gpt-5.1**

**Type:** Advanced Chat + Reasoning

**Why We Chose It:**  
High reasoning ability, strong accuracy, and good Hindi support.

**Observations:**

- Stable and consistent
- Very low hallucination rate
- Excellent for structured and rule-based tasks
- Sometimes asks too many questions and does not follow the prompt strictly

**Why We Stopped:**  
Stopped due to too many unnecessary questions, which impacted flow.

**Summary:**  
Strong and reliable model, but discontinued because of excessive questioning behavior.

### **6\. gpt-4.1**

**Type:** General Chat

**Why We Chose It:**  
A stable and widely used baseline model.

**Observations:**

- Stable and reliable
- Older generation model compared to GPT-5 series

**Summary:**  
A dependable model, still used for certain tasks.

## **2\. Comparison Table**

| Model | Type | Performance | Reason Dropped | Notes |
| --- | --- | --- | --- | --- |
| Llama-4 Maverick 17B | Chat | Medium | Hallucination, unstable | Good speed |
| GPT-OSS 120B | Chat | High | Too slow, costly | Strong reasoning, good tool-calling |
| GPT-OSS 20B | Chat | Low | Poor accuracy | Not production-ready |
| GPT-5.1 Mini | Chat | Medium | Limited reasoning | Best for small tasks |
| GPT-5.1 | Chat | High | Too many questions | Very stable |
| GPT-4.1 | Chat | High | —   | Still in use |

## **3\. Final Notes**

**Most Reliable Models:**

- gpt-4.1

**Models Rejected:**

- Llama-4 Maverick 17B
- GPT-OSS 20B
- GPT-OSS 120B