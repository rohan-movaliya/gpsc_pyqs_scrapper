# GitLab Link

backend - https://gitlab.inexture.com/ai.inexture/Inexture_portal_chatbot.git

frontend - https://gitlab.inexture.com/ai.inexture/frontend/inexture_portal_chatbot_front_end.git