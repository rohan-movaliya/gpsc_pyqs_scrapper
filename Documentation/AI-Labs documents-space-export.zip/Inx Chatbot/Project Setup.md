# Project Setup

This document guides you through setting up a local development environment for the INX Chatbot Backend. Follow the steps below so that each section builds on the previous one.

## Prerequisites

- Python 3.10 or newer (3.11 recommended)
- `pip` and `venv` from the Python standard library
- Git client with access to the project repository
- Redis 6+ running locally or reachable from your machine (optional but required for full feature testing)
- API credentials for Groq and Google Generative AI
- (Optional) Access to company policy PDFs for rebuilding the semantic vector store

## 1\. Clone The Repository

```
git clone https://gitlab.inexture.com/Dev/inx-chatbot.git
cd inx-chatbot-backend
```

If you are working inside an existing monorepo, make sure you are in the backend directory before continuing.

## 2\. Create A Virtual Environment

```
python3 -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
```

Keeping dependencies isolated avoids conflicts with other projects and ensures reproducible installs.

## 3\. Install Dependencies

Upgrade `pip` first, then install the Python dependencies.

```
pip install --upgrade pip
pip install -r requirements.txt
```

If you plan to run tests that generate coverage reports, consider installing the optional development tooling listed in `pyproject.toml` under the `tool.poetry.group.dev` section (if present) or the `requirements-dev.txt` file when available.

## 4\. Configure Environment Variables

1\. Start from the example file:

```
cp .env.example .env
```

2\. Populate the new `.env` with at least the required keys:

```
GOOGLE_API_KEY=your_google_api_key
GROQ_API_KEY=your_groq_api_key
MODEL_PROVIDER=groq            # or gemini
CHATBOT_PORT=8001
```

3\. Configure optional values (Redis, PMS base URLs, logging) as needed. Refer to `docs/environment-configuration.md` for the full list of supported variables and recommended profiles for development, staging, and production.

> ℹ️ The application loads `.env` automatically; no additional tooling is required.

## 5\. Prepare External Services

- **Redis**: Start a Redis instance locally (`redis-server`) or point the environment variables at an existing host. Without Redis the application will fall back to in-memory caches, but features like leave/worklog context caching will be limited.
- **Policy PDFs**: Ensure the `data/source/policy_pdf` directory contains the policy documents that should populate the semantic vector store. The repository may already include sample PDFs; replace them with the latest versions if necessary.

## 6\. Optional: Build/Refresh The Vector Store

The backend can automatically rebuild the policy vector database on first run when the PDFs and `GOOGLE_API_KEY` are available. To trigger a manual rebuild (recommended after updating PDFs):

```
python app/ai/vector_db_creator.py
```

Progress and statistics are written to `log/vector_db_creation.log` and `data/embeddings/policy_vector_database/creation_stats.json`.

If you prefer the non-blocking auto-creation flow, call the helper instead:

```bash
python -m app.ai.auto_vector_db_creator
```

The helper reports whether prerequisites are met and starts background generation when possible.

## 7\. Run The Application

With the virtual environment activated and `.env` configured, start the FastAPI server:

```
python main.py
```

Visit `http://localhost:8001/docs` to inspect the interactive OpenAPI documentation. Adjust the host/port to match your deployment or container environment.

## 8\. Run The Test Suite

Execute the automated tests before opening merge requests or deploying:

```
pytest
```

Helpful variants:

```
pytest tests/test_integration -v
pytest --cov=app --cov-report=term-missing --cov-report=html
```

The HTML report is generated in `htmlcov/index.html` and can be viewed in a browser.

## 9\. Common Troubleshooting Tips

- **Missing API keys**: Check that `GOOGLE_API_KEY` and `GROQ_API_KEY` are present and correctly spelled in `.env`.
- **Redis errors**: Verify the server is running and the connection settings (`REDIS_HOST`, `REDIS_PORT`, `REDIS_PASSWORD`) are accurate.
- **Model selection issues**: Ensure `MODEL_PROVIDER` matches the models declared in your `.env`. Switching between Groq and Gemini requires updating the per-agent model variables.
- **Vector DB missing**: Re-run the vector store creation script or confirm the auto-creator succeeds. Logs in `log/vector_db_creation.log` provide detailed diagnostics.