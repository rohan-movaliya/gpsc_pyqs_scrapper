# Technical Document 

**1\. Overview** 

The INX Chatbot powers conversational workflows across Leave, WFH, policy, and Worklog domains. It follows a modular, layered architecture leveraging FastAPI for APIs, LangGraph for orchestration, and Redis/ChromaDB for caching and retrieval. The design emphasizes scalability, observability, and maintainability with specialized tools, state checkpointing, and high test coverage. 

**2\. Tech Stack** 

|     |     |
| --- | --- |
| **Layer** | **Technology** |
| **Backend Framework** | FastAPI (Starlette, Pydantic v2) |
| **Orchestration** | LangGraph, LangChain, LangSmith |
| **LLM Providers** | Groq (primary), Google Gemini (optional fallback) |
| **Vector Store** | ChromaDB (local embeddings) |
| **Caching/State** | Redis (context + LangGraph checkpointing) |
| **Web Server** | Uvicorn |
| **Testing** | Pytest, pytest-cov |
| **Logging/Observability** | structlog, HTML coverage reports |
| **Configuration** | dotenv + pyproject metadata |

 

**3\. Application Structure** 

app/   
├── ai/           # Graphs, agents, model configs, and domain tools   
├── apis/         # Domain-specific API modules (routes, schemas, services)   
├── core/         # Constants, cache/context managers, background refresh logic   
├── data/         # Embeddings, documents, and generated outputs   
├── docs/         # Configuration & error handling documentation   
└── tests/        # Unit, integration, and prompt adherence tests 

**4\. Architecture and Flow** 

- **Supervisor agent** routes user intent to domain agents (Leave, WFH, Worklog, Policy, Common). 

- **LangGraph memory state** ensures continuity with token-efficient checkpointing. 

- **Domain tools** enable structured interactions and error isolation per domain. 

- **Redis caching** accelerates responses and reduces external API dependency. 

- **Chroma retrieval** supports contextual policy Q&A and document reasoning. 

**5\. AI Layer (Agents and Orchestration)** 

- **Supervisor Agent** – routes and prioritizes conversation flows 

- **Specialized Agents** – domain experts (Policy, Leave, WFH, Worklog, Common) 

- **Memory Management** – uses summarization and checkpointing to maintain history efficiently 

- **Model Configuration** – environment-driven model/provider selection 

 

**6\. Domain Tools and Context Integration** 

|     |     |
| --- | --- |
| **Domain** | **Capabilities** |
| **Leave Tools** | Apply leave, view balance/history, check conflicts, approval workflows |
| **WFH Tools** | Apply WFH, view balances, history, and approval requests |
| **Worklog Tools** | Add logs, fetch pending logs, retrieve past entries |
| **Context Tools** | Fetch and validate domain data from Redis cache |

 

**7\. Caching and Background Processing** 

- **Context Managers** maintain session, leave, WFH, and worklog caches 

- **Cache Expiry Policy** ensures consistency with external PMS APIs 

**8\. Data and Retrieval Pipeline** 

- **Document Ingestion**: PDFs → text cleaning → normalization → chunking → embedding 

- **Quality Enhancements**: Removes noise, fixes sentence boundaries, filters low-quality segments 

- **Vector Storage**: ChromaDB local persistence for fast and reliable retrieval 

**9\. Key Dependencies** 

- **Core**: fastapi, uvicorn, pydantic 

- **AI Stack**: langgraph, langchain, langsmith 

- **Models**: groq, google-generativeai 

- **Storage**: chromadb, redis 

- **Testing**: pytest, pytest-cov 

- **Logging**: structlog 

**10\. API Endpoints** 

|     |     |     |
| --- | --- | --- |
| **Method** | **Endpoint** | **Purpose/Use** |
| GET | /   | Health check — returns API status and version |
| POST | /chatbot | Process chatbot queries — validates session, runs LangGraph, stores interaction, returns bot response |
| POST | /create-session | Create new chatbot session — validates access token, initializes session data, required before chatbot interactions |
| DELETE | /destroy-session/{session_id} | Destroy session — cleans up session data, memory, and cache (call on logout) |
| GET | /user-profile/{user_id} | Get user profile and context information |
| GET | /user-request-to/{user_id} | Get user's request_to data (approvers list) |
| GET | /user-my-tasks/{user_id} | Get user's my_tasks data |
| GET | /user-my-leaves/{user_id} | Get user's my_leaves data |
| GET | /user-my-wfh/{user_id} | Get user's my_wfh (work from home) data |
| GET | /debug/sessions | List all active sessions (debugging) — returns session details and counts |

 

 

 

 

 

.