# Requirement Document

**1\. Overview** 

The INX Chatbot provides conversational access to HR and workplace services such as Leave Management, Work From Home (WFH), and Worklog Management, along with utility tools (e.g., calculator) and intelligent agent capabilities with memory. 

It exposes REST API endpoints for integration and supports tool-based actions through an AI-driven agent layer. 

**2\. Goals and Scope** 

- Enable employees to self-serve common HR and workplace tasks via natural language. 

- Automate routine queries such as applying for leave, checking balances, and managing WFH requests. 

- Reduce operational overhead for HR and admin teams. 

- Provide an extensible tool framework for adding new chatbot capabilities and integrations. 

**3\. Functional Requirements** 

**3.1 Leave Management** 

- **Apply Leave:** Allows users to create a leave request specifying leave type, dates, and reason. Validates balance and policy rules before submission. 

- **Check Leave Balance:** Retrieves current leave balances for each leave type. 

- **Check Leave Status:** Displays all leave requests with their current status (Pending, Approved, Rejected). Supports filters by date range or leave type. 

- **List Upcoming Leaves:** Displays all approved upcoming leaves for the user or team (if manager). Can optionally send reminders or summaries. 

- **Check Employees on Leave Today:** Lists employees who are currently on leave for the day, categorized by department or team. 

- **Leave Policy Queries:** Provides FAQs and responses about leave rules, accrual, carry-forward, holidays, and blackout dates. 

- **Check Leave Requests (for Management):** Enables upper management or HR to view and review employee leave requests. 

**3.2 Work From Home (WFH)** 

- **Apply WFH:** Submit WFH requests specifying date(s) and reason. Validates policy rules (e.g., maximum days, advance notice). 

- **Check WFH Status:** Shows pending, approved, or rejected WFH requests. 

- **Check Employees on WFH Today:** Displays the list of employees working from home today, organized by department or team. 

- **WFH Policy Queries:** Answers FAQs regarding eligibility, approval process, and WFH frequency limits. 

- **Check WFH Requests (for Management):** Enables upper management or HR to view and review employee WFH requests, including pending, approved, and rejected statuses. 

**3.3 Worklog Management** 

- **Submit Worklog:** Allows users to log daily work details including date, hours, project/task name, and description. Validates minimum/maximum hours and date range. 

- **View Worklog:** Lists worklog entries filtered by date range, project, or status. Supports daily and weekly summaries. 

**3.4 Policy Queries (User-Facing)** 

- Users can ask general questions related to company policies, HR guidelines, and organizational procedures. 

- The chatbot retrieves policy-related information dynamically or from pre-configured sources.