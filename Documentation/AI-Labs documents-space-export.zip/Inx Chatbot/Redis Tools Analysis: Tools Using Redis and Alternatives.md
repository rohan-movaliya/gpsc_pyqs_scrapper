# Redis Tools Analysis: Tools Using Redis and Alternatives

## Overview

This document analyzes all tools in the INX Chatbot Backend that use Redis, identifies which ones are Redis-only (no fallback), and provides alternatives for each use case.

---

## Summary

### Tools Using Redis: **15+ tools**

### Redis-Only Tools (No Fallback): **3 tools**

1.  `refresh_leave_cache()` - Cache refresh operation
2.  `refresh_wfh_cache()` - Cache refresh operation
3.  `clear_leave_cache()` / `clear_wfh_cache()` - Cache clearing operations

### Tools with Fallback Mechanisms: **12+ tools**

All other tools have fallback to session manager or direct API calls when Redis is unavailable.

---

## Detailed Analysis

### 1\. Leave Context Tools

#### Tools with Redis + Fallback:

| Tool | Primary Source | Fallback Mechanism | Status |
| --- | --- | --- | --- |
| `get_leave_summary()` | Redis cache | Falls back to `get_user_my_leaves_data()` from session manager | ✅ Has Fallback |
| `get_leave_status_for_date()` | Redis cache | Falls back to `get_user_my_leaves_data()` from session manager | ✅ Has Fallback |
| `get_recent_leaves()` | Redis cache | Falls back to `get_user_my_leaves_data()` from session manager | ✅ Has Fallback |
| `check_leave_conflict()` | Redis cache | Falls back to `get_user_my_leaves_data()` from session manager | ✅ Has Fallback |

**Fallback Implementation:**

```python
# From leave_context_manager.py
def get_user_leaves_from_cache(self, user_id: str, force_refresh: bool = False):
    if not self.redis_client or force_refresh:
        # Fallback to session manager
        leaves_data = get_user_my_leaves_data(user_id)
        return leaves_data.get("results", [])
    
    # Try Redis cache
    cached_data = self.redis_client.get(cache_key)
    if not cached_data:
        # Cache miss - fallback to session manager
        leaves_data = get_user_my_leaves_data(user_id)
        return leaves_data.get("results", [])
```

#### Redis-Only Tools:

| Tool | Purpose | Why Redis-Only | Alternative |
| --- | --- | --- | --- |
| `refresh_leave_cache()` | Force refresh Redis cache | Cache management operation | Direct API call via `get_user_my_leaves_data()` |
| `clear_leave_cache()` | Clear Redis cache | Cache management operation | No direct alternative needed |

**Alternative for Cache Refresh:**

- Instead of `refresh_leave_cache()`, call `get_leave_summary()` with `force_refresh=True` parameter
- Or directly call `get_user_my_leaves_data(user_id)` from session manager

---

### 2\. WFH Context Tools

#### Tools with Redis + Fallback:

| Tool | Primary Source | Fallback Mechanism | Status |
| --- | --- | --- | --- |
| `get_wfh_summary()` | Redis cache | Falls back to `get_user_my_wfh_data()` from session manager | ✅ Has Fallback |
| `get_wfh_status_for_date()` | Redis cache | Falls back to `get_user_my_wfh_data()` from session manager | ✅ Has Fallback |
| `check_wfh_conflict()` | Redis cache | Falls back to `get_user_my_wfh_data()` from session manager | ✅ Has Fallback |

**Fallback Implementation:**

```python
# From wfh_context_manager.py
def get_user_wfh_from_cache(self, user_id: str, force_refresh: bool = False):
    if not self.redis_client or force_refresh:
        # Fallback to session manager
        wfh_data = get_user_my_wfh_data(user_id)
        return wfh_data.get("results", [])
    
    # Try Redis cache with fallback
    # ... (similar pattern)
```

#### Redis-Only Tools:

| Tool | Purpose | Alternative |
| --- | --- | --- |
| `refresh_wfh_cache()` | Force refresh Redis cache | Direct API call via `get_user_my_wfh_data()` |
| `clear_wfh_cache()` | Clear Redis cache | No direct alternative needed |

---

### 3\. Worklog Context Tools

#### Tools with Redis + Fallback:

| Tool | Primary Source | Fallback Mechanism | Status |
| --- | --- | --- | --- |
| `get_user_tasks_from_cache()` | Redis cache | Falls back to `get_user_my_tasks_data()` from session manager | ✅ Has Fallback |
| `find_task_by_name()` | Redis cache | Falls back to `get_user_my_tasks_data()` from session manager | ✅ Has Fallback |
| `find_task_by_id()` | Redis cache | Falls back to `get_user_my_tasks_data()` from session manager | ✅ Has Fallback |
| `get_available_projects()` | Redis cache | Falls back to `get_user_my_tasks_data()` from session manager | ✅ Has Fallback |

**Fallback Implementation:**

```python
# From worklog_context_manager.py
def get_user_tasks_from_cache(self, user_id: str, force_refresh: bool = False):
    if not self.redis_client or force_refresh:
        # Fallback to session manager
        tasks_data = get_user_my_tasks_data(user_id)
        return tasks_data
    
    # Try Redis cache with fallback
    # ... (similar pattern)
```

---

### 4\. User Profile Cache Tools

#### Tools with Redis + Fallback:

| Tool | Primary Source | Fallback Mechanism | Status |
| --- | --- | --- | --- |
| `get_user_profile_from_redis()` | Redis cache | Falls back to `fetch_user_profile()` API call | ✅ Has Fallback |
| `store_user_profile_in_redis()` | Redis cache | Falls back to in-memory storage (if needed) | ✅ Has Fallback |

**Fallback Implementation:**

```python
# From session_manager.py
def get_user_profile_from_redis(user_id: str) -> dict:
    if not redis_client:
        return {}  # Fallback to API fetch
    
    profile_json = redis_client.get(profile_key)
    if not profile_json:
        return {}  # Cache miss - fallback to API fetch
    
    # Return cached data
    return enhanced_data.get("profile_data", {})
```

---

## Alternatives to Redis

### Option 1: In-Memory Cache (Python Dictionary)

**Pros:**

- ✅ No external dependencies
- ✅ Zero latency (in-process)
- ✅ Simple implementation
- ✅ Works immediately

**Cons:**

- ❌ Lost on server restart
- ❌ Not shared across multiple instances
- ❌ Memory limited by server RAM
- ❌ No automatic TTL (manual cleanup needed)

**Implementation:**

```python
# Simple in-memory cache
from datetime import datetime, timedelta
from typing import Dict, Optional

class InMemoryCache:
    def __init__(self):
        self._cache: Dict[str, Dict] = {}
    
    def get(self, key: str) -> Optional[Dict]:
        entry = self._cache.get(key)
        if entry and entry['expires_at'] > datetime.now():
            return entry['data']
        if entry:
            del self._cache[key]  # Expired
        return None
    
    def setex(self, key: str, ttl_seconds: int, value: Dict):
        self._cache[key] = {
            'data': value,
            'expires_at': datetime.now() + timedelta(seconds=ttl_seconds)
        }
    
    def delete(self, key: str):
        self._cache.pop(key, None)

# Usage
in_memory_cache = InMemoryCache()
```

**When to Use:**

- Single-server deployments
- Development/testing environments
- Low-traffic applications
- When Redis is unavailable

---

### Option 2: PostgreSQL with JSONB

**Pros:**

- ✅ Persistent storage (survives restarts)
- ✅ Shared across instances
- ✅ ACID guarantees
- ✅ Complex queries possible
- ✅ Already in your stack (likely)

**Cons:**

- ❌ Slower than Redis (disk I/O)
- ❌ More complex setup
- ❌ Requires database schema
- ❌ Higher latency (5-10ms vs 1-2ms)

**Implementation:**

```python
# PostgreSQL cache table
CREATE TABLE cache_store (
    key VARCHAR(255) PRIMARY KEY,
    value JSONB NOT NULL,
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_cache_expires ON cache_store(expires_at);

# Python implementation
import psycopg2
from datetime import datetime, timedelta
import json

class PostgreSQLCache:
    def __init__(self, connection_string: str):
        self.conn = psycopg2.connect(connection_string)
    
    def get(self, key: str) -> Optional[Dict]:
        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT value FROM cache_store 
            WHERE key = %s AND expires_at > NOW()
        """, (key,))
        result = cursor.fetchone()
        cursor.close()
        return json.loads(result[0]) if result else None
    
    def setex(self, key: str, ttl_seconds: int, value: Dict):
        cursor = self.conn.cursor()
        expires_at = datetime.now() + timedelta(seconds=ttl_seconds)
        cursor.execute("""
            INSERT INTO cache_store (key, value, expires_at)
            VALUES (%s, %s, %s)
            ON CONFLICT (key) DO UPDATE SET
                value = EXCLUDED.value,
                expires_at = EXCLUDED.expires_at
        """, (key, json.dumps(value), expires_at))
        self.conn.commit()
        cursor.close()
    
    def delete(self, key: str):
        cursor = self.conn.cursor()
        cursor.execute("DELETE FROM cache_store WHERE key = %s", (key,))
        self.conn.commit()
        cursor.close()
```

**When to Use:**

- Already using PostgreSQL
- Need persistence without Redis
- Want ACID guarantees
- Complex query requirements

---

### Option 3: Memcached

**Pros:**

- ✅ Similar to Redis (key-value store)
- ✅ Simpler than Redis (fewer features)
- ✅ Lower memory overhead
- ✅ Good for pure caching

**Cons:**

- ❌ No persistence (data lost on restart)
- ❌ No complex data structures
- ❌ No built-in TTL (manual expiry)
- ❌ Another external dependency

**Implementation:**

```python
import memcache

class MemcachedCache:
    def __init__(self, servers: List[str]):
        self.client = memcache.Client(servers)
    
    def get(self, key: str) -> Optional[Dict]:
        return self.client.get(key)
    
    def setex(self, key: str, ttl_seconds: int, value: Dict):
        self.client.set(key, value, time=ttl_seconds)
    
    def delete(self, key: str):
        self.client.delete(key)
```

**When to Use:**

- Need simple key-value caching
- Don't need Redis features (pub/sub, lists, etc.)
- Want lower memory usage
- Pure caching use case

---

### Option 4: File-Based Cache

**Pros:**

- ✅ No external dependencies
- ✅ Persistent (survives restarts)
- ✅ Simple implementation
- ✅ Works on any filesystem

**Cons:**

- ❌ Slow (disk I/O)
- ❌ Not shared across instances easily
- ❌ File system limitations
- ❌ Manual cleanup needed

**Implementation:**

```python
import json
import os
from pathlib import Path
from datetime import datetime, timedelta

class FileCache:
    def __init__(self, cache_dir: str = "/tmp/cache"):
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(exist_ok=True)
    
    def get(self, key: str) -> Optional[Dict]:
        cache_file = self.cache_dir / f"{key}.json"
        if not cache_file.exists():
            return None
        
        with open(cache_file, 'r') as f:
            data = json.load(f)
        
        expires_at = datetime.fromisoformat(data['expires_at'])
        if datetime.now() > expires_at:
            cache_file.unlink()  # Delete expired
            return None
        
        return data['value']
    
    def setex(self, key: str, ttl_seconds: int, value: Dict):
        cache_file = self.cache_dir / f"{key}.json"
        expires_at = datetime.now() + timedelta(seconds=ttl_seconds)
        
        data = {
            'value': value,
            'expires_at': expires_at.isoformat()
        }
        
        with open(cache_file, 'w') as f:
            json.dump(data, f)
    
    def delete(self, key: str):
        cache_file = self.cache_dir / f"{key}.json"
        cache_file.unlink(missing_ok=True)
```

**When to Use:**

- Development/testing
- Single-server deployments
- No database available
- Simple persistence needs

---

### Option 5: Hybrid Approach (Current Implementation)

**Current Strategy:**  
Your codebase already implements a **hybrid approach** with graceful degradation:

1.  **Primary:** Redis cache (fast, shared)
2.  **Fallback:** Session manager → Direct API calls
3.  **Result:** System works even without Redis

**Implementation Pattern:**

```python
def get_data(user_id: str):
    # Try Redis first
    if redis_client:
        cached = redis_client.get(f"key:{user_id}")
        if cached:
            return json.loads(cached)
    
    # Fallback to API
    return fetch_from_api(user_id)
```

**Benefits:**

- ✅ Works with or without Redis
- ✅ Optimal performance when Redis available
- ✅ Graceful degradation
- ✅ No single point of failure

---

## Recommendations

### For Your Use Case:

1.  **Keep Current Hybrid Approach** ✅
    - Already implemented
    - Works with/without Redis
    - Optimal performance
2.  **Add In-Memory Fallback** (Optional)
    - If Redis unavailable, use in-memory cache
    - Better than direct API calls every time
    - Simple to implement
3.  **For Cache-Only Operations:**
    - `refresh_leave_cache()` → Use `get_leave_summary(force_refresh=True)`
    - `clear_leave_cache()` → Not critical, can skip if Redis unavailable

### Migration Path:

```python
# Unified cache interface
class CacheAdapter:
    def __init__(self):
        self.redis = redis_client
        self.memory = InMemoryCache() if not redis_client else None
    
    def get(self, key: str) -> Optional[Dict]:
        # Try Redis
        if self.redis:
            return self._get_from_redis(key)
        
        # Fallback to memory
        if self.memory:
            return self.memory.get(key)
        
        # No cache available
        return None
    
    def setex(self, key: str, ttl: int, value: Dict):
        if self.redis:
            self._setex_redis(key, ttl, value)
        elif self.memory:
            self.memory.setex(key, ttl, value)
```

---

## Conclusion

### Redis-Only Tools: **3 tools**

- `refresh_leave_cache()` - Can use direct API call instead
- `refresh_wfh_cache()` - Can use direct API call instead
- `clear_*_cache()` - Not critical, can skip

### Tools with Fallback: **12+ tools**

- All data retrieval tools have fallback mechanisms
- System works without Redis (just slower)

### Best Alternative:

**Keep your current hybrid approach** - it's already well-designed with graceful degradation. If needed, add in-memory cache as intermediate fallback between Redis and direct API calls.

---

## Quick Reference

| Tool Category | Redis Required? | Fallback Available? | Alternative |
| --- | --- | --- | --- |
| Leave Summary | ❌ No | ✅ Yes (API) | `get_user_my_leaves_data()` |
| Leave Status | ❌ No | ✅ Yes (API) | `get_user_my_leaves_data()` |
| Leave Conflicts | ❌ No | ✅ Yes (API) | `get_user_my_leaves_data()` |
| Refresh Cache | ✅ Yes | ❌ No | Direct API call |
| WFH Tools | ❌ No | ✅ Yes (API) | `get_user_my_wfh_data()` |
| Worklog Tools | ❌ No | ✅ Yes (API) | `get_user_my_tasks_data()` |
| User Profile | ❌ No | ✅ Yes (API) | `fetch_user_profile()` |

**Verdict:** Only **3 cache management tools** are Redis-only, and they have workarounds. All data retrieval tools have fallbacks.