# Session Management, Redis Usage, and Scalability

## Table of Contents

1.  [Session Management Overview](#session-management-overview)
2.  [Current Session Architecture](#current-session-architecture)
3.  [Redis Integration](#redis-integration)
4.  [Scalability Considerations](#scalability-considerations)
5.  [Future Improvements](#future-improvements)

---

## Session Management Overview

The INX Chatbot Backend uses a multi-layered session management system that combines in-memory session storage with Redis caching for optimal performance and scalability.

### Key Components

1.  **Session Manager** (`app/core/cache/session_manager.py`): Handles session creation, validation, and lifecycle management
2.  **Redis Cache**: Stores user profile data, context information, and cached API responses
3.  **LangGraph Memory**: Maintains conversation history using `ConversationSummaryBufferMemory`
4.  **In-Memory Storage**: Temporary session data stored in `active_sessions` dictionary

---

## Current Session Architecture

### Session Lifecycle

#### 1\. Session Creation

When a user logs in, a new session is created through the `create_session()` function:

```python
def create_session(user_id: str, access_token: str, request_to_id: str = None) -> dict
```

**Process Flow:**

1.  **User Authentication**: Validates `user_id` and `access_token`
2.  **Profile Fetching**: Retrieves user profile from PMS APIs
3.  **Data Aggregation**: Fetches related data:
    - User profile information
    - Request-to data (approver information)
    - Task data (`my_tasks`)
    - Leave data (`my_leaves`)
    - WFH data (`my_wfh`)
    - Leave requests
    - WFH requests
    - Resources working under user
4.  **Redis Caching**: Stores all fetched data in Redis with TTL (Time To Live)
5.  **Session Generation**: Creates unique session ID (`sess_{uuid}`)
6.  **In-Memory Storage**: Stores session metadata in `active_sessions` dictionary

**Session Data Structure:**

```python
{
    "session_id": "sess_abc123def456",
    "user_id": "322",
    "access_token": "jwt_token_here",
    "base_url": "https://api.example.com",
    "request_to_id": "approver_id",
    "created_at": "2025-01-15T10:30:00",
    "last_activity": "2025-01-15T10:30:00",
    "expires_at": "2025-01-15T18:30:00",  # 8 hours from creation
    "status": "active"
}
```

**Session Expiry**: Sessions expire after **8 hours** of inactivity or absolute time expiry.

#### 2\. Session Validation

Every API request validates the session before processing:

```python
def validate_session(session_id: str) -> dict
```

**Validation Steps:**

1.  **Existence Check**: Verifies session exists in `active_sessions`
2.  **Expiry Check**: Validates session hasn't expired
3.  **Activity Update**: Updates `last_activity` timestamp
4.  **Data Return**: Returns session data including `access_token` and `base_url`

**Error Handling:**

- Missing session → `ValueError("Session not found")`
- Expired session → `ValueError("Session has expired")`
- Invalid format → `ValueError("session_id is required")`

#### 3\. Session Usage in API Endpoints

**Standard Endpoint Flow** (`/chatbot` and `/chat/stream`):

```python
# 1. Validate session
session_data = validate_session(query.session_id)

# 2. Verify user ownership
if session_data["user_id"] != query.user_id:
    return 403 Forbidden

# 3. Extract credentials
access_token = session_data["access_token"]
base_url = session_data["base_url"]

# 4. Process query with session context
result = await process_chatbot_query(
    question=query.question,
    user_id=query.user_id,
    session_id=query.session_id,
    access_token=access_token,
    base_url=base_url,
)
```

#### 4\. Session Cleanup

**Automatic Cleanup:**

- Expired sessions are removed from `active_sessions` during validation
- `cleanup_expired_sessions()` function can be called periodically to clean up expired sessions

**Manual Cleanup:**

```python
def destroy_session(session_id: str, user_id: str = None) -> dict
```

This function:

- Removes session from `active_sessions`
- Clears user memory (LangChain conversation history)
- Clears Redis cache for the user
- Returns cleanup status

---

## Redis Integration

### Redis Configuration

Redis is configured via environment variables:

```bash
REDIS_HOST=localhost          # Default: localhost
REDIS_PORT=6379              # Default: 6379
REDIS_DB=0                   # Default: 0
REDIS_PASSWORD=None          # Optional password
```

**Connection Initialization:**

```python
redis_client = redis.Redis(
    host=redis_host,
    port=redis_port,
    db=redis_db,
    password=redis_password,
    decode_responses=True  # Automatically decode JSON strings
)
```

**Graceful Degradation:**

- If Redis is unavailable, the system continues to function using in-memory storage
- All Redis operations check for `redis_client` availability before execution

### Redis Data Storage

#### 1\. User Profile Cache

**Key Pattern:** `user_profile:{user_id}`

**Data Structure:**

```json
{
    "profile_data": {
        "id": "322",
        "first_name": "John",
        "last_name": "Doe",
        "email": "john.doe@example.com",
        "team_id": 5,
        ...
    },
    "request_to_id": "approver_id",
    "request_to_data": [...],
    "my_tasks_data": [...],
    "my_leaves_data": {...},
    "my_wfh_data": {...},
    "leave_requests_data": {...},
    "wfh_requests_data": {...},
    "user_resources_working_under_data": {...},
    "cached_at": "2025-01-15T10:30:00",
    "cache_expires_at": "2025-01-15T11:30:00"  # 1 hour TTL
}
```

**TTL Configuration:**

- Default: **1 hour** (configurable via `USER_PROFILE_CACHE_HOURS`)
- Automatically expires and removes stale data

**Functions:**

- `store_user_profile_in_redis()`: Stores complete user profile with all related data
- `get_user_profile_from_redis()`: Retrieves user profile (returns empty dict if expired)
- `get_user_profile_with_metadata()`: Retrieves profile with cache metadata
- `is_user_profile_cache_valid()`: Checks if cache is still valid

#### 2\. Context-Specific Caches

The system uses specialized context managers for different domains:

**Leave Context Cache:**

- **Key Pattern:** `leave_context:{user_id}`
- **TTL:** 1 hour (configurable via `LEAVE_CONTEXT_CACHE_HOURS`)
- **Manager:** `LeaveContextManager` (`app/core/cache/leave_context_manager.py`)

**WFH Context Cache:**

- **Key Pattern:** `wfh_context:{user_id}`
- **TTL:** 1 hour (configurable via `WFH_CONTEXT_CACHE_HOURS`)
- **Manager:** `WFHContextManager` (`app/core/cache/wfh_context_manager.py`)

**Worklog Context Cache:**

- **Key Pattern:** `worklog_context:tasks:{user_id}` and `worklog_context:worklog:{user_id}`
- **TTL:** 1 hour (configurable via `WORKLOG_CONTEXT_CACHE_HOURS`)
- **Manager:** `WorklogContextManager` (`app/core/cache/worklog_context_manager.py`)

#### 3\. Cache Workflow

**Cache-Aside Pattern:**

```
1. Check Redis cache
   ↓ (cache hit)
2. Validate expiry
   ↓ (valid)
3. Return cached data
   
   ↓ (cache miss or expired)
4. Fetch from API
   ↓
5. Store in Redis with TTL
   ↓
6. Return fresh data
```

**Example Implementation:**

```python
def get_user_profile_from_redis(user_id: str) -> dict:
    if not redis_client:
        return {}  # Fallback to API fetch
    
    profile_key = f"user_profile:{user_id}"
    profile_json = redis_client.get(profile_key)
    
    if profile_json:
        enhanced_data = json.loads(profile_json)
        
        # Check expiry
        cache_expires_at = enhanced_data.get("cache_expires_at")
        if cache_expires_at:
            expires_datetime = datetime.fromisoformat(cache_expires_at)
            if datetime.now() > expires_datetime:
                redis_client.delete(profile_key)  # Remove expired cache
                return {}
        
        return enhanced_data.get("profile_data", {})
    
    return {}  # Cache miss
```

### Redis Benefits

1.  **Performance**: Reduces API calls by caching frequently accessed data
2.  **Cost Reduction**: Fewer external API requests = lower costs
3.  **Faster Response Times**: Cached data retrieval is milliseconds vs seconds for API calls
4.  **Reduced Load**: Lessens burden on PMS APIs
5.  **Data Consistency**: Single source of truth during cache validity period

---

## Scalability Considerations

### Current Limitations

#### 1\. In-Memory Session Storage

**Current Implementation:**

```python
active_sessions = {}  # Global dictionary
```

**Limitations:**

- **Single Server Constraint**: Sessions are stored in memory, so they're lost on server restart
- **No Horizontal Scaling**: Multiple server instances don't share sessions
- **Memory Growth**: All sessions stored in application memory
- **No Persistence**: Server restart = all sessions lost

**Impact:**

- Users must re-authenticate after server restarts
- Load balancing across multiple instances won't work correctly
- Memory usage grows with number of active sessions

#### 2\. LangChain Memory Storage

**Current Implementation:**

```python
user_memories: Dict[str, ConversationSummaryBufferMemory] = {}  # Global dictionary
```

**Limitations:**

- **In-Memory Only**: Conversation history lost on restart
- **No Sharing**: Multiple instances can't share conversation context
- **Memory Growth**: Long conversations consume application memory

### Scalability Solutions

#### 1\. Migrate Sessions to Redis

**Proposed Architecture:**

```python
# Session storage in Redis
def create_session_redis(user_id: str, access_token: str) -> dict:
    session_id = f"sess_{uuid.uuid4().hex[:12]}"
    session_data = {
        "session_id": session_id,
        "user_id": user_id,
        "access_token": access_token,
        "base_url": base_url,
        "created_at": datetime.now().isoformat(),
        "expires_at": (datetime.now() + timedelta(hours=8)).isoformat(),
    }
    
    # Store in Redis with 8-hour TTL
    redis_client.setex(
        f"session:{session_id}",
        timedelta(hours=8).total_seconds(),
        json.dumps(session_data)
    )
    
    return session_data

def validate_session_redis(session_id: str) -> dict:
    session_json = redis_client.get(f"session:{session_id}")
    if not session_json:
        raise ValueError("Session not found")
    
    session_data = json.loads(session_json)
    
    # Update last activity
    session_data["last_activity"] = datetime.now().isoformat()
    redis_client.setex(
        f"session:{session_id}",
        timedelta(hours=8).total_seconds(),
        json.dumps(session_data)
    )
    
    return session_data
```

**Benefits:**

- ✅ **Horizontal Scaling**: Multiple instances share sessions
- ✅ **Persistence**: Sessions survive server restarts
- ✅ **Automatic Cleanup**: Redis TTL handles expiry
- ✅ **Memory Efficiency**: Sessions stored outside application memory

#### 2\. LangGraph Checkpointing

**Current State:**

- LangGraph uses `thread_id` for conversation tracking
- Thread ID format: `{user_id}_{session_id}`
- Memory stored in application memory only

**Proposed Solution:**  
Use LangGraph's checkpointing with Redis backend:

```python
from langgraph.checkpoint.redis import RedisSaver

# Initialize Redis checkpoint saver
checkpointer = RedisSaver(redis_client)

# Configure graph with checkpointing
compiled_graph = graph.compile(checkpointer=checkpointer)

# Use in API calls
config = {
    "configurable": {
        "thread_id": f"{user_id}_{session_id}"
    }
}

# State is automatically persisted to Redis
response = compiled_graph.invoke(agent_state, config=config)
```

**Benefits:**

- ✅ **Persistent Memory**: Conversation history survives restarts
- ✅ **Shared State**: Multiple instances share conversation context
- ✅ **Automatic Management**: LangGraph handles state persistence
- ✅ **Scalability**: Supports distributed deployments

#### 3\. Redis Cluster for High Availability

**For Production Scale:**

```yaml
# docker-compose.yml
services:
  redis-cluster:
    image: redis:7.2
    command: redis-server --cluster-enabled yes
    # Configure cluster nodes
```

**Benefits:**

- ✅ **High Availability**: Automatic failover
- ✅ **Data Replication**: Multiple copies of data
- ✅ **Load Distribution**: Spreads load across nodes
- ✅ **Fault Tolerance**: Continues operating if nodes fail

#### 4\. Connection Pooling

**Current Implementation:**

```python
redis_client = redis.Redis(...)  # Single connection
```

**Scalable Implementation:**

```python
from redis.connection import ConnectionPool

# Create connection pool
redis_pool = ConnectionPool(
    host=redis_host,
    port=redis_port,
    db=redis_db,
    password=redis_password,
    max_connections=50,  # Pool size
    decode_responses=True
)

# Use pool for client
redis_client = redis.Redis(connection_pool=redis_pool)
```

**Benefits:**

- ✅ **Connection Reuse**: Reduces connection overhead
- ✅ **Concurrent Requests**: Handles multiple simultaneous requests
- ✅ **Resource Efficiency**: Better memory and connection management

### Scalability Metrics

#### Current Capacity (Single Instance)

| Metric | Current | With Redis Sessions | With Redis + Checkpointing |
| --- | --- | --- | --- |
| **Concurrent Sessions** | Limited by RAM | Unlimited (Redis capacity) | Unlimited |
| **Session Persistence** | ❌ No | ✅ Yes | ✅ Yes |
| **Horizontal Scaling** | ❌ No | ✅ Yes | ✅ Yes |
| **Memory Usage** | High (all in RAM) | Low (Redis) | Low (Redis) |
| **Conversation Memory** | Lost on restart | Lost on restart | ✅ Persistent |
| **Load Balancing** | ❌ Sticky sessions required | ✅ Stateless | ✅ Stateless |

#### Performance Characteristics

**Session Validation:**

- **In-Memory**: ~0.1ms (dictionary lookup)
- **Redis**: ~1-2ms (network round-trip + lookup)
- **Acceptable**: Redis overhead is minimal for the benefits

**Cache Hit Rate:**

- **Target**: >80% cache hit rate for user profiles
- **Current**: Depends on TTL and usage patterns
- **Optimization**: Adjust TTL based on data freshness requirements

---

## Future Improvements

### Phase 1: Redis Session Migration (High Priority)

**Tasks:**

1.  Implement Redis-based session storage
2.  Migrate `active_sessions` to Redis
3.  Update `validate_session()` to use Redis
4.  Add migration script for existing sessions
5.  Update tests

**Estimated Impact:**

- ✅ Enables horizontal scaling
- ✅ Session persistence
- ✅ Reduced memory usage

### Phase 2: LangGraph Checkpointing (High Priority)

**Tasks:**

1.  Integrate Redis checkpoint saver
2.  Configure graph with checkpointing
3.  Migrate existing memory to checkpoint store
4.  Update conversation memory retrieval
5.  Test conversation continuity

**Estimated Impact:**

- ✅ Persistent conversation history
- ✅ Shared conversation state across instances
- ✅ Better scalability

### Phase 3: Redis Cluster Setup (Medium Priority)

**Tasks:**

1.  Configure Redis cluster
2.  Update connection configuration
3.  Implement cluster-aware client
4.  Add monitoring and health checks
5.  Load testing

**Estimated Impact:**

- ✅ High availability
- ✅ Fault tolerance
- ✅ Better performance at scale

### Phase 4: Advanced Caching Strategies (Low Priority)

**Tasks:**

1.  Implement cache warming strategies
2.  Add cache invalidation webhooks
3.  Implement cache versioning
4.  Add cache analytics and monitoring
5.  Optimize TTL values based on usage patterns

**Estimated Impact:**

- ✅ Better cache hit rates
- ✅ Reduced API calls
- ✅ Improved response times

---

## Monitoring and Observability

### Key Metrics to Monitor

1.  **Session Metrics:**
    - Active sessions count
    - Session creation rate
    - Session expiry rate
    - Average session duration
2.  **Redis Metrics:**
    - Memory usage
    - Cache hit/miss rates
    - Connection pool usage
    - Command latency
3.  **Performance Metrics:**
    - API response times
    - Cache retrieval times
    - Session validation times
    - Memory usage per instance

### Recommended Tools

- **Redis Insight**: Visual monitoring for Redis
- **Prometheus + Grafana**: Metrics collection and visualization
- **Application Logs**: Structured logging for session events
- **Health Checks**: Endpoint monitoring for Redis availability

---

## Best Practices

### Session Management

1.  **Always validate sessions** before processing requests
2.  **Set appropriate TTLs** based on security and UX requirements
3.  **Clean up expired sessions** regularly
4.  **Log session events** for debugging and auditing
5.  **Handle Redis failures gracefully** with fallback mechanisms

### Redis Usage

1.  **Use appropriate key patterns** for easy management
2.  **Set TTLs on all cached data** to prevent memory leaks
3.  **Validate cache expiry** before using cached data
4.  **Implement cache invalidation** for data updates
5.  **Monitor Redis memory usage** to prevent OOM errors

### Scalability

1.  **Design for statelessness** where possible
2.  **Use connection pooling** for database/Redis connections
3.  **Implement circuit breakers** for external dependencies
4.  **Monitor resource usage** and plan capacity
5.  **Test horizontal scaling** before production deployment

---

## Conclusion

The current session management system provides a solid foundation with Redis caching for performance optimization. However, migrating session storage and LangGraph memory to Redis will unlock true horizontal scalability and high availability.

**Recommended Next Steps:**

1.  ✅ Migrate sessions to Redis (Phase 1)
2.  ✅ Implement LangGraph checkpointing (Phase 2)
3.  ⏳ Plan Redis cluster for production (Phase 3)
4.  ⏳ Optimize caching strategies (Phase 4)

This migration will transform the system from a single-instance application to a scalable, distributed system capable of handling enterprise-level traffic.