# Vibexture – V2 Requirement Specification & V1 Upgrade Report

## **1\. Executive Summary**

Vibexture V1 successfully demonstrated the full AI music generation pipeline — _Lyrics → AI → Music_ — integrating **React**, **FastAPI**, **DiffRhythm models**, **authentication**, and **real-time WebSockets**.

However, real-world tests revealed several limitations related to responsiveness, model control, token limits, and music-length alignment.  
Vibexture V2 aims to address these challenges, enhance system performance, restructure the AI pipeline, and introduce advanced control capabilities as discussed with **Gaurav Sir** and **Kuna Bhai**.

## **2\. Purpose of This Document**

This document serves to:

1.  Summarise all major issues identified in Vibexture V1.
2.  Define the complete functional and technical requirements for Vibexture V2.
3.  Outline the upgrade roadmap, key milestones, and work plan.

Stakeholders for SRS finalisation:

- Gaurav Sir
- Kuna Bhai
- Internal Engineering Team

## **3\. V1 Gap Analysis**

## 3.1 AI Music Length Generation

**Problem:** Music continues beyond lyrics, causing a duration mismatch due to a lack of alignment between timestamps, line durations, and model tempo.  
**Impact:** Inconsistent timing and misaligned user output.

## 3.2 Lyrics Generation (Token Limit & Response Truncation)

**Problem:** Groq/LLaMA models hit token limits, causing incomplete or repetitive lyrics and memory spikes.  
**Impact:** Incomplete songs and failed music generation in missing LRC format scenarios.

## 3.3 Frontend Responsiveness (Mobile)

**Problems:** UI overlaps, non-responsive player and progress sections, broken layouts on mobile.  
**Impact:** Poor user experience on iOS and Android devices.

## 3.4 Model Control Limitations (GAN/DiffRhythm)

**Problem:** No direct control over tempo, measures, or instrument layering; chained model architecture complicates customisation.  
**Impact:** Unpredictable output and limited upgrade flexibility.

## 3.5 Song Length Control

**Problem:** Manual duration enforcement fails as DiffRhythm overrides timings.  
**Impact:** Unreliable and inconsistent audio length.

## 3.6 Pending Requirement Freeze

**Action Required:**

- Confirm final features and enhancements with **Gaurav Sir**.
- Verification by **Kuna Bhai** and **Gaurav Sir**.

## **4\. V2 Requirement Specification**

## 4.1 Functional Requirements

## 4.1.1 Music-Length Synchronization (High Priority)

**Solution:**

- Implement a dynamic alignment algorithm based on total line duration.
- Realign timestamps and validate duration vs. model output.
- Add “smart padding” and silence padding where needed.

## 4.1.2 AI Lyrics Generation Upgrade

**Enhancements:**

- Introduce chunk-based (topic & structure) lyric generation to avoid token overflow.
- Regenerate line-by-line on overflow and add retry logic for model failure.  
    **Outcome:** Token-safe, complete lyrics with accurate LRC timestamps.

## 4.1.3 Mobile-Responsive UI Redesign

**Implementation:**

- Fully responsive forms, audio player, and model sections using Tailwind.
- Apply dynamic font scaling (1–3vw).
- Test on 320px–768px device widths (iPhone SE/Android/Tablet).

## 4.1.4 Enhanced Model Control Layer

**New Pipeline Abstraction:**

- Introduce pre-processing, tempo suggestion, prosody alignment, and post-generation normalization.  
    **Outcome:** Allow user input for tempo, mood, instrument density, and complexity (algorithmic control).

## 4.1.5 Song-Length Control Engine

**New Algorithm:**

- Estimate tempo, dynamically adjust durations, and apply fade-out or loop padding.  
    **Outcome:** Consistent, user-defined music length.

## 4.1.6 Admin Dashboard (Optional)

- Logs for usage, prompts, requests, credits, and song history.

## 4.2 Technical Requirements

## Frontend (React + TypeScript)

- Tailwind-based responsive UI.
- Modular components for audio generation and WebSocket handling.

## Backend (FastAPI)

- Robust lyric and LRC validation.
- Retry logic for AI tasks.
- Asynchronous task architecture (Celery or AsyncQueue).
- Music Length Validator Engine.

## AI Layer (Groq + DiffRhythm)

- Chunked lyric generation with token-safe prompts.
- AI response logging and auto-repair mechanism.
- Enhanced model controller layer.

## Database

- Add new tables: `generation_logs`, `admin_actions`, `lyrics_structure`, `model_settings`.

## **5\. V2 Development Roadmap**

| **Phase** | **Tasks** | **Duration** |
| --- | --- | --- |
| **1\. Requirement Freeze** | Finalize scope and features with stakeholders | 1–2 days |
| **2\. V1 Bug Fixing** | Token issue fix, responsiveness, WebSocket patch, UI cleanup | 4–5 days |
| **3\. AI Pipeline Redesign** | Build chunked generator, control layer, smart-duration engine | 7–10 days |
| **4\. Frontend V2 UI** | Responsive redesign, audio panel & interface upgrade | 5–7 days |
| **5\. Backend Release** | New APIs, validation engine, optional admin module | 5 days |
| **6\. Testing & QA** | Functional, AI stability, mobile, regression testing | 3–5 days |

**Total Duration:** _24–34 Days (based on final scope)_

---

## **6\. Milestones & Payment Structure**

| **Milestone** | **Deliverable** | **Payment** |
| --- | --- | --- |
| **1** | Requirement Freeze + Base UI Fix | 20% |
| **2** | AI Pipeline Upgrade + Lyrics Fix | 40% |
| **3** | Final V2 Release, QA & Deployment | 40% |

---

## **7\. Final Verification Workflow**

- Demo presentation to **Gaurav Sir**
- Validation by **Kuna Bhai**
- Requirement freeze confirmation
- Final adjustments and V2 deployment

## **8\. Conclusion**

Vibexture V2 will deliver a comprehensive upgrade focusing on _stability, AI optimization, mobile responsiveness,_ and _music consistency_. This document serves as the complete execution blueprint for transitioning from V1 to V2 successfully.