# Technical Specification Document 

**AI Music Generation Platform (Vibexture)** 

**Version:** 1.0.0   
**Document Type:** Technical Specification   
**Status:** Complete 

 

**Table of Contents** 

1.  Executive Summary 

2.  System Architecture 

3.  Technology Stack 

4.  Backend API Specification 

1.  Module-wise Endpoint Tables (Integrated) 

5.  Frontend Architecture 

6.  Database Schema 

7.  AI/ML Integration 

8.  WebSocket Implementation 

9.  Authentication & Authorization 

10. Configuration Management 

11. Security Features 

12. Deployment & Infrastructure 

13. Error Handling 

14. Performance Considerations 

 

 

**Executive Summary** 

Vibexture is an AI-powered music generation platform that transforms user-provided lyrics into high-quality audio compositions using advanced AI models. It integrates multiple services including lyric generation, audio synthesis, and real-time progress monitoring. The system is modular, scalable, and secured with a role-based authentication system. 

**Core Capabilities** 

- **Lyrics Generation:** Uses Google Gemini 2.0 Flash for dynamic lyric composition. 

- **Music Generation:** Employs DiffRhythm AI models to create full-length audio. 

- **Real-Time Processing:** WebSocket-driven progress updates. 

- **User Management:** Email verification, credits, and RBAC. 

- **Intelligent Timestamping:** AI-based synchronization of lyrics and audio. 

**Key Features** 

- Customizable AI lyric generation with topic, genre, and style. 

- Multiple music generation model options. 

- LRC and plain-text lyric support. 

- Daily credit system with automatic resets. 

- Role and permission-based access. 

- AI timestamp generation for lyrics. 

 

**System Architecture** 

**High-Level Overview** 

 

The architecture consists of: 

- **Frontend (React):** User interface and client-side logic. 

- **Backend (FastAPI):** API management, authentication, AI orchestration. 

- **AI Engines:** Gemini for text, DiffRhythm for audio generation. 

- **Database:** SQLite for development, PostgreSQL for production. 

 

**Technology Stack** 

**Backend** 

|     |     |     |
| --- | --- | --- |
| **Technology** | **Version** | **Purpose** |
| Python | 3.10+ | Core language |
| FastAPI | 0.104.0+ | Web framework |
| SQLAlchemy | 2.0.0+ | ORM |
| Uvicorn | 0.24.0+ | ASGI server |
| Pydantic | 2.5.0+ | Data validation |
| python-jose | 3.3.0+ | JWT |
| passlib | 1.7.4+ | Password hashing |
| google-generativeai | 0.8.0+ | Gemini client |
| PyTorch | 2.0.0+ | DiffRhythm integration |
| WebSockets | 12.0+ | Real-time updates |

**Frontend** 

|     |     |     |
| --- | --- | --- |
| **Technology** | **Version** | **Purpose** |
| React | 18.3.1+ | UI framework |
| TypeScript | 5.8.3+ | Type safety |
| Vite | 5.4.19+ | Build tool |
| React Router | 6.30.1+ | Routing |
| TanStack Query | 5.83.0+ | Data fetching |
| Tailwind CSS | 3.4.17+ | Styling |
| Radix UI | —   | Components |
| Zod | 3.25.76+ | Validation |

**Databases** 

- **SQLite** for local/testing 

- **PostgreSQL** for production 

**AI Models** 

- **Google Gemini 2.0 Flash** for lyrics 

- **DiffRhythm Suite:** 

- Base (95s fixed) 

- 1_2 (extended high-quality) 

- 1_2-base (extended base) 

- Full (long-duration) 

 

**Backend API Specification** 

**Base URLs** 

- Development: http://localhost:8000 

- Production: configured via environment variables 

**Overview** 

All endpoints are grouped module-wise. Each module table lists endpoint path, HTTP method, short description, request parameters (path/query/body/headers), and example response format. 

**Module-wise Endpoint Tables (Integrated)** 

**_Module: Health & Root_** 

|     |     |     |
| --- | --- | --- |
| **Endpoint** | **Method** | **Description** |
| /health | GET | Health check endpoint |
| /   | GET | Root info and docs link |

**_Module: Authentication (/auth)_** 

|     |     |     |
| --- | --- | --- |
| **Endpoint** | **Method** | **Description** |
| /auth/register | POST | Register new user. Sends verification email. |
| /auth/login | POST | Login and obtain tokens. |
| /auth/logout | POST | Logout and blacklist token. |
| /auth/refresh | POST | Get new access token using refresh token. |
| /auth/me | GET | Get current user info. |
| /auth/send-verification-email | POST | Send verification email. |
| /auth/verify-email | GET | Verify email using JWT token. |
| /auth/verify-email-otp (DEPRECATED) | POST | Verify email via OTP (legacy). |
| /auth/forgot-password | POST | Request password reset OTP. |
| /auth/reset-password | POST | Reset password using OTP. |
| /auth/change-password | POST | Change password (requires current). |
| /auth/me/credits | GET | Get user's credit status. |
| /auth/admin/users | GET | List all users with credit status (Super Admin only). |
| /auth/admin/users/{user_id}/credits | GET | Get specific user's credit info (Super Admin only). |
| /auth/admin/users | POST | Create a new admin user (Super Admin only). |
| /auth/admin/users/{user_id} | PUT | Update user (Super Admin only). |
| /auth/admin/users/{user_id} | DELETE | Delete user (Super Admin only). |

**_Module: Music Generation (/api/music)_** 

|     |     |     |
| --- | --- | --- |
| **Endpoint** | **Method** | **Description** |
| /api/music/generate | POST | Start music generation from lyrics or AI parameters. Requires verified user and credits. |
| /api/music/status/{task_id} | GET | Get status and progress for a generation task. |
| /api/music/audio/{filename} | GET | Download generated audio file. |
| /api/music/convert-lyrics | POST | Convert plain lyrics to LRC timestamps. AI assigns timestamps if style_prompt provided. |
| /api/music/generate-lyrics | POST | Generate lyrics using Gemini (simple or lrc format). |
| /api/music/models | GET | List available DiffRhythm and related models and metadata. |
| /api/music/upload-reference-audio | POST | Upload reference audio for style guidance. (Max 10MB) |
| /api/music/options | GET | Get selectable styles, moods, instruments options for UI. |

Notes: 

- Input mode priority for /api/music/generate: ai_lyrics_params > lrc_content > lyrics. 

- Audio format: WAV, 44.1 kHz, 16-bit stereo. 

- Model length constraints enforced server-side. 

**_Module: Role Management (/api/roles)_** 

|     |     |     |
| --- | --- | --- |
| **Endpoint** | **Method** | **Description** |
| /api/roles | POST | Create a new role. Permission required: role:create. |
| /api/roles | GET | List roles. Permission required: role:read. |
| /api/roles/{role_id} | GET | Get role by ID. Permission: role:read. |
| /api/roles/{role_id} | PUT | Update role. Permission: role:update. |
| /api/roles/{role_id} | DELETE | Delete role. Permission: role:delete. |
| /api/roles/{role_id}/permissions | POST | Assign permissions to a role. Permission: role:assign. |
| /api/roles/{role_id}/permissions | GET | Get permissions assigned to a role. Permission: role:read. |

**_Module: Permission Management (/api/permissions)_** 

|     |     |     |
| --- | --- | --- |
| **Endpoint** | **Method** | **Description** |
| /api/permissions | POST | Create a new permission. Permission: permission:create. |
| /api/permissions | GET | List permissions. Permission: permission:read. |
| /api/permissions/{permission_id} | GET | Get permission by ID. Permission: permission:read. |
| /api/permissions/{permission_id} | PUT | Update permission. Permission: permission:update. |
| /api/permissions/{permission_id} | DELETE | Delete permission. Permission: permission:delete. |

**_Module: WebSocket (Real-time)_** 

|     |     |     |
| --- | --- | --- |
| **Endpoint** | **Method** | **Description** |
| /ws | WebSocket | Unauthenticated real-time channel for pings and public events. |
| /ws/authenticated | WebSocket | Authenticated WebSocket. Validates JWT token on connect. |

Message types (client→server): ping, subscribe, unsubscribe.   
Message types (server→client): pong, connected, progress, notification, event, error. 

**_Module: Admin & Management (Admin-specific endpoints)_** 

|     |     |     |
| --- | --- | --- |
| **Endpoint** | **Method** | **Description** |
| /auth/admin/users | GET | List all users (Super Admin). |
| /auth/admin/users | POST | Create admin user (Super Admin). |
| /auth/admin/users/{user_id} | PUT | Update user (Super Admin). |
| /auth/admin/users/{user_id} | DELETE | Delete user (Super Admin). |
| /auth/admin/users/{user_id}/credits | GET | View user credits (Super Admin). |

**_Module: Misc / Utilities_** 

|     |     |     |
| --- | --- | --- |
| **Endpoint** | **Method** | **Description** |
| /api/music/health (if implemented) | GET | Model or inference health check |
| /api/docs | GET | OpenAPI/Swagger documentation (FastAPI default) |

 

**Frontend Architecture** 

- **React + TypeScript** modular design. 

- **State Management:** Context API + TanStack Query. 

- **Authentication Layer:** Token-based. 

- **Theme Layer:** Tailwind CSS + Radix UI. 

- **Build Tool:** Vite for optimized hot-reload and bundling. 

Key pages and components are preserved from the original spec. API client uses base URL http://localhost:8000 during development and sends Authorization: Bearer {access_token} header. 

 

**Database Schema** 

**Core Tables (as defined)** 

- users, user_roles, roles, permissions, role_permissions, email_otps, token_blacklist, user_credits, plus music task tracking table(s) as implied (music_tasks, uploads). 

Schema details and defaults are included in the original content. Credit reset behavior: midnight UTC. 

 

**AI/ML Integration** 

- **Gemini 2.0 Flash:** Generates contextual lyrics based on prompt metadata. Default config and usage examples included. 

- **DiffRhythm Models:** Convert LRC-formatted lyrics into audio using diffusion-based inference. Model details, durations, and approximate generation times are documented. 

- **Inference pipeline:** validation, saving LRC, running DiffRhythm, monitoring progress, post-processing, storing output. 

GPU recommendations and memory management notes included. 

 

**WebSocket Implementation** 

- Manager: ConnectionManager for tracking by connection ID and user ID. 

- Progress stages enumerated. 

- Authenticated and unauthenticated endpoints exist. Messages detailed in tables above. 

 

**Authentication & Authorization** 

- JWT flows and token structure included. 

- RBAC enforced with permission checks and require_permission dependency example. 

- Email verification flow and OTP handling documented. 

 

**Configuration Management** 

Environment variables, config files (model_config.yaml, prompt_templates.yaml, logging_config.yaml) and their keys are preserved from original content. 

 

**Security Features** 

- Password hashing, token security, validation, rate limiting, input sanitization, and other features included as previously provided. 

 

**Deployment & Infrastructure** 

- Development and production deployment commands preserved. 

- Dockerfiles for backend and frontend included. 

- Infrastructure requirements enumerated. Suggest Redis for caching and PostgreSQL for production. 

 

**Error Handling** 

- Standardized error schema and HTTP status codes described. 

- Custom exceptions and global exception handler detailed. 

 

**Performance Considerations** 

- Async I/O, caching, GPU acceleration, chunked inference, and DB indexing described. 

 

**Appendix** 

**API Endpoint Summary (quick counts)** 

- Health/Root: 2 

- Authentication: 15+ (including admin user endpoints) 

- Music Generation: 8+ endpoints 

- Role Management: 7 endpoints 

- Permission Management: 5 endpoints 

- WebSocket: 2 endpoints 

- **Total endpoints: 40+ (matches original count)** 

**Default Roles and Permissions** 

- Super Admin: All permissions, unlimited credits. 

- User: Basic permissions, 5 credits/day, must verify email to use generation. 

**Document Version:** 1.0.0   
**Last Updated:** 2025