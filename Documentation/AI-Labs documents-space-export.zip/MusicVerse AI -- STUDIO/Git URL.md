# Git URL

  
**Note:**   
This document contains reference links to the official source code for repositories for the Vibexture AI Music Generation Platform. These repositories include both frontend and backend implementations that collectively power the complete system, enabling seamless text-to-music generation, user management, and AI model integration. 

**Repository Links:**   
**Frontend Repository (React/Next.js):**    
 https://gitlab.inexture.com/ai.inexture/musicverse-ai/-/tree/dev/ai_music_generation/Backend?ref_type=heads

 **Backend Repository (Fast API):** 

[https://gitlab.inexture.com/ai.inexture/ai_music_generation/-/tree/dev/ai_music_generation/Backend?ref_type=heads](https://gitlab.inexture.com/ai.inexture/musicverse-ai/-/tree/dev/ai_music_generation/Frontend?ref_type=heads)