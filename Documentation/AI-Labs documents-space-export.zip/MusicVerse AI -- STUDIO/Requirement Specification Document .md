# Requirement Specification Document 

**Project:** Vibexture – AI Music Generation Studio 

 

**1\. System Overview** 

Vibexture is an AI-powered music generation platform that transforms text lyrics into high-quality, studio-grade songs using **DiffRhythm** models. It provides an integrated web-based solution with a **React (TypeScript)** frontend and **FastAPI (Python)** backend. The platform supports authentication, role-based access, GPU-based AI generation, and real-time progress tracking through WebSocket communication. 

 

**2\. Objectives** 

- Convert text lyrics to professional music using AI. 

- Support multiple AI models for generation speed and quality. 

- Enable real-time progress tracking of music creation. 

- Maintain a secure, role-based, and scalable backend. 

- Provide seamless frontend interaction and audio management. 

 

**3\. Scope** 

Vibexture will serve: 

- Songwriters and musicians want AI-generated compositions. 

- Content creators require background music. 

- Developers and AI researchers are working with music generation models. 

System will cover: 

- AI lyrics generation (optional). 

- Lyrics-to-music conversion using pre-trained DiffRhythm models. 

- Real-time song generation with GPU acceleration. 

- Role-based access management for users and administrators. 

 

**4\. Functional Requirements** 

**_4.1 User Management_** 

- **Register:** User signs up with email, username, password. 

- **Login:** Authenticated access using JWT tokens. 

- **Email Verification:** OTP or JWT-based verification. 

- **Password Management:** Change and reset functionality. 

- **Role Assignment:** Admin-defined roles (e.g., user, editor, admin). 

**_4.2 Lyrics Management_** 

- **Upload/Input Lyrics:** Accepts text or LRC formatted lyrics. 

- **AI Lyrics Generation:** Uses Google Gemini API to generate lyrics based on genre, topic, and style. 

- **LRC Conversion:** Converts text lyrics into time-synced LRC format. 

- **Duration Control:** Custom duration (95–285 seconds). 

**_4.3 Music Generation_** 

- **Model Selection:** Choose between DiffRhythm-base, DiffRhythm-1_2, and DiffRhythm-1_2-base. 

- **Style Definition:** Users define genre, instrument type, mood, and tempo. 

- **Audio Generation:** AI produces .wav audio with real-time progress. 

- **WebSocket Updates:** Real-time feedback on generation status. 

- **Download Option:** WAV file download post-generation. 

**_4.4 Role-Based Access Control (RBAC)_** 

- **Role Creation:** Admin can create/edit roles. 

- **Permission Assignment:** Define CRUD permissions per role. 

- **JWT Enforcement:** Access validation via bearer tokens. 

**_4.5 WebSocket Communication_** 

- **Authenticated Channels:** Token-based WebSocket connection. 

- **Progress Updates:** Generation steps and completion events. 

- **Event Handling:** Ping, status, and completion notifications. 

**_4.6 File & Model Management_** 

- **Local Model Storage:** Store DiffRhythm models locally. 

- **Dynamic Loading:** Load models dynamically into GPU memory. 

- **Output Handling:** Manage generated audio in /Backend/data/outputs/. 

 

**5\. Non-Functional Requirements** 

|     |     |
| --- | --- |
| **Category** | **Requirement** |
| **Performance** | Base model generates within ~30s, extended models within 60–90s. |
| **Scalability** | Designed for concurrent user handling via FastAPI async architecture. |
| **Reliability** | Real-time feedback with automatic task tracking and error handling. |
| **Security** | JWT-based authentication, secure password storage (bcrypt), and role-based access. |
| **Usability** | Intuitive React-based UI with responsive design. |
| **Maintainability** | Modular backend and frontend with clear directory hierarchy. |
| **Portability** | Supports deployment on local or cloud GPU environments. |

 

**6\. System Architecture** 

**Architecture Layers:** 

|     |     |     |
| --- | --- | --- |
| **Layer** | **Technology** | **Function** |
| **Frontend** | React + TypeScript | User interaction, lyrics input, audio playback, and progress tracking |
| **Backend** | FastAPI (Python) | Authentication, AI integration, WebSocket management |
| **AI Models** | DiffRhythm Family | Lyrics-to-music conversion |
| **Database** | SQLite / PostgreSQL | User, roles, and generation logs |
| **GPU Backend** | NVIDIA CUDA | AI inference acceleration |

**Ports Used:** 

- Frontend: 5173 

- Backend: 8000 

**Data Flow:**   
React (User Input) ⇄ FastAPI (REST/WebSocket) ⇄ DiffRhythm Model (GPU Inference) 

 

**7\. Technology Stack** 

|     |     |
| --- | --- |
| **Component** | **Technology** |
| Frontend | React, TypeScript, WebSocket |
| Backend | Python, FastAPI, AsyncIO |
| AI Model | DiffRhythm (Base, 1_2, 1_2-base) |
| LLM | Google Gemini (Lyrics Generation) |
| Database | SQLite (default), PostgreSQL (optional) |
| Authentication | JWT, Refresh Tokens |
| Infrastructure | NVIDIA GPU (≥8 GB VRAM), CUDA-enabled Python |
| Audio Processing | FFmpeg (optional) |

 

**8\. API Summary** 

**_8.1 Authentication_** 

- POST /auth/register – Register new user 

- POST /auth/login – Login 

- GET /auth/me – Get user info 

- GET /auth/verify-email – Verify email 

- POST /auth/change-password – Change password 

**_8.2 Lyrics & Music Generation_** 

- POST /api/music/generate-lyrics – Generate lyrics using AI 

- POST /api/music/generate – Generate full song 

- GET /api/music/status/{task_id} – Get generation status 

- GET /api/music/audio/{task_id}.wav – Download audio 

**_8.3 Role Management_** 

- POST /api/roles – Create role 

- GET /api/roles – Fetch all roles 

**_8.4 WebSocket_** 

- ws://localhost:8000/ws/authenticated?token={access_token} – Authenticated session for live updates 

 

**9\. System Requirements** 

|     |     |
| --- | --- |
| **Type** | **Specification** |
| **GPU** | NVIDIA RTX 2080 (min), RTX 3080+ recommended |
| **VRAM** | ≥8 GB |
| **RAM** | ≥16 GB |
| **CPU** | Multi-core processor |
| **Storage** | ≥20 GB free |
| **OS** | Linux / Windows with CUDA support |
| **Dependencies** | Python 3.10+, Node.js 18+, FFmpeg |

 

**10\. Security Requirements** 

- Token-based JWT authentication and refresh mechanism. 

- Secure email verification with expiring tokens. 

- Hashed password storage (bcrypt). 

- CORS protection for frontend origins. 

- Environment variable-based secret key management. 

- HTTPS enforcement in production. 

 

**11\. Performance Metrics** 

|     |     |     |     |     |
| --- | --- | --- | --- | --- |
| **Model** | **Duration** | **Quality** | **Generation Time** | **VRAM Usage** |
| DiffRhythm-base | 95s | Standard | ~30s | ~6GB |
| DiffRhythm-1_2 | 96–285s | High | 60–90s | ~8GB |
| DiffRhythm-1_2-base | 96–285s | High | 60–90s | ~8GB |

 

**12\. Testing and Validation** 

- **Unit Tests:** Backend modules (auth, music, AI integration). 

- **Integration Tests:** API routes and WebSocket communication. 

- **E2E Tests:** Full pipeline (lyrics → music → download). 

- **Coverage Target:** ≥87%. 

- **Testing Tool:** pytest. 

 

**13\. Deployment** 

**Local Setup:** 

- python [main.py](http://main.py) (backend) 

- npm run dev (frontend) 

**Production Deployment:** 

- Use uvicorn with Gunicorn for backend. 

- Serve frontend via Nginx. 

- Configure environment variables securely. 

- Enable HTTPS. 

 

**14\. Future Enhancements** 

- Integration with more LLMs for multilingual lyric generation. 

- Support for real-time voice input. 

- Cloud-based GPU scaling. 

- User credit system for generation quotas. 

- Advanced mixing and mastering AI stage. 

 

**15\. License and Acknowledgments** 

**License:** Uses DiffRhythm under its open-source license. 

**Acknowledgments:** 

- ASLP Lab for DiffRhythm models 

- Google Gemini for LLM integration 

- React and FastAPI communities for foundational frameworks