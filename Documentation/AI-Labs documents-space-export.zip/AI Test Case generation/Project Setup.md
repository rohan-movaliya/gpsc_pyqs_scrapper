# Project Setup

Follow these steps to set up and run the **TestGen - AI Test Case Generator** locally.

---

## **Quick Setup Summary**

Follow these steps to set up and run the **TestGen Backend** and **Frontend** locally.

## **1\. Clone and Setup Environment**

```worktree-shellscript
# Clone the repository
git clone <your-repo-url>
cd testcase_generated

# Create and activate virtual environment (Backend)
cd backend
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install system dependencies (Ubuntu/Debian)
sudo apt-get update
sudo apt-get install libmagic1 libmagic-dev postgresql-15

# Install backend dependencies
pip install -r requirements.txt

# Install frontend dependencies
cd ../Frontend
npm install
```

## **2\. Configure Environment Variables**

### **Backend Configuration**

Copy the example environment file and update values:

```worktree-shellscript
cd backend
cp env.example .env
```

Configure the following sections:

- **Database**: PostgreSQL credentials and connection details

- **JWT Auth**: Secret key, algorithm, and expiry time

- **Groq API**: Your Groq API key for AI inference

- **CORS**: Frontend URLs for cross-origin requests

- **File Upload**: Upload directory and file size limits

- **Application Settings**: Server host, port, and environment

**Required Environment Variables:**

```worktree-shellscript
# Database Configuration
DATABASE_URL=postgresql://postgres:password@localhost:5432/testgen_db
DB_HOST=localhost
DB_PORT=5432
DB_NAME=testgen_db
DB_USER=postgres
DB_PASSWORD=password

# API Keys and Secrets
GROQ_API_KEY=your_groq_api_key_here
JWT_SECRET_KEY=your-secret-key-change-in-production
JWT_ALGORITHM=HS256
JWT_ACCESS_TOKEN_EXPIRE_MINUTES=30

# Server Configuration
HOST=0.0.0.0
PORT=8002
DEBUG=True
ENVIRONMENT=development

# CORS Configuration
CORS_ORIGINS=http://localhost:3000,http://localhost:5173,http://localhost:5174
```

### **Frontend Configuration**

Copy the example environment file and update values:

```worktree-shellscript
cd Frontend
cp env.example .env.local
```

**Required Environment Variables****:**

```worktree-shellscript
# API Configuration
VITE_API_BASE_URL=http://localhost:8002

# Frontend Configuration
VITE_FRONTEND_URL=http://localhost:5173

# Environment Settings
VITE_ENVIRONMENT=development
VITE_DEBUG=true
```

## **3\. Database Setup**

Start the PostgreSQL service and create the database:

```worktree-shellscript
# Start PostgreSQL service
sudo systemctl start postgresql
sudo systemctl enable postgresql

# Create database
sudo -u postgres psql
CREATE DATABASE testgen_db;
CREATE USER testgen WITH PASSWORD 'your_password';
GRANT ALL PRIVILEGES ON DATABASE testgen_db TO testgen;
\q
```

Initialize the database with tables and seed data:

```worktree-shellscript
cd backend
source venv/bin/activate
python3 -c "from app.database import init_database; init_database()"
```

This automatically initializes the database schema, permissions, roles, and creates a default admin user.

## **4\. Run the Servers**

### **Start Backend Server**

```worktree-shellscript
cd backend
source venv/bin/activate  # On Windows: venv\Scripts\activate
python main.py
```

Or using uvicorn directly with hot reload:

```worktree-shellscript
uvicorn main:app --reload --host 0.0.0.0 --port 8002
```

This automatically initializes the database, permissions, and roles.

### **Start Frontend Server**

```worktree-shellscript
cd Frontend
npm run dev
```

The frontend will start on port **5173** by default.

## **5\. Access Application & API Documentation**

Once both servers are running, access the application:

- **Frontend Application**: http://localhost:5173

- **Backend API**: http://localhost:8002

- **Swagger UI**: http://localhost:8002/docs

- **ReDoc**: http://localhost:8002/redoc

- **API Root**: http://localhost:8002/

---

## **6\. Default Admin Account**

After database initialization, use these credentials to log in:

- **Email**: [admin@example.com](mailto:admin@example.com)

- **Password**: Admin@123

- **Role**: Admin (Full system access)

**⚠️ Important**: Change the default admin password immediately after first login.

---

## **7\. Troubleshooting**

### **Backend Issues**

**Database Connection Failed**

```worktree-shellscript
# Check PostgreSQL status
sudo systemctl status postgresql

# Restart PostgreSQL service
sudo systemctl restart postgresql

# Verify database exists
sudo -u postgres psql -c "\l" | grep testgen_db
```

**Invalid Groq API Key**

```worktree-shellscript
# Test your API key
curl -H "Authorization: Bearer YOUR_GROQ_API_KEY" \
     https://api.groq.com/openai/v1/models
```

Get your Groq API key at: https://console.groq.com/

**Port Already in Use (8002)**

```worktree-shellscript
# Find process using port
lsof -i :8002

# Kill the process
kill -9 <PID>

# Or use a different port in .env
PORT=8003
```

**Import Errors or Missing Dependencies**

```worktree-shellscript
# Activate virtual environment
cd backend
source venv/bin/activate

# Reinstall all dependencies
pip install --upgrade pip
pip install -r requirements.txt
```

### **Frontend Issues**

**Port Already in Use (5173)**

```worktree-shellscript
# Check what's using the port
lsof -i :5173

# Use a different port
npm run dev -- --port 3000
```

**Build Errors**

```worktree-shellscript
# Clear cache and reinstall
cd Frontend
rm -rf node_modules package-lock.json
npm install
npm run build
```

**API Connection Errors**

- Verify backend is running on port 8002

- Check VITE_API_BASE_URL in .env.local

- Ensure CORS_ORIGINS in backend .env includes your frontend URL

- Check browser console for CORS errors

**Module Not Found Errors**

```worktree-shellscript
# Clear Vite cache
rm -rf Frontend/node_modules/.vite
npm run dev
```

### **Common Issues**

**Cannot Activate Virtual Environment (Windows)**

`# Enable script execution`

`Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser`

`# Then activate`

`.\venv\Scripts\activate`

**Permission Denied on File Upload**

```worktree-shellscript
# Ensure upload directories exist and have proper permissions
cd backend
mkdir -p data/uploads/temp data/uploads/backups data/uploads/prd_documents
chmod -R 755 data/
```

**Email Verification Not Working**

Check your SMTP settings in backend/.env if email verification is required:

```worktree-shellscript
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USERNAME=your-email@gmail.com
SMTP_PASSWORD=your-app-password
```