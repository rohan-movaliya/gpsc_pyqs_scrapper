# Technical Document

# **TestGen - AI-Powered Test Case Generation System**

**Technical Documentation**  

This is an intelligent test case generation system that leverages AI-powered PRD document analysis, document chunking algorithms, and parallel LLM processing to automate the creation of comprehensive test cases for QA teams. The system processes Product Requirements Documents (PRD), extracts structured requirements, generates user stories, and creates detailed test cases using large language models.  

**TECHNOLOGY STACK**  

**Backend Technologies**  

Application Framework   

• FastAPI with Uvicorn   

• Python 3.10+  

Artificial Intelligence   

• Groq API (Llama 3.1 70B model) for requirements extraction, user story generation, and test case generation   

• tiktoken for token counting and text processing  

**Document Processing**   

• PyPDF2, pdfplumber, PyMuPDF for PDF extraction   

• python-docx, docx2txt for Word document processing   

• python-magic for file type detection   

• aiofiles for asynchronous file operations  

**Database & ORM**   

• PostgreSQL 15+ for relational data storage   

• SQLAlchemy 2.0 for ORM and database management   

• Alembic for database migrations   

• psycopg2-binary for PostgreSQL connectivity  

**Authentication & Security**   

• python-jose for JWT token generation and validation   

• passlib with bcrypt for password hashing   

• HTTPBearer for API authentication  

**Email & Communication**   

• aiosmtplib for async SMTP email sending   

• email-validator for email validation  

**Data Processing**   

• Pydantic for data validation and settings   

• pydantic-settings for configuration management   

• Jinja2 for template rendering  

**Export & Reporting**   

• openpyxl for Excel file generation (Jira export and test case/user story export)  

**Testing & Configuration**   

• pytest, pytest-asyncio, pytest-cov for testing   

• httpx for HTTP client testing   

• python-dotenv for environment configuration  

**Utilities**   

• psutil for system monitoring and health checks   

• python-multipart for file upload handling  

**Frontend Technologies**  

**Core Framework**   

• React 18 with TypeScript   

• Vite for build tooling and development server  

**UI Components**   

• shadcn/ui component library   

• Radix UI primitives (@radix-ui/react-\*)   

• Tailwind CSS for styling   

• lucide-react for icons  

**State Management & Data Fetching**   

• React Context API for global state   

• @tanstack/react-query for server state management   

• React Router DOM for navigation  

**Form Handling**   

• react-hook-form for form management   

• @hookform/resolvers with zod for validation   

• zod for schema validation  

**UI Enhancements**   

• date-fns for date manipulation   

• react-day-picker for date selection   

• react-dropzone for file uploads   

• recharts for data visualization   

• react-syntax-highlighter for code display  

**Utilities**   

• axios for HTTP requests   

• sonner for toast notifications   

• clsx and tailwind-merge for conditional styling   

• next-themes for theme management  

**Data Storage**  

Relational Database PostgreSQL database for all structured data including:   

• Users and authentication data   

• Projects and project metadata   

• PRD documents and document metadata   

• Extracted requirements   

• Generated user stories   

• Generated test cases   

• Project members and roles   

• API keys configuration   

• Processing queue tasks  

**File Storage**   

• File system storage for uploaded PRD documents   

• Organized directory structure for document management   

• Backup storage for document versions  

**CORE FEATURES**  

**PRD Document Management**  

Upload and manage PRD documents with metadata extraction including file name, upload date, file size, and processing status. Support for multiple formats (PDF, DOCX, TXT, MD). Full create, read, update, and delete operations for document entries. Document text extraction and processing status tracking.  

**Requirements Extraction**  

Intelligent extraction of structured functional and non-functional requirements from PRD documents using AI. Context preservation across document sections through intelligent chunking. Requirements categorization, validation, and deduplication. Source tracking to identify which document section generated each requirement.  

**User Story Generation**  

AI-powered generation of user stories from extracted requirements using parallel chunk processing. Two generation modes: AI-generated and manual creation. Preview functionality before saving. Full CRUD operations with status management (Draft, In Progress, Completed, Blocked). Priority assignment and story point estimation. Acceptance criteria association with user stories.  

**Test Case Generation**  

Comprehensive test case generation from user stories using AI with parallel processing capabilities. Multiple test case types (Functional, Integration, Regression, Performance). Priority levels (Critical, High, Medium, Low). Status management (Draft, Ready, Executed, Passed, Failed, Blocked). Test case grouping by user story. Preview functionality and manual test case creation.  

 

 

**Project Management**  

Complete project lifecycle management with CRUD operations. Project metadata including name, description, and domain/industry classification. Project statistics and analytics. Project member management with role-based access control. Project archiving and status management.  

**Queue-Based Processing**  

Asynchronous task queue system for long-running document processing operations. Task status tracking (Pending, Processing, Completed, Failed). Automatic retry mechanism for failed tasks. Queue monitoring and task prioritization. Background processing to prevent API timeouts.  

**Document Chunking**  

Intelligent document chunking strategies for optimal LLM processing. Configurable chunk sizes based on document type and content. Section-based and paragraph-based chunking approaches. Chunk metadata tracking for result merging. Optimal chunking configuration recommendations.  

**API ENDPOINTS**  

**Health & Status** 

|     |     |     |
| --- | --- | --- |
| **Endpoint** | **Method** | **Description** |
| /   | GET | Service root and API information |
| /api/health | GET | System health check and readiness status |
| /api/health/ready | GET | Database connection and system readiness |

 

**Authentication & User Management** 

|     |     |     |
| --- | --- | --- |
| **Endpoint** | **Method** | **Description** |
| /api/auth/login | POST | User login with email and password |
| /api/auth/refresh | POST | Refresh JWT access token |
| /api/auth/logout | POST | User logout and token invalidation |
| /api/auth/profile | GET | Get current user profile |
| /api/auth/change-password | POST | Change user password |

**Project Management** 

|     |     |     |
| --- | --- | --- |
| **Endpoint** | **Method** | **Description** |
| /api/projects | GET | List all user's projects |
| /api/projects | POST | Create new project |
| /api/projects/{project_id} | GET | Get project details |
| /api/projects/{project_id} | PUT | Update project |
| /api/projects/{project_id} | DELETE | Delete project |
| /api/projects/{project_id}/statistics | GET | Get project statistics |
| /api/projects/{project_id}/requirements | GET | Get project requirements overview |

**PRD Document Management** 

|     |     |     |
| --- | --- | --- |
| **Endpoint** | **Method** | **Description** |
| /api/projects/{project_id}/upload-prd | POST | Upload PRD document |
| /api/projects/{project_id}/documents | GET | List all documents in project |
| /api/projects/{project_id}/documents/{document_id} | GET | Get document details |
| /api/projects/{project_id}/documents/{document_id}/download | GET | Download document file |
| /api/projects/{project_id}/documents/{document_id}/processing-status | GET | Get document processing status |
| /api/projects/{project_id}/documents/{document_id}/retry-processing | POST | Retry failed document processing |
| /api/projects/{project_id}/documents/{document_id} | DELETE | Delete document |

**Requirements Extraction** 

|     |     |     |
| --- | --- | --- |
| **Endpoint** | **Method** | **Description** |
| /api/projects/{project_id}/requirements | GET | Get extracted requirements for project |
| /api/projects/{project_id}/documents/{document_id}/requirements | GET | Get requirements from specific document |

**User Story Generation** 

|     |     |     |
| --- | --- | --- |
| **Endpoint** | **Method** | **Description** |
| /api/user-stories/projects/{project_id}/generate | POST | Generate user stories from requirements using AI |
| /api/user-stories/projects/{project_id}/preview | POST | Preview generated user stories without saving |
| /api/user-stories/projects/{project_id}/save | POST | Save previewed user stories to project |
| /api/user-stories/projects/{project_id} | GET | List all user stories in project |
| /api/user-stories/projects/{project_id}/stories/{story_id} | GET | Get user story details |
| /api/user-stories/projects/{project_id}/stories/{story_id} | PUT | Update user story |
| /api/user-stories/projects/{project_id}/stories/{story_id}/status | PUT | Update user story status |
| /api/user-stories/projects/{project_id}/stories/{story_id} | DELETE | Delete user story |
| /api/user-stories/projects/{project_id}/manual | POST | Create user story manually |

**Test Case Generation** 

|     |     |     |
| --- | --- | --- |
| **Endpoint** | **Method** | **Description** |
| /api/test-cases/generate/{project_id} | POST | Generate test cases from user stories using AI |
| /api/test-cases/generate-preview/{project_id}/{user_story_id} | POST | Preview generated test cases without saving |
| /api/test-cases/save/{project_id}/{user_story_id} | POST | Save previewed test cases to project |
| /api/test-cases/grouped/{project_id} | GET | Get test cases grouped by user story |
| /api/test-cases/user-story/{project_id}/{user_story_id} | GET | Get test cases for specific user story |
| /api/test-cases/{project_id}/{test_case_id} | PUT | Update test case |
| /api/test-cases/projects/{project_id}/manual | POST | Create test case manually |

**Export Functionality** 

|     |     |     |
| --- | --- | --- |
| **Endpoint** | **Method** | **Description** |
| /api/export/user-stories-excel/{project_id} | GET | Export user stories to Excel format |
| /api/export/jira-excel/{project_id} | GET | Export test cases to Jira-compatible Excel format |

**Dashboard & Analytics** 

|     |     |     |
| --- | --- | --- |
| **Endpoint** | **Method** | **Description** |
| /api/dashboard/overview | GET | Get dashboard overview statistics |
| /api/dashboard/recent-projects | GET | Get user's recent projects |

**Queue Management** 

|     |     |     |
| --- | --- | --- |
| **Endpoint** | **Method** | **Description** |
| /api/projects/{project_id}/queue-task/{document_id} | POST | Add document processing task to queue |
| /api/queue-status | GET | Get overall queue status |
| /api/task-status/{task_id} | GET | Get specific task status |

**Project Members & Collaboration** 

|     |     |     |
| --- | --- | --- |
| **Endpoint** | **Method** | **Description** |
| /api/projects/{project_id}/members | GET | List all project members |
| /api/projects/{project_id}/members/add-or-create | POST | Add or invite member to project |
| /api/projects/{project_id}/members/{user_id} | PUT | Update member role |
| /api/projects/{project_id}/members/{user_id} | DELETE | Remove member from project |
| /api/projects/{project_id}/members/{user_id}/resend-invite | POST | Resend invitation email |

**API Key Management** 

|     |     |     |
| --- | --- | --- |
| **Endpoint** | **Method** | **Description** |
| /api/api-keys | GET | List user's API keys |
| /api/api-keys | POST | Create new API key |
| /api/api-keys/{key_id} | DELETE | Delete API key |
| /api/api-keys/{key_id}/test | POST | Test API key connection |
| /api/api-keys/providers | GET | Get available LLM providers |

**Chunking Configuration** 

|     |     |     |
| --- | --- | --- |
| **Endpoint** | **Method** | **Description** |
| /api/chunking-config/optimal | POST | Get optimal chunking configuration for document |

**LLM Processing Results** 

|     |     |     |
| --- | --- | --- |
| **Endpoint** | **Method** | **Description** |
| /api/projects/{project_id}/llm-processing-results/{document_id} | GET | Get LLM processing results for document |

 

 

 

**Permissions** 

|     |     |     |
| --- | --- | --- |
| **Endpoint** | **Method** | **Description** |
| /api/permissions/me | GET | Get current user's permissions |
| /api/permissions/roles | GET | List available roles |
| /api/permissions/roles/{role} | GET | Get role permissions |

 

**SYSTEM WORKFLOW**  

Document Processing Workflow  

1.  User creates a project through React interface  

2.  User uploads PRD document via file upload component  

3.  Frontend sends document to FastAPI backend /api/projects/{project_id}/upload-prd  

4.  Backend validates file format and stores document  

5.  Document processing task is added to queue  

6.  Queue processor extracts text from document (PDF/DOCX/TXT)  

7.  Document is chunked based on optimal configuration  

8.  Chunks are processed in parallel using Groq LLM API  

9.  Requirements are extracted from each chunk and merged  

10. Processing status is updated in database  

11. Backend returns processing results  

12. Frontend displays extracted requirements to user  

**User Story Generation Workflow**  

1.  User selects requirements (or uses all extracted requirements)  

2.  User clicks "Generate User Stories" in React interface  

3.  Frontend sends request to /api/user-stories/projects/{project_id}/generate  

4.  Backend triggers LLM service with selected requirements  

5.  Document chunks are prepared with requirements context  

6.  Chunks are processed in parallel using Groq API  

7.  User stories are generated for each chunk  

8.  Results are merged and validated  

9.  Preview is returned to frontend  

10. User reviews generated user stories  

11. User can edit user stories before saving  

12. User saves user stories via /api/user-stories/projects/{project_id}/save  

13. User stories are stored in database and associated with project  

**Test Case Generation Workflow**  

1.  User selects user stories from project  

2.  User clicks "Generate Test Cases" in React interface  

3.  Frontend sends request to /api/test-cases/generate/{project_id}  

4.  Backend triggers LLM service with selected user stories  

5.  Document chunks are prepared with user story context  

6.  Chunks are processed in parallel using Groq API  

7.  Test cases are generated for each chunk  

8.  Results are merged and validated  

9.  Preview is returned to frontend  

10. User reviews generated test cases  

11. User can edit test cases before saving  

12. User saves test cases via /api/test-cases/save/{project_id}/{user_story_id}  

13. Test cases are stored in database and grouped by user story  

**Export Workflow**  

1.  User navigates to export section in React interface  

2.  User selects test cases or user stories to export  

3.  User chooses export format (Excel or Jira format)  

4.  Frontend sends request to export endpoint (/api/export/\*)  

5.  Backend retrieves selected items from database  

6.  Data is formatted according to export template  

7.  Excel file is generated using openpyxl  

8.  File is streamed to frontend as download  

9.  User downloads the exported file  

**AI PROCESSING FLOW**  

The backend delegates specialized tasks to dedicated components for efficient AI-powered processing:  

**Document Text Extraction**  

File Processing Service - Handles extraction of text content from various document formats:  

• PDF files using PyPDF2, pdfplumber, and PyMuPDF  

• Word documents (DOCX) using python-docx and docx2txt  

• Text files (TXT) and Markdown files (MD)  

• File type detection using python-magic  

• Asynchronous file operations using aiofiles  

**Document Chunking**  

Chunking Service - Intelligently divides documents into optimal chunks:  

• Section-based chunking for structured documents  

• Paragraph-based chunking for narrative content  

• Configurable chunk sizes based on document type  

• Token counting using tiktoken for LLM compatibility  

• Metadata tracking for chunk context preservation  

• Optimal chunking configuration recommendations  

**LLM Processing Service**  

Groq LLM Integration - Processes chunks in parallel for efficiency:  

• Integration with Groq API using Llama 3.1 70B model  

• Parallel chunk processing with controlled concurrency (max 2 concurrent requests)  

• Circuit breaker pattern for rate limit handling  

• Automatic retry mechanism with exponential backoff  

• Request timeout management (60 seconds)  

• Result merging from multiple chunks  

• Error handling and fallback strategies  

**Requirements Extraction**  

Requirements Prompt Builder - Creates prompts for requirements extraction:  

• Context-aware prompt generation from document chunks  

• Project context integration  

• Structured output format for requirements  

• JSON response parsing and validation  

• Duplicate detection and merging  

• Source tracking (which chunk generated each requirement)  

**User Story Generation**  

User Story Prompt Builder - Generates user stories from requirements:  

• Requirements-to-user-story mapping  

• Acceptance criteria extraction  

• Story point estimation prompts  

• Priority assignment logic  

• Result merging from parallel chunk processing  

• Validation and deduplication  

**Test Case Generation**  

Test Case Prompt Builder - Creates comprehensive test cases:  

• User story to test case mapping  

• Test step generation with preconditions  

• Expected results formulation  

• Test type classification (Functional, Integration, Regression, etc.)  

• Priority assignment based on user story priority  

• Result grouping by user story  

• Test case validation and structure checking  

**Queue Management**  

Processing Queue Service - Manages asynchronous task processing:  

• Task queuing for document processing  

• Task status tracking (Pending, Processing, Completed, Failed)  

• Priority-based task execution  

• Automatic retry for failed tasks  

• Queue monitoring and status reporting  

• Background worker pattern for long-running operations  

**Result Merging & Validation**  

Result Merger - Combines results from parallel chunk processing:  

• Requirements merging from multiple chunks  

• User story deduplication and merging  

• Test case grouping and organization  

• Context preservation across chunks  

• Metadata aggregation  

• Quality validation and structure checking