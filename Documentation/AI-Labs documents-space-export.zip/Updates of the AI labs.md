# Updates of the AI labs

1) AI music Done

2) AI test case generation

3) Football prediction Done

4) Inx chatbot

5) Multi langual chatbot

6)Connect database

7)