# Project Requirements Document

---

### 1\. Purpose & Scope

- **Purpose**:
    - **Automate appointment booking, rescheduling, checking, and cancellation** via AI-driven voice and chat interfaces.
    - Provide **Hindi/Indian language support** for patients using regular phone calls, with real-time, natural conversations.
- **Scope**:
    - Inbound and outbound phone calls using Twilio.
    - Real-time **voice conversations** using Twilio Media Streams + Sarvam AI (STT/TTS).
    - **Web chat UI** and **web-triggered voice calls**.
    - Appointment storage and validation via a database layer with strict business rules.

---

### 2\. Users & Use Cases

- **Primary Users**:
    - Patients or customers calling to manage appointments.
    - Clinic/office staff monitoring or initiating calls from the web interface.
- **Key Use Cases**:
    - **Book appointment**: “Book an appointment tomorrow at 2 PM” / Hindi variants.
    - **Reschedule appointment**: Move an existing appointment to another valid slot.
    - **Cancel appointment**: Cancel by ID or by contextual reference (“my Monday appointment”).
    - **Check appointments**: Ask for upcoming or specific day appointments.
    - **Web chat interaction**: Same intents via text chat.
    - **Initiate outbound call from web UI**: Enter phone number and trigger AI call.

---

### 3\. Functional Requirements

- **FR-1: Voice Call Handling (Twilio)**
    - System shall expose a **Twilio webhook** for inbound calls.
    - On call connect, the system shall play a **greeting** generated via TTS (Sarvam AI primary, Twilio TTS fallback).
    - System shall support **outbound calls** via an API and via the frontend.
    - System shall maintain **call status** and list active calls via dedicated APIs.
- **FR-2: Real-Time Voice Streaming**
    - System shall support **Twilio Media Streams** via WebSocke.
    - Audio shall be processed in **~20 ms chunks** with μ-law ↔ PCM16 conversion and resampling as required.
    - System shall implement **speech activity detection**, turn-taking, and silence handling to avoid overlap and feedback.
    - System shall perform **real-time STT** (Sarvam) and **real-time TTS** for low-latency conversations.
- **FR-3: Chat Interface (WebSocket & REST)**
    - System shall expose **WebSocket** endpoints for real-time chat sessions.
    - System shall provide **REST chat endpoints** (send message, get history, clear history, manage sessions).
    - Chat conversations shall use the **same AI agent** and appointment logic as voice calls.
- **FR-4: AI Agent Behavior (LangChain/LangGraph)**
    - System shall implement a **single ReAct agent** that:
        - Detects intents: book, reschedule, cancel, check appointments, ask questions.
        - Uses **tool calling** for all appointment-related operations; it must not invent appointment data.
        - Maintains **conversation history and context** per session (voice or chat).
    - Tools must include at minimum:
        - Check availability for a given date/time.
        - Get available slots for a date.
        - Create appointment in DB.
        - Update appointment in DB.
        - Cancel appointment in DB.
    - Agent shall:
        - Ask **clarifying questions** when information is incomplete.
        - Confirm details before booking / changing / canceling.
        - Return a unique **appointment ID** on creation.
- **FR-5: Appointment & Business Rules**
    - Dates must be in `YYYY-MM-DD`; times must be in `HH:MM[:SS]` 24h format.
    - Appointments must be in the **future** relative to `Asia/Kolkata` time.
    - **Business hours**: default 09:00–17:00 (configurable).
    - **Slot granularity**: on the hour or half-hour only.
    - Appointment types restricted to configured values (e.g., telephonic, virtual).
    - System shall **suggest alternative slots** when requested time is unavailable.
- **FR-6: Multi-language & Indian Context**
    - System shall support **Hindi** and **English**, including **code-mixed Hinglish**.
    - All STT/TTS shall primarily use **Sarvam AI** with correct models (`saarika:v2.5` for STT, `bulbul:v2` for TTS).
    - System shall be easily extensible to other Indian languages via configuration.
- **FR-7: Web Frontend**
    - System shall provide a **React + TypeScript** SPA that includes:
        - **Chat UI** with message history, typing input, and contextual prompts.
        - **Voice call panel** with phone number input and call status display.
        - **Sidebar** for call status, quick actions (e.g., “Book appointment”), and about/info.
    - Frontend shall call backend via **Axios** and use **WebSockets** for real-time features.
    - Frontend shall be **responsive** and styled using **Tailwind CSS** and **shadcn/ui** components.
- **FR-8: Data & Storage**
    - System shall use **SQLite** by default for appointment data, with ability to switch to a different DB via configuration.
    - Appointment operations (create/read/update/delete, availability) shall be encapsulated in the `db_tool` layer.
    - System shall maintain **per-session conversation history** separately from persistent appointment data.
- **FR-9: Configuration & Environment**
    - System shall load settings from environment variables (via `.env`), including:
        - Twilio credentials & phone number.
        - LLM provider keys (OpenAI, Groq).
        - Sarvam AI API key.
        - Database URL.
        - Business hours, timezone, model names, and temperature.
    - System shall run backend on configurable HOST/PORT (default `0.0.0.0:8000`) and frontend on default Vite port (5173).

---

### 4\. Non-Functional Requirements

- **NFR-1: Performance & Latency**
    - End-to-end **voice response latency** (user speech → AI response audio) should typically be **< 2 seconds** under normal conditions.
    - STT and TTS calls must adhere to Sarvam’s **length and format constraints** (e.g., STT max ~30 seconds per chunk).
- **NFR-2: Reliability & Error Handling**
    - System shall implement **retries with exponential backoff** for Twilio operations.
    - On Sarvam or LLM errors, system shall respond with **user-friendly messages** and optionally fallback to Twilio TTS.
    - WebSocket and Media Stream sessions shall handle **disconnects and reconnections** gracefully.
- **NFR-3: Security & Privacy**
    - All external communication (Twilio webhooks, WebSockets, Sarvam API, LLM APIs) shall use **HTTPS/WSS**.
    - API keys and credentials shall **never be hard-coded**; they must come from environment variables.
    - Access to APIs not meant for public use (e.g., admin/debug endpoints) shall be protected or disabled in production.
- **NFR-4: Maintainability & Extensibility**
    - Code shall follow **clear modular structure** (routers → core → db_tool → agentic_graph).
    - All new functions shall include **Google-style docstrings** and proper type hints.
    - Business rules (hours, timezone, slot size) shall be configurable with minimal code change.
    - Adding new tools or appointment fields shall require localized changes in `db_manager.py`, `db_tools.py`, and agent prompts.
- **NFR-5: Usability & UX**
    - Voice prompts shall be **clear, concise, and localized** to the user’s language where possible.
    - Web UI shall provide **visual feedback** for call status, connection state, and errors.
    - Chat and call flows shall be designed to minimize user effort (e.g., confirm summarized details before booking).

---

### 5\. External Integrations

- **Twilio**: voice calls, webhooks, Media Streams, call status.
- **Sarvam AI**: Hindi/Indian STT & TTS.
- **OpenAI / Groq**: LLM backends for the LangGraph agent.
- **Ngrok (or equivalent)**: tunneling local backend for Twilio webhooks during development.

---

### 6\. Constraints & Assumptions

- System assumes primary timezone **Asia/Kolkata** and Indian clinic working hours by default.
- At least **one LLM provider** (OpenAI or Groq) and **Sarvam AI** must be available for full voice experience.
- In-memory or SQLite DB is acceptable for demo; production deployments will reconfigure DB for persistence and scale.
-