# Design Document: IVR Streaming Refactor

## 1\. Overview

This document outlines the design for refactoring the existing **Twilio-based AI IVR pipeline** to achieve:

- **Sub-500ms end-to-end latency**
- **Elimination of choppy / degraded audio**
- **True real-time streaming behavior**

### Current Pain Points

- Batch-oriented TTS processing
- Blocking I/O operations
- No explicit flow control or backpressure
- Audio jitter and latency spikes

### Target Outcomes

The refactored system introduces:

- True **streaming TTS** using async generators
- **Backpressure handling** via Twilio mark events
- **Latency masking** using cached filler audio
- **Robust barge-in handling**
- Fully **asynchronous, non-blocking architecture**

---

## 2\. Architecture

### 2.1 High-Level Architecture

```mermaid
graph TB
    subgraph "Twilio Media Stream"
        TMS[Twilio Media Stream WebSocket]
    end

    subgraph "IVR System Core"
        WSH[WebSocket Handler]
        ABM[Audio Buffer Manager]
        FCM[Flow Control Manager]
        BAM[Barge-in Manager]
    end

    subgraph "Audio Processing Pipeline"
        STT[Streaming STT Engine]
        LLM[LLM Agent]
        TTS[Streaming TTS Engine]
        FAC[Filler Audio Cache]
    end

    subgraph "External Services"
        SARVAM[Sarvam AI API]
    end

    TMS <--> WSH
    WSH --> ABM
    WSH --> FCM
    WSH --> BAM
    ABM --> STT
    STT --> LLM
    LLM --> TTS
    TTS --> ABM
    FAC --> ABM
    TTS <--> SARVAM
    STT <--> SARVAM
```

---

### 2.2 Streaming Architecture Pattern

The system follows a **producer–consumer model with explicit backpressure**.

**Streams**

1.  **Audio Input**  
    `Twilio → Audio Buffer → STT`
2.  **Processing**  
    `STT → LLM → TTS`
3.  **Audio Output**  
    `TTS Generator → Chunk Buffer → Twilio`
4.  **Flow Control**  
    `Twilio Mark Events → Buffer Control → Transmission Throttling`

---

## 3\. Components & Interfaces

---

### 3.1 Streaming WebSocket Handler

**Purpose**  
Manages Twilio Media Stream WebSocket connections with minimal latency.

**Responsibilities**

- Accept connections within **≤ 50ms**
- Fully async message processing
- Per-call session isolation
- Graceful error handling

```python
class StreamingWebSocketHandler:
    async def handle_media_stream(self, websocket: WebSocket) -> None
    async def process_media_event(self, session_id: str, media_data: dict) -> None
    async def process_mark_event(self, session_id: str, mark_data: dict) -> None
    async def handle_connection_error(self, session_id: str, error: Exception) -> None
```

---

### 3.2 Streaming TTS Engine

**Purpose**  
Generate audio **immediately** using Sarvam AI’s streaming WebSocket API.

**Responsibilities**

- Yield audio chunks as soon as they arrive
- Optimize chunks to **20–50ms**
- Emit end-of-stream signals
- Cancel generation on interruption

```python
class StreamingTTSEngine:
    async def stream_tts(self, text: str) -> AsyncGenerator[bytes, None]
    async def cancel_active_tasks(self) -> None
    def optimize_chunk_size(self, audio_chunk: bytes) -> List[bytes]
```

---

### 3.3 Flow Control Manager

**Purpose**  
Implement backpressure using **Twilio mark events**.

**Responsibilities**

- Track playback completion
- Pause when buffers exceed thresholds
- Resume transmission based on marks
- Exponential backoff on congestion

```python
class FlowControlManager:
    async def track_playback_completion(self, mark_name: str) -> None
    async def check_buffer_capacity(self, session_id: str) -> bool
    async def pause_transmission(self, session_id: str) -> None
    async def resume_transmission(self, session_id: str) -> None
    def calculate_backoff_delay(self, retry_count: int) -> float
```

---

### 3.4 Filler Audio Cache

**Purpose**  
Mask LLM latency using pre-generated filler audio.

**Responsibilities**

- Load cached audio on startup
- Generate filler clips only if missing
- Persist in **mulaw** format
- Randomize playback
- Seamless transition to real response

```python
class FillerAudioCache:
    async def initialize_cache(self) -> None
    async def load_cached_audio_from_disk(self) -> Dict[str, bytes]
    async def generate_and_save_filler_clips(self) -> None
    async def get_random_filler(self) -> bytes
    def is_cache_ready(self) -> bool
    def cache_exists_on_disk(self) -> bool
    async def save_filler_to_disk(self, filename: str, audio_data: bytes) -> None
```

---

### 3.5 Barge-in Manager

**Purpose**  
Handle user interruptions during system speech.

**Responsibilities**

- Detect user speech mid-playback
- Clear server + Twilio buffers
- Switch to listening mode in **≤ 100ms**
- Preserve partial input

```python
class BargeInManager:
    async def detect_user_speech(self, audio_data: bytes) -> bool
    async def clear_audio_buffers(self, session_id: str) -> None
    async def send_clear_message(self, session_id: str) -> None
    async def switch_to_listening_mode(self, session_id: str) -> None
    async def preserve_partial_input(self, session_id: str, audio_data: bytes) -> None
```

---

### 3.6 Audio Buffer Manager

**Purpose**  
Prevent jitter through controlled buffering.

**Responsibilities**

- Maintain optimal buffer depth
- Monitor buffer health
- Coordinate with flow control
- Handle overflow / underflow

```python
class AudioBufferManager:
    def add_audio_chunk(self, session_id: str, chunk: bytes) -> None
    def get_buffer_level(self, session_id: str) -> float
    def is_buffer_full(self, session_id: str) -> bool
    def clear_buffer(self, session_id: str) -> None
    async def monitor_buffer_health(self, session_id: str) -> None
```

---

## 4\. Data Models

### 4.1 Streaming Session State

```python
@dataclass
class StreamingSession:
    session_id: str
    call_sid: str
    stream_sid: str
    websocket: WebSocket

    # Audio state
    audio_buffer: bytes
    is_speaking: bool
    is_listening: bool

    # Flow control
    pending_marks: Dict[str, float]
    buffer_level: float
    transmission_paused: bool

    # Metrics
    latency_metrics: LatencyMetrics
    audio_quality_metrics: AudioQualityMetrics

    # Barge-in
    barge_in_detected: bool
    partial_input_buffer: bytes

    created_at: datetime
    last_activity: datetime
```

---

### 4.2 Audio Chunk Model

```python
@dataclass
class AudioChunk:
    data: bytes
    chunk_id: str
    timestamp: float
    duration_ms: int
    format: str  # mulaw / pcm16
    sample_rate: int

    mark_name: Optional[str] = None
    requires_ack: bool = False
```

---

### 4.3 Performance Metrics

```python
@dataclass
class LatencyMetrics:
    stt_latency_ms: float
    llm_processing_ms: float
    tts_latency_ms: float
    end_to_end_ms: float
    time_to_first_chunk_ms: float
```

```python
@dataclass
class AudioQualityMetrics:
    jitter_ms: float
    packet_loss_rate: float
    audio_dropouts: int
    sample_rate_consistency: bool
    artifact_detection_score: float
```

---

## 5\. Correctness Properties

> **Definition**  
> A property defines behavior that must hold true across all valid executions.

### Key Properties (Excerpt)

- **Streaming TTS Immediacy** – no full-audio waits
- **20–50ms Chunk Size Enforcement**
- **Continuous Audio Flow (no gaps)**
- **Mark-based Backpressure Control**
- **Barge-in ≤ 100ms reaction time**
- **Async-only I/O guarantees**
- **End-to-end latency tracking**
- **Audio fidelity preservation**

> _All 38 properties are explicitly mapped to system requirements._

---

## 6\. Error Handling

### Connection Errors

- WebSocket drops → exponential backoff + circuit breaker
- Network timeout → degrade gracefully
- Service outage → cached filler fallback

### Audio Processing Errors

- TTS failure → fallback audio / text
- STT failure → user re-prompt
- Buffer overflow → emergency clear

### Performance Degradation

- High latency → adaptive quality reduction
- Memory pressure → GC + buffer shrink
- CPU overload → task prioritization

---

## 7\. Testing Strategy

### Dual Testing Model

**Unit Tests**

- Connection lifecycle
- Buffer edge cases
- Audio format conversions
- Failure scenarios

**Property-Based Tests (Hypothesis)**

- ≥ 100 iterations per property
- Randomized input coverage
- Shrinking enabled

---

### Testing Categories

1.  Streaming behavior
2.  Concurrency & isolation
3.  Performance & throughput
4.  Error recovery
5.  Audio quality fidelity

---

### Integration Testing

- End-to-end latency measurement
- Multi-call load simulation
- Network degradation scenarios
- Sarvam AI service stress testing

---

If you want, I can next:

- Convert this into a **Notion PRD template**
- Extract **engineering tasks / milestones**
- Generate **property-to-test mappings**
- Create a **review-ready architecture summary** for stakeholders