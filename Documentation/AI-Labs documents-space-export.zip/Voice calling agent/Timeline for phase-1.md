# Timeline for phase-1

|     |     |     |
| --- | --- | --- |
| **Date** | **Backend & Database Infrastructure** | **Intent Logic & IVR Flow** |
| **2 Feb** | • Initialize PostgreSQL (Users/Appointments tables).  • Extract phone numbers from metadata for identity. | • Build Unified Intent Detection (Route to Booking/Cancel).  • Implement name enrichment/capture flow. |
| **3 Feb** | • Build `user_id` query/creation logic.  • Develop Date/Time availability validation service. | • Build sequential IVR booking flow (Date/Time/Notes).  • Implement multi-appointment disambiguation logic. |
| **4 Feb** | • Build Discovery service for UPCOMING appointments.  • Develop Status Update service (CANCELLED status). | • Build error-handling prompts for invalid/full slots.  • Integrate availability checks into the reschedule flow. |
| **5 Feb** | • Construct Rescheduling update logic (Timestamps). | • Ensure booking pipeline is user-type agnostic.  • Conduct initial integration of update logic. |
| **6 Feb** | • Implement `call_sid` persistence (Drop protection). | • Final End-to-End lifecycle integration testing. |