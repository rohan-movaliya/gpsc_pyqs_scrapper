# Planning and Diagrams

# Phase-wise planning

## 1\. Objective

Design and implement a **phone-number–driven IVR appointment system** that supports:

- User onboarding (new + existing)
- Appointment booking
- Appointment cancellation
- Appointment rescheduling

All flows must:

- Work **synchronously during a live call**
- Maintain **strong data consistency**
- Be **IVR-friendly** (one question at a time)
- Be **database-driven and deterministic**

---

## 2\. Core Design Principles

### 2.1 Phone Number as Identity Anchor

- Mobile number is the **primary lookup key**
- Every call starts with a phone number resolution
- `user_id` is generated once and reused everywhere

### 2.2 Early User Creation, Progressive Enrichment

- User record is created immediately if not found
- Mandatory fields (name) are captured during conversation
- Business flows never wait for post-call completion

### 2.3 Unified Business Pipelines

- Booking flow is shared for:
    - New users
    - Existing users
    - Regular appointments
    - Follow-up appointments
- Cancel and reschedule share the same appointment discovery logic

---

## 3\. High-Level System Architecture

```
Incoming Call
   ↓
IVR / LLM Orchestrator
   ↓
User Service (User lookup / creation)
   ↓
Appointment Service (CRUD + availability)
   ↓
Database
```

Each service is **stateless**; state is maintained via:

- `call_sid`
- `user_id`
- Appointment IDs

---

## 4\. Data Model (Minimal & Final)

### 4.1 Users Table

```
users
-----
user_id (PK)
phone_number (UNIQUE, NOT NULL)
name (NOT NULL)
created_at
```

### 4.2 Appointments Table

```
appointments
------------
appointment_id (PK)
user_id (FK)
date
time
notes
status (UPCOMING, CANCELLED)
created_at
updated_at
```

---

## 5\. Flow 1: User Onboarding (Call Entry)

### 5.1 Trigger

- Incoming IVR call

### 5.2 Steps

1.  Extract mobile number from call metadata
2.  Query `users` table using phone number

#### If user exists:

- Fetch `user_id`
- Proceed to intent detection

#### If user does not exist:

1.  Create user record with:
    - phone_number
    - name = NULL (temporary)
2.  Ask user for name
3.  Update same user record with name
4.  Proceed to intent detection

### 5.3 Guarantees

- Exactly one user record per phone number
- `user_id` always exists before appointments are created
- No duplicate users

---

## 6\. Flow 2: Intent Detection & Routing

Once onboarding is complete, the system determines intent:

```
User intent ∈ {
  Book appointment,
  Cancel appointment,
  Reschedule appointment
}
```

Routing is purely **intent-based**, independent of user type.

---

## 7\. Flow 3: Appointment Booking

### 7.1 Entry Conditions

- User is onboarded
- `user_id` is known

### 7.2 Booking Steps

1.  Ask user for preferred date and time
2.  Check availability in DB
3.  If unavailable:
    - Re-prompt for date and time
4.  If available:
    - Ask for notes or reason
5.  Confirm appointment
6.  Create appointment record

### 7.3 Key Rules

- Availability check is mandatory
- Appointment is created only after confirmation
- Booking logic is identical for:
    - New users
    - Existing users
    - Regular or follow-up appointments

---

## 8\. Flow 4: Appointment Cancellation

### 8.1 Entry Conditions

- User requests cancellation

### 8.2 Cancellation Steps

1.  Fetch upcoming appointments for `user_id`
2.  If none:
    - Inform user and exit
3.  If one appointment:
    - Inform details
    - Ask for confirmation
    - Ask reason
    - Cancel appointment
4.  If multiple appointments:
    - List appointments with dates
    - Ask user to select one
    - Ask reason
    - Cancel selected appointment

### 8.3 DB Operation

- Update appointment status to `CANCELLED`
- Do not delete records

---

## 9\. Flow 5: Appointment Reschedule

### 9.1 Entry Conditions

- User requests reschedule

### 9.2 Reschedule Steps

1.  Fetch upcoming appointments for `user_id`
2.  If none:
    - Inform user and exit
3.  If one appointment:
    - Proceed to reschedule flow
4.  If multiple appointments:
    - List appointments
    - Ask user to select one

### 9.3 Shared Reschedule Logic

1.  Ask for new date and time
2.  Check availability in DB
3.  If unavailable:
    - Re-prompt
4.  If available:
    - Confirm change
    - Update appointment record

---

## 10\. Error Handling & Edge Cases

### 10.1 Call Drop Mid-Flow

- User already exists in DB
- No orphan appointments created
- Safe retry on next call

### 10.2 Duplicate Calls

- Phone number uniqueness prevents duplication
- Idempotent user lookup

### 10.3 Ambiguous Responses

- Always ask **one question at a time**
- Re-prompt on unclear input

---

## 11\. Execution Order (Recommended)

### Phase 1 – Foundation

- User table
- Phone number lookup
- User creation + name capture

### Phase 2 – Booking

- Availability checks
- Appointment creation

### Phase 3 – Cancellation

- Fetch upcoming appointments
- Multi vs single logic

### Phase 4 – Rescheduling

- Shared appointment discovery
- Slot validation loop

---

## 12\. Mental Model to Keep Consistent

> **Onboarding creates identity.**  
> **Booking modifies state.**  
> **Cancellation and rescheduling operate on existing state.**

---

## 13\. What This Enables Long-Term

- Multi-channel reuse (WhatsApp, Web, App)
- Analytics per user
- Follow-up reminders
- Audit-safe appointment lifecycle

---

If you want next:

- Convert this plan into **LangGraph states**
- Convert into **API contracts**
- Convert into **task breakdown for Jira**
- Validate against **Twilio IVR constraints**

Say what you want to operationalize next.

# Diagrams

User onboarding diagram

```mermaid
flowchart TD
    A[Incoming Call] --> B[Extract mobile number]
    B --> C{User exists?}

    %% Existing user
    C -->|Yes| D[Fetch user by mobile number]
    D --> F[Proceed with conversation]

    %% New user onboarding
    C -->|No| G[Create user record]
    G --> H[Store mobile number]
    H --> I[Generate user_id]
    I --> J[Ask user for name]

    J --> K[Capture user name]
    K --> L[Update user record with name]
    L --> F
```

Appointment flow

```mermaid
flowchart TD
    A[Start] --> B{Is user registered?}

    %% New user registration
    B -->|No| C[Collect user details]
    C --> D[Register user in system]
    D --> E[Proceed to appointment booking]

    %% Existing user flow
    B -->|Yes| F[Fetch appointment history]
    F --> G[Inform user about previous appointments]
    G --> H{Book follow-up appointment?}
    H -->|Yes| E
    H -->|No| E

    %% Shared appointment booking flow
    E --> I[Ask for preferred date & time]
    I --> J[Check availability in database]
    J --> K{Slot available?}
    K -->|No| I
    K -->|Yes| L[Ask for notes / reason]
    L --> M[Confirm appointment]
    M --> N[Appointment booked successfully]
```

cancel appointment

```mermaid
flowchart TD
    A[User requests appointment cancellation] --> B[Fetch upcoming appointments from DB]

    B --> C{Any upcoming appointments?}
    C -->|No| D[Inform user: No upcoming appointments]
    D --> Z[End flow]

    C -->|Yes| E{Multiple upcoming appointments?}

    %% Multiple appointments case
    E -->|Yes| F[List appointments with dates & times]
    F --> G[Ask user to select appointment to cancel]
    G --> H[Capture selected appointment]
    H --> I[Ask reason for cancellation]
    I --> J[Confirm cancellation]
    J --> K[Cancel appointment in DB]
    K --> L[Confirm cancellation to user]
    L --> Z

    %% Single appointment case
    E -->|No| M[Inform user of upcoming appointment]
    M --> N[Ask for confirmation]
    N --> O{User confirms?}
    O -->|No| Z
    O -->|Yes| P[Ask reason for cancellation]
    P --> K
```

appointment reschedule

```mermaid
flowchart TD
    A[User requests appointment reschedule] --> B[Fetch upcoming appointments from DB]

    B --> C{Any upcoming appointments}
    C -->|No| D[Inform user no upcoming appointments]
    D --> Z[End flow]

    C -->|Yes| E{Multiple upcoming appointments}

    %% Multiple appointments case
    E -->|Yes| F[List appointments with date and time]
    F --> G[Ask user to select appointment by date]
    G --> H[Capture selected appointment]

    %% Single appointment case
    E -->|No| I[Inform user of upcoming appointment]
    I --> H

    %% Shared reschedule flow
    H --> J[Ask for new preferred date and time]
    J --> K[Check availability in database]
    K --> L{Slot available}
    L -->|No| J
    L -->|Yes| M[Confirm rescheduled appointment]
    M --> N[Update appointment in database]
    N --> O[Inform user appointment rescheduled successfully]
    O --> Z
```