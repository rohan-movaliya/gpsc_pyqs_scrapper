# Technical Architecture Document

## 1\. Overview

### High-level Purpose

The Healthcare AI Voice IVR System is an intelligent appointment booking platform that enables users to schedule, reschedule, and cancel medical appointments through natural voice conversations in Hindi and English. The system leverages advanced AI agents, real-time voice streaming, and multi-modal interfaces to provide seamless healthcare appointment management.

### Key Domains and Responsibilities

- **Voice Communication**: Real-time bi-directional audio streaming via Twilio Media Streams
- **AI Agent Orchestration**: LangGraph-powered ReAct agents for appointment management
- **Speech Processing**: Hindi/English TTS and STT using Sarvam AI
- **Appointment Management**: Database-driven CRUD operations with business rule validation
- **Web Interface**: React-based chat and voice call interface
- **API Gateway**: FastAPI-based REST and WebSocket endpoints

### Core Architectural Principles

- **Event-Driven Architecture**: WebSocket-based real-time communication
- **Microservice-Oriented**: Modular components with clear separation of concerns
- **AI-First Design**: LangGraph agents as primary business logic orchestrators
- **Multi-Modal Support**: Unified AI behavior across voice, chat, and streaming interfaces
- **Fault Tolerance**: Retry mechanisms, graceful degradation, and error recovery

---

## 2\. Tech Stack

| Layer | Technology | Purpose |
| --- | --- | --- |
| **Frontend** | React 18 + TypeScript | Modern UI with real-time chat and voice controls |
| **UI Framework** | Tailwind CSS | Utility-first styling with accessible components |
| **Backend Framework** | FastAPI + Uvicorn | High-performance async API server |
| **AI Orchestration** | LangChain + LangGraph | Agent workflows and tool integration |
| **LLM Providers** | OpenAI GPT-4o, Groq Llama-3.3-70b | Natural language processing with failover |
| **Voice Services** | Twilio Voice + Media Streams | Programmable voice calls and real-time audio |
| **Speech AI** | Sarvam AI SDK | Hindi/English TTS and STT capabilities |
| **Database** | SQLite | Lightweight appointment data persistence |
| **Real-time Communication** | WebSockets | Bi-directional streaming for chat and voice |

---

## 3\. Application Structure

```
├── backend/                            # Python FastAPI Backend
│   ├── app/                           # Main application module
│   │   ├── main.py                    # FastAPI app entry point + WebSocket handling
│   │   ├── core/                      # Core utilities and configuration
│   │   │   ├── config.py             # Settings and environment variables
│   │   │   ├── sarvam_client.py      # Sarvam AI SDK wrapper (TTS/STT)
│   │   │   └── websocket_manager.py  # WebSocket connection management
│   │   ├── routers/                   # API route handlers
│   │   │   ├── chat.py               # Chat API endpoints
│   │   │   ├── voice.py              # Voice/Twilio webhook endpoints
│   │   │   └── voice_stream.py       # Real-time voice streaming endpoints
│   │   └── audio/                     # Audio processing utilities
│   │       └── audio_utils.py        # Audio manipulation and conversion
│   ├── agentic_graph/                 # LangGraph AI agent implementation
│   │   ├── agent_graph.py            # ReAct agent setup and workflow
│   │   └── prompts.py                # AI agent system prompts
│   ├── db_tool/                       # Database abstraction layer
│   │   ├── db_manager.py             # SQLite database operations
│   │   └── db_tools.py               # LangChain-compatible database tools
│   └── requirements.txt               # Python dependencies
├── frontend/                          # React TypeScript Frontend
│   ├── src/                          # Frontend source code
│   │   ├── App.tsx                   # Main application component
│   │   ├── components/               # React components
│   │   │   ├── ui/                   # shadcn/ui base components
│   │   │   ├── chat/                 # Chat interface components
│   │   │   ├── voice/                # Voice call components
│   │   │   ├── sidebar/              # Sidebar components
│   │   │   └── layout/               # Layout components
│   │   ├── services/                 # API service layer
│   │   ├── hooks/                    # Custom React hooks
│   │   ├── store/context/            # React Context providers
│   │   ├── types/                    # TypeScript type definitions
│   │   └── utils/                    # Utility functions
│   ├── package.json                  # Frontend dependencies
│   └── vite.config.ts                # Vite configuration
```

### Brief Responsibility of Each Folder

- `backend/app/`: FastAPI application with REST/WebSocket endpoints
- `backend/agentic_graph/`: AI agent logic using LangGraph ReAct pattern
- `backend/db_tool/`: Database operations and LangChain tool integration
- `frontend/src/components/`: Reusable React UI components
- `frontend/src/services/`: API client and external service integrations
- `frontend/src/store/`: Application state management using Context API

---

## 4\. Architecture and Flow

### Request Lifecycle

#### Voice Call Flow:

1.  **Incoming Call**: Twilio → `/api/voice/incoming-call` → TwiML with Media Stream connection
2.  **Stream Connection**: WebSocket established at `/api/voice/stream`
3.  **Audio Processing**: Mulaw → PCM16 → Resampling (8kHz → 16kHz)
4.  **Speech Recognition**: Sarvam AI STT (Hindi/English)
5.  **AI Processing**: LangGraph ReAct agent with database tools
6.  **Speech Synthesis**: Sarvam AI TTS → Mulaw encoding
7.  **Audio Streaming**: Chunked audio (20ms frames) back to Twilio

#### Chat Flow:

1.  **WebSocket Connection**: Client → `/ws/{session_id}`
2.  **Message Processing**: User message → LangGraph agent
3.  **Tool Execution**: Database operations via LangChain tools
4.  **Response Streaming**: AI response → WebSocket → Client

### Agent Routing / Orchestration Flow

The system uses a **single comprehensive ReAct agent** rather than multiple specialized agents:

- **Agent Type**: LangGraph `create_react_agent` with ReAct (Reasoning and Acting) pattern
- **Tools Available**:
    - `check_appointment_availability(date, time)`
    - `create_appointment_in_db(name, mobile_number, type, date, time, notes)`
    - `get_available_slots_for_date(date)`
    - `update_appointment_in_db(appointment_id, ...)`
    - `cancel_appointment_in_db(appointment_id)`
- **Context Injection**: Current Asia/Kolkata time added to every request
- **Response Sanitization**: Markdown removal for TTS compatibility

### State and Memory Handling

- **Chat Sessions**: In-memory conversation history per WebSocket session
- **Voice Streaming**: Session-based conversation history in `streaming_sessions` dict
- **LangGraph Memory**: Built-in conversation memory using thread IDs
- **Call State**: Active call tracking with session metadata
- **Audio Buffering**: Intelligent buffering (500ms-10s) with silence detection

---

## 5\. AI Layer (Agents and Orchestration)

### Supervisor Agent Role

The system uses a **single ReAct agent** approach rather than a supervisor pattern:

- **Primary Agent**: Comprehensive appointment management agent
- **Decision Making**: Built-in reasoning for tool selection and execution
- **Context Awareness**: Maintains conversation state across interactions

### Specialized Agents

**Single Agent Architecture**:

- **Appointment Agent**: Handles all appointment-related operations
- **Tool Integration**: Direct access to 5 database tools
- **Multi-Modal**: Same agent serves chat, voice, and streaming interfaces

### Memory and Summarization Strategy

- **Session-Based Memory**: Conversation history maintained per session/call
- **LangGraph Memory**: Built-in memory management with thread IDs
- **Context Preservation**: Full conversation context passed to agent
- **Time Context**: Current timestamp injected for temporal awareness

### Model Configuration Strategy

- **Primary LLM**: OpenAI GPT-4o (configurable via `OPENAI_MODEL`)
- **Alternative LLM**: Groq Llama-3.3-70b (configurable via `GROQ_MODEL`)
- **Provider Selection**: Environment variable `LLM_PROVIDER` (openai/groq)
- **Model Fallback**: Automatic failover between providers
- **Temperature**: Configurable via `AI_TEMPERATURE` (default: 0.7)

---

## 6\. Domain Tools and Context Integration

| Domain | Capabilities |
| --- | --- |
| **Appointment Availability** | Check slot availability, validate business hours, suggest alternatives |
| **Appointment Creation** | Create appointments with validation, mobile number verification, type validation |
| **Slot Management** | Generate available slots, filter past times, business hour enforcement |
| **Appointment Updates** | Modify existing appointments, status changes, field-level updates |
| **Appointment Cancellation** | Soft-delete appointments, status management, cleanup operations |
| **Data Validation** | Date/time format validation, mobile number validation, name validation |
| **Business Rules** | Future-only bookings, slot granularity (hour/half-hour), business hours (9 AM-5 PM) |

---

## 7\. Caching and Background Processing

### Cache Strategy

- **In-Memory Caching**: Conversation history cached per session
- **Audio Caching**: Temporary audio files for TTS/STT processing
- **Session Storage**: Active call sessions and streaming states
- **No Persistent Cache**: System uses direct database queries for real-time data

### Expiry and Refresh Logic

- **Session Expiry**: Sessions cleaned up on WebSocket disconnect
- **Audio Cleanup**: Temporary files removed after processing
- **Memory Management**: Conversation history bounded by session lifecycle

### Background Tasks

- **Silence Detection**: Asynchronous timers for speech activity monitoring
- **Audio Processing**: Background audio buffer processing during voice streams
- **Connection Monitoring**: WebSocket connection health checks
- **Cleanup Tasks**: Automatic cleanup of disconnected sessions

---

## 8\. Data and Retrieval Pipeline

### Ingestion Flow

1.  **Voice Input**: Twilio Media Streams → Mulaw audio chunks
2.  **Audio Conversion**: Mulaw → PCM16 → Resampling (8kHz → 16kHz)
3.  **Speech Recognition**: Sarvam AI STT → Text transcript
4.  **Text Processing**: AI agent processing with context injection

### Data Quality Handling

- **Audio Validation**: Minimum duration checks, silence detection, RMS analysis
- **Speech Activity Detection**: Prevents processing of silence or noise
- **Input Sanitization**: Text cleaning, format validation, business rule enforcement
- **Error Recovery**: Graceful handling of STT/TTS failures with fallbacks

### Storage and Retrieval Approach

- **SQLite Database**: Lightweight persistence for appointment data
- **ACID Compliance**: Atomic transactions for data consistency
- **Real-time Queries**: Direct database access without caching layer
- **Schema Management**: Automatic table creation and migration support

---

## 9\. Key Dependencies

### Core Dependencies

- **fastapi**: Modern async web framework
- **uvicorn**: ASGI server for FastAPI
- **websockets**: Real-time communication
- **twilio**: Voice communication and Media Streams

### AI Dependencies

- **langchain**: AI agent framework and tool integration
- **langgraph**: Stateful agent workflows and memory management
- **langchain-openai**: OpenAI LLM integration
- **langchain-groq**: Groq LLM integration
- **openai**: OpenAI API client
- **groq**: Groq API client

### Storage Dependencies

- **sqlite3**: Built-in database (Python standard library)
- **pydantic**: Data validation and serialization

### Testing Dependencies

- **hypothesis**: Property-based testing framework

### Logging Dependencies

- **logging**: Built-in Python logging (standard library)

---

## 10\. API Endpoints

| Method | Endpoint | Purpose |
| --- | --- | --- |
| **GET** | `/` | Root endpoint with server status |
| **GET** | `/health` | Health check for monitoring |
| **WebSocket** | `/ws/{session_id}` | Real-time chat communication |
| **POST** | `/api/chat/message` | Send message to AI assistant |
| **GET** | `/api/chat/history/{session_id}` | Get conversation history |
| **DELETE** | `/api/chat/history/{session_id}` | Clear conversation history |
| **GET** | `/api/chat/sessions` | List active chat sessions |
| **POST** | `/api/chat/new-session` | Create new chat session |
| **POST** | `/api/voice/initiate-call` | Initiate outbound voice call |
| **POST** | `/api/voice/incoming-call` | Twilio webhook for incoming calls |
| **GET** | `/api/voice/call-status/{call_sid}` | Get call status information |
| **GET** | `/api/voice/active-calls` | List active voice calls |
| **WebSocket** | `/api/voice/stream` | Twilio Media Streams endpoint |
| **GET** | `/api/voice/active-streams` | List active streaming sessions |

### API Documentation

- **Interactive Docs**: Available at `/docs` (Swagger UI)
- **Alternative Docs**: Available at `/redoc` (ReDoc)
- **OpenAPI Schema**: Auto-generated from FastAPI route definitions

---

## Key Features Summary

### Real-Time Voice Streaming

- **Twilio Media Streams**: Bi-directional audio streaming with WebSocket
- **Low Latency**: 20ms audio chunks for natural conversation flow
- **Speech Activity Detection**: Intelligent silence detection and turn-taking
- **Audio Processing**: Mulaw ↔ PCM16 conversion with resampling

### Multi-Language AI Support

- **Sarvam AI Integration**: Native Hindi and English TTS/STT
- **Bilingual Conversations**: Seamless Hindi-English (Hinglish) support
- **Cultural Context**: Optimized for Indian communication patterns

### Intelligent Appointment Management

- **Business Rule Enforcement**: Business hours, slot granularity, future-only bookings
- **Comprehensive Validation**: Date/time, mobile number, appointment type validation
- **Alternative Suggestions**: Closest available slots when requested time unavailable

### Robust Error Handling

- **Retry Logic**: Exponential backoff for Twilio operations
- **Graceful Degradation**: Fallback mechanisms for TTS/STT failures
- **Connection Recovery**: Automatic reconnection and cleanup