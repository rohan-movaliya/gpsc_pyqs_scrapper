# One-Pager: AI PoC and Production-Ready Implementations

This document is a **practical guide** for using the AI Solution / Delivered Project One-Pager across **AI Lab, Sales, and Delivery teams**. Its main goal is to ensure everyone presents AI work in a **consistent, clear, and business-focused** way—without overcomplicating things.

### What this guide helps you do

- Understand **which sections to fill** based on your use case
- Write content that matches the **right audience and intent**
- Avoid common mistakes that reduce clarity or impact

### How to use it by team

**AI Lab Products**

- Write in **present tense**
- Skip the **Client Snapshot**
- Focus on **capabilities, features, and reusability**
- Keep it product-driven, not client-specific

**Delivered Client Projects**

- Write in **past tense**
- Include **real metrics** or **validated performance ranges**
- Client Snapshot is optional and must be **anonymized**
- Highlight what was delivered and the value created

**Sales & Proposals**

- Lead with **outcomes, ROI, and scalability**
- Keep it **CXO-friendly** (Page 1 matters most)
- Position AI as a **business enabler**, not just tech

### Do’s and Don’ts (non-negotiable)

**DO**

- Keep language **business-first and impact-driven**
- Use **ranges** if exact numbers are confidential
- Make it easy for non-technical readers to get the point

**DON’T**

- Mention **client names** without approval
- Overload the page with **deep technical details**
- Turn it into a documentation dump

### Bottom line

This one-pager is not about showing _how smart the tech is_—it’s about showing **why it matters**. If someone can skim it in a minute and still get the value, you’ve done it right.