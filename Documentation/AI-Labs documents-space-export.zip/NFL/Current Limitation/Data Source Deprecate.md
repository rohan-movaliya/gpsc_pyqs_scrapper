# Data Source Deprecate

# **NFL Data Source Migration Notice**

## **1\. Reason for Migration**

The existing data loader `nfl_data_load.py` is going to be **deprecated soon**, and there is **no planned update or long-term support** for it.  
Because of this, the project must migrate to a stable and actively maintained data source.

To avoid future issues, I decided to **switch the datasource as soon as possible** to the new module:  
`nfl_read.py`

---

## **2\. Verification of the New Data Source**

Before migrating, the data generated from `nfl_read.py` was reviewed and validated.  
Key observations:

### ✔ Data Consistency

- The structure and content of the new dataset is **almost the same** as the old one.
- Most fields match correctly and provide the data required for the model.

### ✔ Differences Identified

Although the datasets are similar, a few changes were found:

#### **2.1 Column Name Differences**

- Some column names are slightly different from the previous data source.
- This requires **minor updates** in preprocessing and feature-mapping code.

#### **2.2 Attribute Changes**

- Some attributes have been renamed or modified.
- A review is needed to ensure compatibility with existing feature engineering steps.

#### **2.3 Method Change for Writing Files**

- Instead of:
    
    ```python
    df.to_csv()
    ```
    
- The new module requires:
    
    ```python
    df.write_csv()
    ```
    
- This change must be updated wherever CSV writing is used in the pipeline.

---

## **3\. Conclusion**

Because `nfl_data_load.py` **is deprecated** and will no longer receive updates, switching to `nfl_read.py` is necessary.  
The new datasource has been reviewed, and while the data is mostly the same, small adjustments are required due to:

- Changed column names
- Updated attribute names
- Modified file-writing method (`write_csv()`)

The migration ensures that the pipeline remains stable and future-proof.