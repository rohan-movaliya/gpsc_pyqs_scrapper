# Confidence Issue

## **1\. Accuracy Limitation Due to Team-Level Features**

Our prediction models are currently limited because we only use **team-level statistics**. These features do not provide enough detail about individual players, matchups, injuries, or game-specific conditions.  
Because of this, all models hit a natural accuracy ceiling of **65–70%**, no matter how much we tune them.

---

## **2\. Random Forest Limitation**

Random Forest gives us **stable results** and **decent confidence scores**, but:

- It averages around **65% accuracy**
- It cannot learn deeper patterns because the available data lacks detail
- Its performance does not improve even after tuning

This model works the best for our limited data, but it cannot push accuracy higher.

---

## **3\. CatBoost Limitation**

CatBoost gives a slightly better accuracy of **around 70%**, but it has a major issue:

- The **confidence scores are almost always near 50-50**, even when the prediction is correct
- This happens because the model does not have strong enough features to separate one team from the other

So although accuracy improves, **the confidence values are not trustworthy**.

---

## **4\. Deep Learning Model Limitation**

A deep learning model produces **strong confidence values**, but:

- It **underfits** because we do not have enough rich data
- It cannot learn meaningful patterns from team-level stats alone

Deep learning requires much more detailed data to perform well, which we currently do not have.

---

## **5\. Overall Data Limitation**

All models struggle because our data is:

- Too small
- Too high-level (team stats only)
- Missing important signals like player performance, injuries, momentum, and game context

This lack of detailed information limits both **accuracy** and **confidence** across all models.

---

# **UI Limitation: ESPN Probability Data**

## **6\. ESPN Probability Endpoint Limitation**

In the UI, we display **ESPN win probabilities**, but the API has major reliability issues:

- Sometimes it returns probability data
- Other times it returns nothing
- ESPN only updates these values when a game is **live** or actively tracked
- When the game is not live, the endpoint often goes blank

This causes the UI to show empty values or become inconsistent.