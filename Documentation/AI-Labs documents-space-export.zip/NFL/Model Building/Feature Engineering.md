# Feature Engineering

### **Overview**

The feature engineering pipeline creates temporal, team strength, and historical matchup features from cleaned match-level data. It adds rolling statistics, previous game features, Glicko2 ratings, and head-to-head win ratios.

---

## **1\. add_match_result()**

**Location:** backend/app/pipeline/[feature.py](http://feature.py) (lines 6-27)

**Purpose:** Creates a binary/triple outcome label from home and away scores.

**Parameters:**

- df (pd.DataFrame): Input DataFrame with scores

- home_col (str): Home team score column (default: "total_home_score")

- away_col (str): Away team score column (default: "total_away_score")

- result_col (str): Output column name (default: "match_result")

**Returns:**

- pd.DataFrame: DataFrame with match_result column

**How it works:**

1.  Compares home_col and away_col

1.  Sets match_result:

- 1 if home wins

- 0 if away wins

- 2 if tie

**Implementation:**

df\[result_col\] = np.where(

 

**Notes:**

- Used as the target variable

- Ties (2) are removed for binary classification

- Assumes scores are numeric

---

## **2\. add_last5_stat()**

**Location:** backend/app/pipeline/[feature.py](http://feature.py) (lines 30-92)

**Purpose:** Creates rolling window features: mean of the last 5 games for each team.

**Parameters:**

- df (pd.DataFrame): Input DataFrame (must be chronologically sorted)

- home_feature (str): Home team feature column name

- away_feature (str): Away team feature column name

**Returns:**

- pd.DataFrame: DataFrame with last_5_{home_feature} and last_5_{away_feature} columns

**How it works:**

1.  Maintains a history dictionary per team: teams\[team_name\] = \[value1, value2, ...\]

1.  For each row:

- Computes mean of the last 5 values for home team: np.mean(teams\[home_team\]\[-5:\])

- Computes mean of the last 5 values for away team: np.mean(teams\[away_team\]\[-5:\])

- Appends current game values to each team's history

1.  Creates columns:

- last_5_{home_feature}: rolling mean for home team

- last_5_{away_feature}: rolling mean for away team

**Example:**

If home_feature = "total_home_score" and away_feature = "total_away_score":

- last_5_total_home_score: mean of home team's last 5 scores

- last_5_total_away_score: mean of away team's last 5 scores

**Notes:**

- Requires chronological ordering

- For first games, uses available history (fewer than 5)

- Captures recent form

**Features created:**

- ~30 pairs of last_5_\* features (e.g., last_5_total_home_epa, last_5_home_rushing_yards)

---

## **3\. add_prev_feature()**

**Location:** backend/app/pipeline/[feature.py](http://feature.py) (lines 97-162)

**Purpose:** Creates lag features: the most recent previous game value for each team.

**Parameters:**

- df (pd.DataFrame): Input DataFrame (must be chronologically sorted)

- home_feature (str): Home team feature column name

- away_feature (str): Away team feature column name

**Returns:**

- pd.DataFrame: DataFrame with prev_{home_feature} and prev_{away_feature} columns

**How it works:**

1.  Maintains the most recent value per team: teams\[team_name\] = most_recent_value

1.  For each row:

- Retrieves the stored previous value for home team

- Retrieves the stored previous value for away team

- Updates stored values with current game values

1.  Handles missing values:

- First game for a team: np.nan

- Fills with mean of the feature: df\[prev_col\].fillna(np.mean(df\[feature\]))

1.  Creates columns:

- prev_{home_feature}: previous value for home team

- prev_{away_feature}: previous value for away team

**Example:**

If home_feature = "total_home_score":

- prev_total_home_score: home team's score in their most recent previous game

**Difference from add_last5_stat():**

- add_last5_stat(): mean of last 5 games (rolling average)

- add_prev_feature(): value from the most recent previous game (lag feature)

**Features created:**

- ~33 pairs of prev_\* features (including Glicko ratings)

---

## **4\. add_last5_h2h_win_ratios()**

**Location:** backend/app/pipeline/[feature.py](http://feature.py) (lines 167-262)

**Purpose:** Computes head-to-head win ratios for the last N games between the same two teams.

**Parameters:**

- df (pd.DataFrame): Input DataFrame

- date_col (str, optional): Column to sort chronologically (default: None, uses index)

- n (int): Number of recent H2H games to consider (default: 5)

**Returns:**

- pd.DataFrame: DataFrame with h2h_home_win_ratio and h2h_away_win_ratio columns

**How it works:**

1.  Creates matchup key:

- matchup = tuple(sorted((home_team, away_team))) (order-independent)

1.  Determines winner:

- "home_team" if home wins

- "away_team" if away wins

- "DRAW" if tie

1.  Sorts by date (or index)

1.  Groups by matchup and computes ratios:

- For each game, looks at last N H2H games (excluding current)

- Excludes draws from denominator

- Counts wins for home and away

- Computes ratios: home_wins / total_non_draw_games

1.  Creates columns:

- h2h_home_win_ratio: fraction of last N H2H games won by home team

- h2h_away_win_ratio: fraction of last N H2H games won by away team

**Example:**

If teams played 5 times before:

- Home won 3, Away won 2, 0 draws

- h2h_home_win_ratio = 3/5 = 0.6

- h2h_away_win_ratio = 2/5 = 0.4

**Edge cases:**

- Fewer than N games: uses available games

- No prior non-draw games: ratios = 0.0

- First meeting: ratios = 0.0

**Notes:**

- Captures matchup-specific history

- Draws excluded from denominator

- Order-independent matchup key

---

## **5\. Glicko2 rating system**

**Location:** backend/app/pipeline/[glicko.py](http://glicko.py)

### **5.1. Glicko2Player class**

**Purpose:** Represents a team's Glicko2 rating state.

**Attributes:**

- mu: Rating on Glicko-2 scale (converted from standard rating)

- phi: Rating deviation (RD) on Glicko-2 scale

- sigma: Volatility

**Initialization:**

- Default: rating=1500, rd=350, vol=0.06

- Converts to Glicko-2 scale: mu = (rating - 1500) / 173.7178

**Methods:**

- get_rating(): Returns rating on standard scale (1500-based)

- get_rd(): Returns RD on standard scale

- get_vol(): Returns volatility

### **5.2. Glicko2 class**

**Purpose:** Manages Glicko2 rating updates.

**Initialization:**

- tau (float): System constant (default: 0.5)

**Key methods:**

#### ensure_player(name: str)

- Ensures a player/team exists in the system

- Creates new player with default ratings if missing

#### \_g(phi: float)

- Glicko2 function: 1 / sqrt(1 + 3 \* phi² / π²)

- Used in expected score calculation

#### _expected_score(mu, mu_j, phi_j)

- Expected score against opponent

- Formula: 1 / (1 + exp(-g(phi_j) \* (mu - mu_j)))

#### _update_sigma(player, delta, v)

- Updates volatility using iterative method

- Implements Glicko2 paper Step 5 (volatility update)

#### update_ratings(player_name, opponents, scores)

- Updates a player's rating after games

- Steps:

1.  Compute v (variance of performance)

1.  Compute delta (improvement over expected)

1.  Update volatility (sigma)

1.  Update RD (phi)

1.  Update rating (mu)

### **5.3. add_glicko_features()**

**Location:** backend/app/pipeline/[glicko.py](http://glicko.py) (lines 125-159)

**Purpose:** Adds Glicko2 rating features to the DataFrame.

**Parameters:**

- df (pd.DataFrame): Input DataFrame (must be chronologically sorted)

- home_col (str): Home team column (default: "home_team")

- away_col (str): Away team column (default: "away_team")

- home_score_col (str): Home score column (default: "total_home_score")

- away_score_col (str): Away score column (default: "total_away_score")

**Returns:**

- pd.DataFrame: DataFrame with 6 new Glicko columns

**How it works:**

1.  Initializes Glicko2 system

1.  For each game (chronologically):

- Ensures both teams exist in the system

- Converts scores to Glicko scores:

- 1.0 for win, 0.0 for loss, 0.5 for tie

- Records ratings before the match:

- home_team_glicko_rating

- home_team_rd

- home_team_vol

- away_team_glicko_rating

- away_team_rd

- away_team_vol

- Updates ratings after the match

1.  Concatenates rating columns to the DataFrame

**Features created:**

- home_team_glicko_rating: Home team strength rating

- home_team_rd: Home team rating deviation (uncertainty)

- home_team_vol: Home team volatility

- away_team_glicko_rating: Away team strength rating

- away_team_rd: Away team rating deviation

- away_team_vol: Away team volatility

**Notes:**

- Ratings recorded before the match (no leakage)

- Requires chronological ordering

- Ratings update after each game

- Higher rating = stronger team

- Lower RD = more confidence

- Volatility measures rating change rate

---

## **6\. feature_engineering() (main orchestrator)**

**Location:** backend/app/pipeline/schedule_[scripts.py](http://scripts.py) (lines 200-306)

**Purpose:** Orchestrates the feature engineering pipeline.

**Parameters:**

- df (pd.DataFrame): Cleaned DataFrame from data_cleaning()

**Returns:**

- pd.DataFrame: DataFrame with all engineered features

**Pipeline steps:**

### **Step 1: Add match result labels**

**df** **\=** **add_match_result****(****df****)**

- Creates match_result column (0, 1, or 2)

### **Step 2: Remove draws**

**df** **\=** **df****\[~(****df****\[****"match_result"****\]** **\==** **2****)\]**

- Removes ties for binary classification

### **Step 3: Add last 5 games statistics**

- Defines ~30 feature pairs (home/away)

- For each pair, calls add_last5_stat()

- Creates ~60 last_5_\* features

**Features processed:**

- Scoring: total_home_score, total_away_score

- EPA: total_home_epa, total_away_epa, total_home_rush_epa, total_home_pass_epa

- Downs: home_first_down_rush, home_third_down_converted, etc.

- Turnovers: home_interception, home_fumble_lost, etc.

- Offense: home_rush_attempt, home_pass_attempt, home_pass_touchdown, etc.

- Yards: home_rushing_yards, home_passing_yards, etc.

- Special teams: home_punt_attempt, home_kickoff_attempt, etc.

### **Step 4: Add Glicko2 rating features**

**df** **\=** **add_glicko_features****(****df****)**

- Adds 6 Glicko features (rating, RD, volatility for home and away)

### **Step 5: Add previous game features**

- Defines ~33 feature pairs (including Glicko features)

- For each pair, calls add_prev_feature()

- Creates ~66 prev_\* features

**Features processed:**

- Same as Step 3, plus:

- prev_home_team_glicko_rating

- prev_home_team_rd

- prev_home_team_vol

### **Step 6: Add head-to-head win ratios**

**df** **\=** **add_last5_h2h_win_ratios****(****df****)**

- Creates 2 H2H features:

- h2h_home_win_ratio

- h2h_away_win_ratio

---

## **Summary of feature engineering workflow**

Cleaned Match-Level DataFrame

    ↓

\[add_match_result\]

    → Creates match_result column (0, 1, 2)

    ↓

\[Remove draws\]

    → Filters out match_result == 2

    ↓

\[add_last5_stat\] × ~30 feature pairs

    → Creates ~60 last_5_\* rolling average features

    ↓

\[add_glicko_features\]

    → Creates 6 Glicko2 rating features

    ↓

\[add_prev_feature\] × ~33 feature pairs

    → Creates ~66 prev_\* lag features

    ↓

\[add_last5_h2h_win_ratios\]

    → Creates 2 H2H win ratio features

    ↓

Feature-Engineered DataFrame

    (~134 new features + original cleaned features)

---

## **Feature categories summary**

| Category | Function | Features Created | Purpose |
| --- | --- | --- | --- |
| **Target Variable** | add_match_result() | 1 (match_result) | Binary classification label |
| **Rolling Statistics** | add_last5_stat() | ~60 (last_5_\*) | Recent team form (5-game average) |
| **Lag Features** | add_prev_feature() | ~66 (prev_\*) | Most recent previous game value |
| **Team Strength** | add_glicko_features() | 6 (Glicko ratings) | Dynamic team strength ratings |
| **Matchup History** | add_last5_h2h_win_ratios() | 2 (H2H ratios) | Head-to-head performance |

**Total engineered features:** ~135 new features