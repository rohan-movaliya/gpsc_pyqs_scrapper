# Data Cleaning

### **Overview**

The cleaning pipeline converts play-by-play data into match-level features. It aggregates statistics, handles categorical and numerical features, filters end-of-game records, and normalizes yard-based features.

---

## **1\. remove_columns()**

**Location:** backend/app/pipeline/[clean.py](http://clean.py) (lines 9-35)

**Purpose:** Removes specified columns from a DataFrame.

**Parameters:**

- df (pd.DataFrame): Input DataFrame

- column_list (List\[str\]): Columns to remove

**Returns:**

- pd.DataFrame: DataFrame with specified columns removed

**How it works:**

1.  Uses df.drop(columns=column_list)

1.  Returns a new DataFrame (does not modify in place)

**Notes:**

- Raises KeyError if a column doesn't exist

- Returns a copy; original is unchanged

**Usage in pipeline:**

- Removes redundant play-level columns

- Removes aggregated categorical columns after use

- Removes non-predictive columns (e.g., play_id, season, week)

---

## **2\. aggregate_categorical_counts()**

**Location:** backend/app/pipeline/[clean.py](http://clean.py) (lines 38-94)

**Purpose:** Aggregates categorical features as counts per team per game, preserving the full play-by-play DataFrame with counts only in the last row of each game.

**Parameters:**

- df (pd.DataFrame): Play-by-play DataFrame

- cat_cols (List\[str\]): Categorical columns to aggregate (e.g., \["field_goal_result", "extra_point_result"\])

- game_id_col (str): Game identifier column (default: "game_id")

- posteam_col (str): Possession team column (default: "posteam")

- home_team_col (str): Home team column (default: "home_team")

- away_team_col (str): Away team column (default: "away_team")

- time_col (str): Time remaining column (default: "game_seconds_remaining")

**Returns:**

- pd.DataFrame: DataFrame with new count columns (e.g., home_field_goal_result_made, away_field_goal_result_made)

**How it works:**

1.  For each categorical column:

- Groups by game_id and posteam

- Counts occurrences of each category value

- Unstacks to create separate columns per category

- Renames columns with the original column name as prefix

1.  Merges home team counts:

- Prefixes with "home_"

- Merges on game_id and home_team

1.  Merges away team counts:

- Prefixes with "away_"

- Merges on game_id and away_team

1.  Masks non-final rows:

- Sets aggregated columns to NaN for all rows except the last play (game_seconds_remaining == 0)

**Example output columns:**

- home_field_goal_result_made

- home_field_goal_result_missed

- home_field_goal_result_blocked

- away_field_goal_result_made

- away_extra_point_result_good

- away_extra_point_result_failed

**Notes:**

- Preserves full play-by-play structure

- Counts appear only in the final row of each game

- Uses [pd.NA](http://pd.NA) for non-final rows

---

## **3\. aggregate_match_features_with_nulls()**

**Location:** backend/app/pipeline/[clean.py](http://clean.py) (lines 97-164)

**Purpose:** Aggregates numerical play-by-play statistics into match-level features for home and away teams, preserving the full DataFrame with aggregated values only in the last row of each game.

**Parameters:**

- df (pd.DataFrame): Play-by-play DataFrame

- stat_cols (List\[str\]): Numerical columns to aggregate (e.g., \["first_down_rush", "sack", "rushing_yards"\])

- game_id_col (str): Game identifier (default: "game_id")

- home_team_col (str): Home team column (default: "home_team")

- away_team_col (str): Away team column (default: "away_team")

- posteam_col (str): Possession team column (default: "posteam")

- last_play_col (str): Time remaining column (default: "game_seconds_remaining")

**Returns:**

- pd.DataFrame: DataFrame with new aggregated columns (e.g., home_first_down_rush, away_sack)

**How it works:**

1.  Aggregates by game and team:

- Groups by game_id and posteam

- Sums each stat column

1.  Merges home team stats:

- Prefixes with "home_"

- Merges on game_id and home_team

1.  Merges away team stats:

- Prefixes with "away_"

- Merges on game_id and away_team

1.  Drops duplicate merge keys

1.  Masks non-final rows:

- Sets aggregated columns to NaN where game_seconds_remaining != 0

**Example aggregated features:**

- home_first_down_rush, away_first_down_rush

- home_sack, away_sack

- home_rushing_yards, away_rushing_yards

- home_pass_touchdown, away_pass_touchdown

**Notes:**

- Uses sum aggregation

- Preserves play-by-play structure

- Aggregated values only in the final row of each game

---

## **4\. aggregate_positive_negative()**

**Location:** backend/app/pipeline/[clean.py](http://clean.py) (lines 168-234)

**Purpose:** Separates numerical features into positive and negative components, then aggregates them separately per team per game.

**Parameters:**

- df (pd.DataFrame): Play-by-play DataFrame

- num_cols (List\[str\]): Numerical columns that can be positive or negative (e.g., \["return_yards", "yards_after_catch"\])

- game_id_col (str): Game identifier (default: "game_id")

- posteam_col (str): Possession team column (default: "posteam")

- home_team_col (str): Home team column (default: "home_team")

- away_team_col (str): Away team column (default: "away_team")

- time_col (str): Time remaining column (default: "game_seconds_remaining")

**Returns:**

- pd.DataFrame: DataFrame with positive/negative aggregated columns

**How it works:**

1.  For each numerical column:

- Creates {col}\_positive: values > 0, else 0

- Creates {col}\_negative: values < 0, else 0

1.  For each sign (positive, negative):

- Groups by game_id and posteam

- Sums the signed column

- Merges home team aggregates (prefix "home_")

- Merges away team aggregates (prefix "away_")

1.  Masks non-final rows:

- Sets aggregated columns to [pd.NA](http://pd.NA) except where game_seconds_remaining == 0

**Example output columns:**

- home_return_yards_positive, away_return_yards_positive

- home_return_yards_negative, away_return_yards_negative

- home_yards_after_catch_positive, away_yards_after_catch_positive

- home_yards_after_catch_negative, away_yards_after_catch_negative

**Why this is needed:**

- Some stats can be positive or negative (e.g., return yards, YAC)

- Separating them captures different aspects of performance

- Positive values indicate favorable outcomes; negative values indicate penalties or losses

---

## **5\. data_cleaning() (main orchestrator)**

**Location:** backend/app/pipeline/schedule_[scripts.py](http://scripts.py) (lines 99-198)

**Purpose:** Orchestrates the cleaning pipeline: aggregates features, filters end-of-game records, removes redundant columns, and normalizes yard-based features.

**Parameters:**

- df (pd.DataFrame): Raw play-by-play DataFrame from data_load()

**Returns:**

- pd.DataFrame: Cleaned DataFrame with match-level features

**Pipeline steps:**

#### Step 1: Define feature lists

_# Numerical features to aggregate_

features = \["first_down_rush", "first_down_pass", "third_down_converted", 

            "fourth_down_converted", "interception", "fumble_lost", 

            "fumble_forced", "rush_attempt", "pass_attempt", "pass_touchdown", 

            "qb_dropback", "rush_touchdown", "tackled_for_loss", "qb_hit", 

            "punt_attempt", "kickoff_attempt", "kickoff_inside_twenty", 

            "penalty_yards", "rushing_yards", "passing_yards", "receiving_yards", 

            "yards_gained", "sack"\]

**_Categorical features_**

cat_features = \["field_goal_result", "extra_point_result"\]

**_Positive/negative features_**

num_features = \["return_yards", "yards_after_catch"\]

#### Step 2: Aggregate numerical match features

- Calls aggregate_match_features_with_nulls() to create home_\* and away_\* columns

#### Step 3: Aggregate categorical counts

- Calls aggregate_categorical_counts() to create count columns for field goals and extra points

#### Step 4: Aggregate positive/negative features

- Calls aggregate_positive_negative() to separate and aggregate return yards and YAC

#### Step 5: Filter end-of-game records

df = df\[df\["game_seconds_remaining"\] == 0\]

- Keeps only final game states (one row per game)

#### Step 6: Remove redundant columns

Removes:

- Original play-level columns (after aggregation)

- Non-predictive columns: play_id, season, week, season_type, stadium, roof, surface, location, temp, wind

- Score columns: home_score, away_score, posteam_score, defteam_score, score_differential

- Betting lines: spread_line, total_line, vegas_wp

- Advanced EPA/WPA columns (not used in model)

- Time columns: quarter_seconds_remaining, half_seconds_remaining, game_seconds_remaining

#### Step 7: Normalize yard-based features

Normalizes by total yards gained:

- home_penalty_yards / home_yards_gained

- home_rushing_yards / home_yards_gained

- home_passing_yards / home_yards_gained

- home_receiving_yards / home_yards_gained

- home_yards_gained / home_yards_gained (becomes 1.0)

- Same for away team

**Purpose:** Creates scale-invariant percentage features

#### Step 8: Remove categorical count columns

Removes aggregated categorical columns (field goal and extra point results) after they've been used, as they're not needed in the final dataset.