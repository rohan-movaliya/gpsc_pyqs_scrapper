# Data source

## **NFL Data Source Description (For nfl_load / nfl_read)**

We use a **pre-compiled historical NFL dataset** that is stored locally in our project and loaded through two custom functions: `nfl_load()` and `nfl_read()`. This dataset serves as the main training source for our prediction model.

### **1\. What the Dataset Contains**

The dataset includes:

- **Game-level information** (season, week, game ID)
- **Team statistics** (offensive yards, defensive stats, turnovers, efficiency metrics)
- **Match outcomes** (final score, winner, point difference)
- **Team form indicators** (previous week stats, rolling averages)
- **Engineered features** used for prediction (Elo rating, team strength, rank differences, etc.)

---

### **2\. Purpose of nfl_load()**

`nfl_load()` is used to:

- Load the entire dataset into memory
- Perform any required preprocessing
- Add engineered features
- Return a clean, structured DataFrame ready for training

It ensures every run is consistent and reproducible.

---

### **3\. Purpose of nfl_read()**

`nfl_read()`:

- Reads the raw source files (CSV/Parquet)
- Extracts the necessary columns
- Handles merging or formatting
- Acts as the foundational step before `nfl_load()` processes the data

This separation allows flexibility and easier debugging.

---

### **4\. Why This Data Source Is Used**

- It contains **multi-year historical NFL performance data**
- All features are already **validated and consistent**
- It avoids dependency on external live APIs
- It guarantees **stable and repeatable** training results

Reference Link: https://github.com/nflverse/nflfastR-data