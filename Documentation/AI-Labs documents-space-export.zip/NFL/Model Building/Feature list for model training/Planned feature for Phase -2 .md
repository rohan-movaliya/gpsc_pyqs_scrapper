# Planned feature for Phase -2

## 1\. Win Percentage of Team

### Definition

Win percentage represents how often a team has won matches over a defined period.

### Formula

```
Win Percentage = Total Wins / Total Games Played
```

### Variants

- **Season Win %**
- **Last N Games Win %**
- **Home Win %**
- **Away Win %**

### Why It Matters

- Captures **overall team strength**
- Strong baseline indicator of performance consistency

---

## 2\. Team PF and PA (Points For & Points Against)

### Definitions

- **PF (Points For):** Total points scored by the team
- **PA (Points Against):** Total points conceded by the team

### Calculation

```
PF = Sum of points scored in past games
PA = Sum of points conceded in past games
```

### Variants

- Season PF / PA
- Rolling PF / PA (last N games)
- Home PF / PA
- Away PF / PA

### Why It Matters

- PF → Offensive strength
- PA → Defensive weakness/strength
- Fundamental inputs for multiple advanced metrics

---

## 3\. Team Average Score by Season

### Definition

Average number of points a team scores per game in a season.

### Formula

```
Team Average Score = Total PF / Total Games Played
```

### Variants

- Season average
- Last N games average
- Home vs Away average

### Why It Matters

- Measures **scoring consistency**
- Helps normalize performance across seasons

---

## 4\. Net Rating (PF / PA)

### Definition

Net Rating measures scoring efficiency relative to points allowed.

### Formula

```
Net Rating = PF / PA
```

### Interpretation

- **\> 1.0** → Team scores more than it allows (strong team)
- **≈ 1.0** → Balanced team
- **< 1.0** → Weak or struggling team

### Why It Matters

- Compact indicator of **overall team dominance**
- Strong predictor in comparative matchups

---

## 6\. Team Offense Rating

### Definition

A quantitative measure of a team’s ability to score points.

### Possible Implementations

- Points per game
- Expected points added (EPA)
- Offensive efficiency per drive

### Example

```
Offense Rating = Average Points Scored per Game
```

### Why It Matters

- Captures scoring potential
- Useful in **over/under** and margin prediction models

---

## Team Defense Rating

### Definition

A measure of how effectively a team prevents opponents from scoring.

### Possible Implementations

- Points allowed per game
- Defensive EPA
- Yards or scores allowed per drive

### Example

```
Defense Rating = Average Points Allowed per Game
```

### Why It Matters

- Identifies teams that can **control games**
- Crucial for upset and close-game prediction

---

## 7\. Team SOV (Strength of Victory)

### Definition

Strength of Victory measures **how strong the opponents were that the team defeated**.

### Formula

```
SOV = Average Win Percentage of Opponents Defeated
```

### Example

If a team beats opponents with win %:

```arduino
[0.70, 0.65, 0.55] → SOV = 0.63
```

### Why It Matters

- Differentiates **easy wins vs quality wins**
- Improves ranking accuracy beyond raw win percentage

---

## Summary Table

| Feature | What It Measures | Importance |
| --- | --- | --- |
| Win % | Overall success | Baseline strength |
| PF / PA | Scoring vs conceding | Core performance |
| Avg Score | Scoring consistency | Stability |
| Net Rating | Efficiency | Dominance |
| Offense | Scoring power | Match control |
| Defense | Resistance | Upset prevention |
| SOV | Quality of wins | Schedule strength |