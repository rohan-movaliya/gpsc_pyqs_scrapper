# Planned features for model building

## **1\. Elo Ratings**

**Objective:**  
Introduce a dynamic, match-to-match rating system that updates based on game outcomes and opponent strength.

Description:  
Elo Ratings provide a numerical representation of a team’s overall power. After each game, team ratings are updated depending on:

- Win/loss outcome
- Pre-game expected probability
- Margin of victory (optional extension)
- Home-field advantage

**Benefits:**

- Captures true team strength better than raw win/loss
- Accounts for opponent quality
- Improves predictive stability across the season

**Usage in Model:**

- Pre-game Elo rating for each team
- Difference in Elo between home and away teams
- Recent Elo momentum (e.g., last 3 games)  
    

---

## **2\. Power Ratings**

**Objective:**  
Create a comprehensive team strength metric using multiple performance factors.

**Description:**  
**Power Ratings aggregate various team performance indicators such as:**

- Offensive efficiency
- Defensive efficiency
- Turnover differential
- Red-zone performance
- Strength of schedule  
    <br/>

This rating represents how well a team is performing beyond win/loss outcomes.

**Benefits:**

- More holistic representation of team performance
- Captures underlying quality not visible in raw stats
- Complements Elo Ratings with a multi-metric perspective  
    <br/>

**Usage in Model:**

- Pre-game Power Score (offense, defense, overall)
- Power differential between teams

---

## **3\. Rolling Features**

**Objective:**  
Introduce time-aware features that represent recent team form and trends.

**Description:**  
**Rolling features are calculated using a moving window (e.g., last 3, 5, or 7 games). Examples include:**

- Rolling average of points scored
- Rolling average of points conceded
- Rolling offensive yards
- Rolling defensive stops
- Rolling turnover stats  
    <br/>

**Benefits:**

- Captures momentum and slumps
- Reduces noise from single-game spikes
- Better representation of short-term team performance

**Usage in Model:**

- Rolling mean, rolling sum, rolling percentage features
- Rolling win streak indicators
- Rolling scoring differential  
    

---

## **4\. Poisson Goal Models (Score Prediction Modeling)**

**Objective:**  
Model expected points scored and conceded using statistical goal-scoring distributions.

**Description:**  
**Poisson models assume that scoring events (e.g., touchdowns/field goals) follow a Poisson distribution.**  
**For NFL, this method helps estimate:**

- Expected points scored by team
- Expected points allowed
- Offensive strength parameter
- Defensive strength parameter  
    

**Benefits:**

- Helps predict likelihood of close games, high-scoring games, etc.
- Adds probabilistic structure to scoring patterns
- Can be used as input to win probability prediction

**Usage in Model:**

- Expected offensive score
- Expected defensive score
- Score differential predicted from Poisson  
    

---

## **5\. Seasonal Features**

**Objective:**  
**Capture season-level effects and distinguish between team performance across different stages of the season.**

**Description:**  
**Seasonal features include:**

- Week number
- Early-season vs mid-season vs late-season performance
- Bye-week effects
- Seasonal trends in scoring (early weeks have different pace than late weeks)

**Benefits:**

- Incorporates context that raw stats cannot capture
- Helps adjust predictions for early instability or late-season pressure
- Accounts for variables like fatigue, rest, and time trends

**Usage in Model:**

- Week number encoded (numeric or cyclical encoding)
- Post-bye performance indicator
- Seasonal momentum variables

---

# **Final Deliverable Structure After Implementation**

**Once these features are integrated, the dataset will include:**

### **Team Strength Metrics**

- Elo rating
- Power rating
- Opponent-adjusted stats  
    

### **Form & Momentum Indicators**

- Rolling averages
- Rolling streaks
- Rolling efficiencies

### **Scoring Models**

- Expected points (offense/defense)
- Poisson-based scoring probabilities

### **Seasonal Context**

- Week-specific trends
- Bye-week indicators