# Model Training

### **Overview**

The model training step trains a Random Forest classifier to predict NFL game outcomes (home win vs away win). It uses preprocessed, feature-engineered data with class imbalance handling.

---

## **7\. Model training**

### **7.1. model_train() function**

**Location:** backend/app/pipeline/schedule_[scripts.py](http://scripts.py) (lines 435-490)

**Purpose:** Trains a Random Forest classifier on preprocessed NFL data for binary classification.

**Parameters:**

- x_resampled (pd.DataFrame): Resampled and scaled training feature matrix from data_preprocessing()

- y_resampled (pd.DataFrame): Resampled training target vector (match_result: 0 or 1)

- x_test (pd.DataFrame, optional): Test feature matrix (for logging, not used in training)

- y_test (pd.Series, optional): Test target vector (for logging, not used in training)

**Returns:**

- RandomForestClassifier: Trained model ready for predictions

**Algorithm:** Random Forest (scikit-learn RandomForestClassifier)

---

### **7.2. Model hyperparameters**

The model uses the following configuration:

| Hyperparameter | Value | Description |
| --- | --- | --- |
| **n_estimators** | 800 | Number of decision trees in the forest |
| **max_depth** | 17  | Maximum depth of each tree (prevents overfitting) |
| **min_samples_split** | 10  | Minimum samples required to split an internal node |
| **min_samples_leaf** | 2   | Minimum samples required at a leaf node |
| **max_features** | 'sqrt' | Number of features to consider for best split (√n_features) |
| **class_weight** | 'balanced_subsample' | Automatically adjust class weights for each bootstrap sample |
| **bootstrap** | False | Use the whole dataset for each tree (no bootstrapping) |
| **random_state** | 42  | Random seed for reproducibility |
| **n_jobs** | \-1 | Use all available CPU cores for parallel training |
| **verbose** | 1   | Show training progress |

**Hyperparameter rationale:**

- n_estimators=800: Large ensemble for stability

- max_depth=17: Limits depth to reduce overfitting

- min_samples_split=10 and min_samples_leaf=2: Prevents overfitting on small samples

- max_features='sqrt': Reduces correlation between trees

- class_weight='balanced_subsample': Handles class imbalance per tree

- bootstrap=False: Uses full dataset per tree (more data per tree)

---

### **7.3. Training process**

#### Step 1: Extract target variable

y_train \= _extract_target_series(y_resampled)

- Converts y_resampled (DataFrame) to a Series if needed

#### Step 2: Initialize model

model \= RandomForestClassifier(

    _n_estimators_\=800,

    _max_depth_\=17,

    

#### Step 3: Train model

[model.fit](http://model.fit)(x_resampled, y_train)

- Fits 800 trees in parallel

- Each tree uses a random subset of features (sqrt of total)

- Class weights are balanced per bootstrap sample

- Progress is logged (verbose=1)

#### Step 4: Return trained model

- Returns the trained RandomForestClassifier for saving and inference

---

### **7.4. Training data preparation**

The training data goes through:

1.  Feature engineering (~135 features)

1.  Label encoding (categorical features)

1.  Train/test split (80/20, stratified)

1.  Standard scaling (fit on train, transform both)

1.  SMOTE resampling (only on training data)

**Training data characteristics:**

- Features: ~135 engineered features

- Target: Binary (match_result: 0 = away win, 1 = home win)

- Class imbalance: Handled with SMOTE

- Scaling: StandardScaler (mean=0, std=1)

- Sample size: Varies by dataset (after SMOTE, typically larger than original)

---

### **7.5. Model saving**

**Location:** backend/app/pipeline/[schedule.py](http://schedule.py) (lines 352-370)

**Function:** _train_and_save_model()

**Process:**

1.  Captures training logs:

- Redirects stdout/stderr to logger

- Captures CatBoost-style output (for compatibility)

1.  Trains model:   model \= model_train(X_train, y_train, _x_test_\=X_test, _y_test_\=y_test_series)

1.  Saves model:   _with_ open(MODEL_FILE, 'wb') _as_ f:       pickle.dump(model, f)

- Saved to: backend/models/cat_model.pkl (legacy naming, but contains Random Forest)

**Saved artifacts:**

- Trained model: backend/models/cat_model.pkl

- Scaler: backend/models/scaler.pkl

- Label encoders:

- backend/models/coach_encoder.pkl

- backend/models/team_encoder.pkl

- backend/models/ground_encoder.pkl

---

### **7.6. Training workflow in pipeline**

**Step 5: Model Training** (step5_model_train())

**Location:** backend/app/pipeline/[schedule.py](http://schedule.py) (lines 295-303)

**Process:**

1.  Loads preprocessed data:

- Uses in-memory cache from Step 4 if available

- Otherwise loads from CSV files

1.  Prepares datasets:   X_train, y_train, X_test, y_test_series \= _prepare_step5_datasets()

1.  Trains and saves model:   _train_and_save_model(X_train, y_train, X_test, y_test_series)

1.  Schedules Step 7:

- Schedules match results update 5 minutes after training completes

**Data flow:**

Step 4 Output (Preprocessed Data)

    ↓

\[Load from cache or disk\]

    ↓

\[Extract train/test sets\]

    ↓

\[model_train()\]

    → Initialize RandomForestClassifier

    → Fit on x_resampled, y_resampled

    ↓

\[Save model to pickle\]

    → backend/models/cat_model.pkl

    ↓

\[Schedule Step 7\]

    → Update match results (5 minutes later)

---

### **7.7. Model characteristics**

**Algorithm:** Random Forest (ensemble of decision trees)

**Advantages:**

- Handles non-linear relationships

- Feature importance available

- Robust to outliers

- No feature scaling required (but used for consistency)

- Parallel training (n_jobs=-1)

**Training time:**

- Depends on dataset size and hardware

- Parallelized across all CPU cores

- Progress logged during training

**Model output:**

- Prediction probabilities: model.predict_proba() returns \[away_prob, home_prob\]

- Binary predictions: model.predict() returns 0 or 1

---

### **7.8. Helper functions**

#### _extract_target_series()

**Location:** backend/app/pipeline/schedule_[scripts.py](http://scripts.py) (lines 491-497)

**Purpose:** Normalizes target variable to a pandas Series.

**Handles:**

- DataFrame → extracts first column

- Series → returns as-is

- Empty containers → returns squeezed result

#### _prepare_eval_set()

**Location:** backend/app/pipeline/schedule_[scripts.py](http://scripts.py) (lines 500-515)

**Purpose:** Prepares evaluation set (kept for API compatibility).

**Note:** Random Forest does not use eval_set or early stopping (unlike CatBoost). This function is kept for compatibility but the return value is not used during training.

---

### **7.9. Model evaluation**

**Current implementation:**

- No explicit evaluation metrics are calculated during training

- Test set is available but not used for evaluation in the training function

- Model performance can be evaluated separately using the test set

**Potential metrics to calculate:**

- Accuracy

- Precision

- Recall

- F1-score

- ROC-AUC

- Confusion matrix

**Note:** The test set (x_test, y_test) is preserved and can be used for evaluation, but this is not done automatically in the current pipeline.

---

### **7.10. Design decisions**

1.  Random Forest over CatBoost:

- No external dependencies beyond scikit-learn

- Good performance for tabular data

- Feature importance available

- Fast parallel training

1.  Hyperparameter choices:

- n_estimators=800: Large ensemble for stability

- max_depth=17: Prevents overfitting

- bootstrap=False: Uses full dataset per tree

- class_weight='balanced_subsample': Handles imbalance

1.  No early stopping:

- Random Forest doesn't support early stopping

- Fixed number of trees (n_estimators=800)

1.  Model persistence:

- Saved as pickle for fast loading

- All preprocessing artifacts saved separately

1.  Training logs:

- Captured and redirected to logger

- Progress shown with verbose=1