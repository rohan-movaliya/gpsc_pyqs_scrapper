# Feature list for model training

### **1\. Categorical features (label encoded)**

- home_team — Home team name (encoded)

- away_team — Away team name (encoded)

- home_coach — Home team coach (encoded)

- away_coach — Away team coach (encoded)

- game_stadium — Stadium name (encoded)

### **2\. Last 5 games statistics (rolling window features)**

For each stat, both last_5_{home_feature} and last_5_{away_feature} are created:

**Scoring & EPA:**

- last_5_total_home_score / last_5_total_away_score

- last_5_total_home_epa / last_5_total_away_epa

- last_5_total_home_rush_epa / last_5_total_away_rush_epa

- last_5_total_home_pass_epa / last_5_total_away_pass_epa

**Downs & conversions:**

- last_5_home_first_down_rush / last_5_away_first_down_rush

- last_5_home_first_down_pass / last_5_away_first_down_pass

- last_5_home_third_down_converted / last_5_away_third_down_converted

- last_5_home_fourth_down_converted / last_5_away_fourth_down_converted

**Turnovers & defense:**

- last_5_home_interception / last_5_away_interception

- last_5_home_fumble_lost / last_5_away_fumble_lost

- last_5_home_fumble_forced / last_5_away_fumble_forced

- last_5_home_sack / last_5_away_sack

- last_5_home_tackled_for_loss / last_5_away_tackled_for_loss

- last_5_home_qb_hit / last_5_away_qb_hit

**Offensive plays:**

- last_5_home_rush_attempt / last_5_away_rush_attempt

- last_5_home_pass_attempt / last_5_away_pass_attempt

- last_5_home_qb_dropback / last_5_away_qb_dropback

**Touchdowns:**

- last_5_home_pass_touchdown / last_5_away_pass_touchdown

- last_5_home_rush_touchdown / last_5_away_rush_touchdown

**Special teams:**

- last_5_home_punt_attempt / last_5_away_punt_attempt

- last_5_home_kickoff_attempt / last_5_away_kickoff_attempt

- last_5_home_kickoff_inside_twenty / last_5_away_kickoff_inside_twenty

**Yards (normalized by total yards gained):**

- last_5_home_penalty_yards / last_5_away_penalty_yards

- last_5_home_rushing_yards / last_5_away_rushing_yards

- last_5_home_passing_yards / last_5_away_passing_yards

- last_5_home_receiving_yards / last_5_away_receiving_yards

- last_5_home_yards_gained / last_5_away_yards_gained

**Return & YAC yards:**

- last_5_home_return_yards_positive / last_5_away_return_yards_positive

- last_5_home_return_yards_negative / last_5_away_return_yards_negative

- last_5_home_yards_after_catch_positive / last_5_away_yards_after_catch_positive

- last_5_home_yards_after_catch_negative / last_5_away_yards_after_catch_negative

### **3\. Previous game features (most recent game)**

For each stat, both prev_{home_feature} and prev_{away_feature} are created:

**Same list as "Last 5 games" above, plus:**

- prev_home_team_glicko_rating / prev_away_team_glicko_rating

- prev_home_team_rd / prev_away_team_rd

- prev_home_team_vol / prev_away_team_vol

### **4\. Glicko2 rating system features**

- home_team_glicko_rating — Home team strength rating

- away_team_glicko_rating — Away team strength rating

- home_team_rd — Home team rating deviation

- away_team_rd — Away team rating deviation

- home_team_vol — Home team volatility

- away_team_vol — Away team volatility

### **5\. Head-to-head (H2H) features**

- h2h_home_win_ratio — Home team win ratio in last 5 H2H games

- h2h_away_win_ratio — Away team win ratio in last 5 H2H games

### **6\. Normalized yard features**

Yard-based features normalized by total yards gained (if applicable):

- Normalized versions of rushing, passing, receiving, and penalty yards

---