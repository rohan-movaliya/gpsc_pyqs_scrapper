# Git URL

  
**Note:**   
This document contains reference links to the official source code for repositories for the NFL Sports outcome prediction. These repositories include both frontend and backend implementations that collectively power the complete system, enabling seamless predictions, match datat and AI model integration. 

**Repository Links:**   
**Frontend Repository (React/Next.js):**  

https://gitlab.inexture.com/ai.inexture/nfl-sport-prediction/-/tree/dev/frontend?ref_type=heads

**Backend Repository (Fast API):** 

https://gitlab.inexture.com/ai.inexture/nfl-sport-prediction/-/tree/dev/backend?ref_type=heads