# AI-Powered Mock Interview System

# **1\. Project Overview**

The AI-Powered Mock Interview System is a web-based application designed to simulate realistic technical interviews. It leverages Large Language Models (LLMs) to analyze a candidate's resume, generate tailored questions, and provide comprehensive feedback. The system also supports **Voice-Based Interview Mode**, enabling real-time speech interaction and speech quality analysis to simulate a real-world interview experience.

---

# **2\. Objectives**

- To provide a realistic and adaptive technical interview experience.
- To assess candidates based on their resume (Skills, Projects, Experience) and target Job Role.
- To offer actionable feedback and scoring.
- To simulate real interview environments using **voice-based interaction**.
- To evaluate not only technical knowledge but also communication and speaking confidence.

# **3\. Technology Stack**

## **3.1 Frontend**

Core:

- React.js (v18)
- TypeScript (v5)
- Vite (v5)

UI/Styling:

- Tailwind CSS (v3)
- Shadcn/UI
- Lucide React (Icons)

State & Routing:

- TanStack Query (v5)
- React Router DOM (v6)

Forms:

- React Hook Form (v7)
- Zod

Voice Integration:

- Web Audio API (Microphone access)
- MediaRecorder API
- Audio Playback support

## **3.2 Backend**

Framework:

- FastAPI (High-performance Python web framework)

Language:

- Python 3.10+

Voice Processing:

- Whisper / Faster-Whisper (Speech-to-Text)
- Edge TTS / Coqui TTS / ElevenLabs (Text-to-Speech)

## **3.3 AI Service**

Orchestration:

- LangChain (Agent & Chain management)

LLM Providers:

- Groq (Llama 3.3-70b) for high-speed inference
- Google Gemini (Gemini 2.0 Flash) as backup

Vector Database:

- ChromaDB (Local persistence for resume context)  
    <br/>

Embeddings:

- HuggingFace (sentence-transformers/all-MiniLM-L6-v2)  
    <br/>

Parsing:

- PyPDF2 (PDFs)
- python-docx (DOCX)

# **4\. Functional Requirements**

## **4.1 User Interface (UI)**

### **Resume Upload**

- Users must upload their resume.
- Supported Formats: PDF (.pdf), Word (.docx)
- Max size: 200MB (logical backend limit may apply)

### **User Details Inputs**

- Years of Experience (Range: 0 – 20)
- Job Role (Max 30 characters)

### **Interview Mode Selection**

User must be able to select:

- Text-Based Interview Mode
- Voice-Based Interview Mode

### **Control Buttons**

- Start Interview
- Submit Answer (Text Mode)
- Record Answer (Voice Mode)
- Stop Recording
- End Interview

## **4.2 Resume Parsing & Processing**

### **Text Extraction**

System must extract raw text from PDF or DOCX.

### **Structured Data Extraction**

An AI agent parses text into structured JSON:

Required Fields:

- Projects
- Skills
- Work Experience
- Education
- Certifications

### **Robustness**

Fallback mechanism:

- Regex-based extraction
- String pattern matching
- JSON validation & retry logic

## **4.3 Interview Agent Logic**

### **Initialization**

Interview starts with relevant opening question.

### **Context Awareness**

Questions vary by experience level:

- 0–2 Years → Foundational concepts
- 2–5 Years → Practical implementation
- 5+ Years → System design, architecture

Agent focuses strictly on selected Job Role.

### **Adaptive Questioning**

- Follow-up questions based on previous answer
- Resume-based contextual questions
- No repetition of questions
- Pattern: 2 follow-ups → 1 new topic

### **Topic Switching**

If user responds with:

- “I don’t know”
- “Skip”

Agent switches topic from resume.

## **4.4 Voice Interview Mode**

### **Speech-to-Text**

- Record user voice via microphone
- Convert audio to text using Whisper
- Send transcription to Interview Agent

### **Text-to-Speech**

- AI interviewer speaks generated questions
- Audio response automatically played in frontend
- Multiple voice styles supported (future)

### **Speech Analytics**

System must analyze:

- Words Per Minute (WPM)
- Filler words detection (um, uh, like, basically)
- Pause frequency
- Answer duration
- Speech clarity estimation

### **Voice-Based Controls**

- Record
- Stop Recording
- Playback user answer

## **4.5 Evaluation & Feedback**

### **Trigger**

Evaluation generated when user clicks “End Interview”.

### **Analysis**

System analyzes:

- Entire chat history
- Speech metrics (if voice mode used)

### **Output**

### **Question-by-Question Breakdown**

- Question
- User Answer
- Feedback
- Improvement Suggestions

### **Overall Scoring (Out of 10)**

Technical Metrics:

- Technical Accuracy
- Problem-Solving Approach
- Depth of Knowledge
- Overall Coherence

Communication Metrics:

- Communication Clarity
- Speaking Fluency (Voice Mode)
- Confidence Level (Voice Mode)

### **Cleanup**

- Clear session memory
- Delete ChromaDB data
- Delete temporary audio files
- Reset interview state

# **5\. Non-Functional Requirements**

Performance:

- Real-time question generation
- Fast speech transcription (< 3 seconds target)

Reliability:

- Graceful API fallback (Groq → Gemini)
- Retry mechanism for invalid JSON
- Audio upload failure handling

Security:

- API keys via environment variables
- Temporary storage for audio files
- No permanent storage of user resume unless enabled  
    <br/>

Usability:

- Clear microphone permissions handling
- Loading spinners during transcription
- Visual indicator while recording  
    <br/>