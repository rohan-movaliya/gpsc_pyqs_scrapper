# Require to discuss

- When testing on the local then everything is working fine, but on server the messages are lagging and functionality takes time to execute.