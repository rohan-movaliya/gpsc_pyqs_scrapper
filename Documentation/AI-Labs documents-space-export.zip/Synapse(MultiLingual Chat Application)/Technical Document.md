# Technical Document

## **Technology Stack**

### 🖥️ **Backend Technologies**

| Component | Description |
| --- | --- |
| **Framework** | FastAPI with Uvicorn (ASGI) |
| **Realtime Transport** | WebSockets (FastAPI WebSocket layer) |
| **Cache / Presence / PubSub** | Redis |
| **Database** | SQL Database (configured in `app/config/database_config.py`) |
| **ORM Layer** | SQLAlchemy 2.0 (sync/async hybrid) |
| **TLS / Security** | Custom TLS via `app/config/tls_config.py`, token-based auth |
| **Configuration** | `.env` files via environment variables |

---

### **Artificial Intelligence (Multilingual Layer)**

- Integrated translation & language utilities at the **service layer**
- **Language routing** implemented in `app/api/v1/languages.py`
- **Pluggable translation strategy** for external or on-prem AI models
- Future-ready for providers such as **OpenAI**, **Groq**, or **local NLP pipelines**

---

### **Testing & Configuration**

| Component | Purpose |
| --- | --- |
| **pytest / pytest-asyncio / pytest-cov** | Unit & integration testing |
| **httpx** | API and WebSocket test client |
| **python-dotenv** | Environment management |
| **Structured constants** | `app/lib/constants.py` defines all configuration constants |

---

### **Frontend Technologies (Consumer Expectations)**

- **React + TypeScript** WebSocket client
- Secure token-based handshake with the FastAPI backend

---

### **Data Storage**

| Store | Usage |
| --- | --- |
| **NoSQL Database** | Users, sessions, messages, lobby metadata |
| **Redis** | Presence, session routing, rate limiting, pub/sub fanout |

---

## **Core Features**

---

### **Authentication & Authorization**

- Secure login with token issuance & validation
- JWT-based access tokens with refresh support
- Session scoping for WebSocket connections
- Guarded access for protected rooms/lobbies

---

### **Session & WebSocket Management**

- Centralized management in `app/core/socket_handlers/session_handler.py`
- Connection lifecycle: connect → authenticate → join room → publish/subscribe → disconnect
- Presence tracking and broadcast via Redis
- Token validation middleware for secure connection gating

---

### **Lobby & Room Coordination**

- Create, join, and leave lobbies via `app/services/lobby_service.py`
- Role-aware permissions for **moderators** and **admins**
- Room metadata & participant management
- Automatic cleanup of inactive rooms

---

### **Messaging**

- Persistent store-and-forward pipeline (`app/services/message_service.py`)
- Server-side fanout to room participants
- Delivery acknowledgments & optional retry semantics
- Message validation, sanitization, and translation hooks

---

### **Guest Request Handling**

- Guest and unauthenticated access flows (`app/services/guest_request_service.py`)
- Controlled elevation to authenticated sessions
- Integration with real-time approval workflows

---

### **Email & Notifications**

- Verification and system notification handling (`app/services/email_service.py`)
- SMTP/transactional provider support
- Configurable message templates and triggers

---

### **Multilingual Support**

- API: `app/api/v1/languages.py` for language discovery & preferences
- Middleware hook for translation in the message pipeline
- Automatic language detection & normalization utilities
- Configurable translation engine strategy (AI service agnostic)

---

### **Security & TLS**

- Centralized TLS configuration (`app/config/tls_config.py`)
- Strict **Pydantic v2** validation for all request schemas
- Centralized constants (`app/lib/constants.py`)
- Defensive error handling with structured responses

---

## ⚡ **System Workflow**

1.  Client authenticates via HTTP and receives an access token (or initiates guest flow).
2.  Client opens a WebSocket connection at `/ws` and authenticates.
3.  Server registers presence in Redis and updates room membership.
4.  Client sends messages → backend persists → applies multilingual processing → fans out via Redis pub/sub.
5.  Recipients receive messages instantly with delivery acknowledgments.
6.  Users can update language preferences dynamically.
7.  On disconnect, the server cleans up presence and membership data.

---

## 🔁 **Realtime Processing Flow**

| Layer | Responsibility |
| --- | --- |
| **WebSocket Gateway** | Terminates connections, validates tokens, registers session, routes events |
| **Session Handler** (`app/core/socket_handlers/session_handler.py`) | Manages lifecycle (connect/join/leave/message), integrates with Redis for pub/sub and presence |
| **Messaging Service** (`app/services/message_service.py`) | Validates messages, persists, and fans out via Redis or in-process broker |
| **Lobby Service** (`app/services/lobby_service.py`) | Creates rooms, manages permissions, resolves roles |
| **Auth Service** (`app/services/auth_service.py`) | Token issuance/validation and identity propagation |
| **Language API** (`app/api/v1/languages.py`) | Exposes supported languages and translation hooks |
| **Email Service** (`app/services/email_service.py`) | Sends verification and system notifications |

---

## 🧱 **Key Architectural Highlights**

- 🧩 **Layered Services Architecture:** Clear separation of concerns between API, services, and infrastructure
- ⚙️ **Fully Async-Capable Stack:** WebSockets, Redis, SQLAlchemy async support
- 🧠 **AI-Enhanced Translation Hooks:** Flexible and modular
- 🔒 **Security-First Design:** TLS, JWT, CORS, and validation at every layer
- 📈 **Scalable Presence Architecture:** Redis clusters for horizontal scaling
- 🧰 **Production-Ready Configuration:** Environment-driven setup, health checks, and structured logging