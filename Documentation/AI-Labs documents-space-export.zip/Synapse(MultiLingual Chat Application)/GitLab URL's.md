# GitLab URL's

Frontend URl:-https://gitlab.inexture.com/ai.inexture/frontend/multilingual-chat-application-front-end  
Backend URI:-https://gitlab.inexture.com/ai.inexture/multilingual-chat-application  

Setup guide for the backend and frontend can be founded in the readme of both repositories