# Feature/Redis-sync

# 🚀 Redis Sync Migration Roadmap

> **Goal:** Replace in-memory Socket.IO state with Redis-based coordination to support multi-worker deployments without cross-worker drift.  
> **Scope:** Settings, state manager scaffolding, handler dual-writes, Redis pub/sub subscriber, resilience hardening, tests, deployment updates, and staging validation.  
> **Constraint:** Maintain existing behavior at each phase — no broken API contracts or Socket.IO events.  
> **Each phase ends with a commit on** `feature/redis-sync` **after review.**

---

## ⚙️ Prerequisites

- ✅ Ensure Redis service is reachable locally (`docker-compose up redis`)
- ✅ Activate virtual environment (`source .venv/bin/activate`)
- ✅ Run baseline tests (`pytest tests/core/socket_handlers -q`)
- ✅ Capture baseline socket smoke test notes (connect, message send, leave)

---

## 🧭 Phase-by-Phase Implementation Plan

---

### **Phase 1 — Branch + Config (Safety)**

**Intent:** Add new settings flags for Redis state usage.

**Code Changes**

- Add `USE_REDIS_STATE` toggle and Redis env vars to `settings.py`.

**Testing**

- Run `pytest tests/config -q`
- Launch `uvicorn app.main:app --reload` → ensure no runtime errors

**Manual Validation**

- Check `/health` endpoint → 200 OK
- Verify `.env.example` includes Redis placeholders

**Tasks**

- Add Redis toggle in settings
- Update `.env` template
- Run settings tests

**Regression Safeguard:** Only settings additions; no runtime logic changes.

---

### **Phase 2 — RedisStateManager Scaffold**

**Intent:** Create central Redis manager class mirroring in-memory structures.

**Code Changes**

- New file: `app/core/redis_state_manager.py`

**Testing**

- Run `pytest tests -k "imports and redis" -q`
- Lint: `ruff` / `flake8`

**Manual Validation**

- REPL:
    
    ```python
    from app.core.redis_state_manager import RedisStateManager
    RedisStateManager()
    ```
    
- Ensure no import side effects.

**Tasks**

- Create scaffold
- Import test via REPL
- Add TODOs for future Redis logic

**Regression Safeguard:** Handlers do not use Redis yet.

---

### **Phase 3 — SocketManager Integration (Wrappers)**

**Intent:** Wire Redis manager into SocketManager without changing logic.

**Code Changes**

- Instantiate `RedisStateManager` inside `socket_manager.py`
- Add wrapper delegations

**Testing**

- Run `pytest tests/core/test_socket_manager.py -q`

**Manual Validation**

- Connect via Socket.IO client
- Observe logs for Redis init success
- Ensure no `NotImplementedError` raised

**Tasks**

- Add RedisManager to SocketManager
- Wrapper delegations added
- Test suite passes

**Regression Safeguard:** Existing dicts untouched.

---

### **Phase 4 — Connection Handler Dual-Write**

**Intent:** Dual-write connection data to Redis and memory.

**Code Changes**

- Modify `connection_handler.py` for Redis writes/removals.

**Testing**

- Run `pytest tests/core/socket_handlers/test_connection_handler.py -q`

**Manual Validation**

- Connect → `redis-cli KEYS "connection:*"` shows entry
- Disconnect → key removed
- Reconnect speed unaffected

**Tasks**

- Dual-write Redis logic
- Cleanup on disconnect
- Verify keys manually

✅ **Completed (2025-11-08)**

---

### **Phase 5 — Online Check & Heartbeat**

**Intent:** Use Redis for online status and heartbeat TTL.

**Code Changes**

- Update `_is_user_online` and heartbeat logic.

**Testing**

- Unit: Mock Redis call path
- Manual: TTL check via `ttl user:{id}:online`

**Manual Validation**

- Verify TTL decrements on idle
- Expiry auto-clears user after disconnect

**Tasks**

- Redis-based heartbeat
- TTL write via Redis
- Unit test for call path

✅ **Completed (2025-11-09)**

---

### **Phase 6 — Rejoin Logic (Read from Redis)**

**Intent:** Use Redis for session rejoin after reconnect.

**Code Changes**

- `_rejoin_all_active_sessions` now reads from Redis.

**Testing**

- Unit: mocked Redis data
- Manual: close/reopen browser within TTL → auto rejoin

**Tasks**

- Redis session membership read
- Mongo fallback retained
- Reconnect validation done

✅ **Completed (2025-11-09)**

---

### **Phase 7 — Redis Pub/Sub Scaffolding**

**Intent:** Scaffold subscriber lifecycle (start/stop hooks).

**Code Changes**

- New file: `redis_pubsub.py`
- Lifecycle integration in `main.py`

**Testing**

- Run `pytest tests/test_main.py -q`

**Manual Validation**

- App logs show:
    
    ```
    RedisPubSubSubscriber initialized
    RedisPubSubSubscriber stopped
    ```
    
- Graceful shutdown confirmed.

✅ **Completed (2025-11-09)**

---

### **Phase 8 — Lobby Handler Publish Hook**

**Intent:** Dual-write lobby requests and publish Redis events.

**Code Changes**

- Add Redis publish on lobby persistence.

**Testing**

- Run `pytest tests/core/socket_handlers/test_lobby_handler.py -q`
- `redis-cli monitor` → observe publish event.

✅ **Completed (2025-11-09)**

---

### **Phase 9 — Session Handler Dual-Write**

**Intent:** Mirror session and approval state in Redis.

**Manual Validation**

- Verify Redis `session:{id}:members` and `approved` sets update on join/leave.

✅ **Completed**

---

### **Phase 10 — Message Handler Routing Prep**

**Intent:** Use room-based broadcasting (Redis socket lists).

**Code Changes**

- Introduce `sio.emit(..., room=session_id)` path.

✅ **Completed (2025-11-09)**

---

### **Phase 11 — Notification Persistence (Dual-Write)**

**Intent:** Store notifications in Redis for replay after reconnect.

✅ **Completed (2025-11-09)**

---

### **Phase 12 — Security/Rate-Limiter Adjustments**

**Intent:** Move rate-limit counters to Redis.

✅ **Completed (2025-11-09)**

🕓 **Pending:** Multi-client manual validation once staging has Redis enabled.

---

### **Phase 13 — Remove In-Memory Fallbacks**

**Intent:** Full Redis migration.

**Tasks**

- Remove in-memory dicts
- Full pytest + 2-worker manual test

---

### **Phase 14 — Redis Pub/Sub Implementation**

**Intent:** Implement subscriber loop and message propagation.

**Tasks**

- Complete `redis_pubsub.py` loop
- Add publish hooks across handlers
- Validate cross-worker sync

---

### **Phase 15 — Resilience: Timeouts & Error Handling**

**Intent:** Harden Redis operations and socket emits.

**Tasks**

- Add retry/backoff logic
- Wrap emits with try/except
- Test Redis downtime scenario

---

### **Phase 16 — Tests & Local Integration**

**Intent:** Ensure Redis state coverage and two-worker integration.

**Tasks**

- Add `test_redis_state_manager.py` mocks
- Run full integration suite
- Record test logs

---

### **Phase 17 — Deployment Config & Staging**

**Intent:** Update deployment stack and validate staging.

**Tasks**

- Update docker-compose with Redis vars
- Validate Redis container health
- Conduct staging smoke test

---

### **Phase 18 — Final Validation & Cleanup**

**Intent:** Finalize implementation and documentation.

**Tasks**

- Remove TODOs/logs
- Compile validation report
- Prepare PR summary

---

## 🧪 Testing Strategy Summary

- **Automated:** Targeted `pytest` after each phase; full-suite runs in Phases 13, 16, 18.
- **Manual:** Continuous smoke tests (connect/auth, session join, notifications, rate-limit).
- **Monitoring:** Add DEBUG logs; track Redis latency metrics.

---

## ⚠️ Risk & Mitigation

| Risk | Mitigation |
| --- | --- |
| Redis downtime | Add retry/backoff; degrade gracefully |
| Multi-worker inconsistency | Validate via Pub/Sub tests before merge |
| Regression | Rollback to latest stable dual-write phase |

---

## ✅ Deliverables Checklist

- `feature/redis-sync` branch created
- RedisStateManager scaffolded
- SocketManager wrappers added
- Dual-write enabled across handlers
- Pub/Sub operational
- Redis-only mode verified
- Resilience added
- Tests complete
- Deployment configs updated
- Documentation finalized
-