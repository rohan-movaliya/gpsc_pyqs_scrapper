# Inx Chatbot

# **INX Chatbot – Project Overview**

## **Overview**

The **INX Chatbot Backend** is an AI-powered conversational platform that allows employees to interact with business systems through natural language.  
Built with **FastAPI**, **LangChain**, and **LangGraph**, it supports leave management, work-from-home requests, worklog tracking, and company policy queries — all handled via intelligent multi-agent workflows.

---

## **Key Objectives**

- Simplify business operations through natural language interaction
- Centralize access to multiple enterprise systems
- Maintain conversation context and memory
- Ensure secure credential handling and optimized caching
- Improve response speed and reduce LLM cost

---

## **Architecture Summary**

- **FastAPI** – RESTful API server
- **LangGraph** – Multi-agent workflow orchestration
- **LangChain** – LLM integration and tool management
- **Redis** – Session & context caching
- **ChromaDB** – Vector database for semantic document search
- **Groq / Google Gemini** – LLM providers for conversation processing

---

## **Core Features**

- **Multi-Agent System** – Specialized agents for Leave, WFH, Worklog, Policy, and Common queries
- **Secure Credential Injection** – Credentials isolated from LLMs
- **Redis Caching** – Fast data retrieval and reduced API calls
- **Conversation Memory** – Summarized chat memory to save tokens
- **Policy Search** – Natural language search using ChromaDB
- **Multi-Model Support** – Groq (Llama) & Google Gemini integration

---

## **Tech Stack**

| Category | Technologies |
| --- | --- |
| **Backend** | FastAPI, Uvicorn, Starlette |
| **AI & Workflow** | LangChain, LangGraph |
| **LLMs** | Groq (Llama), Google Gemini |
| **Cache/DB** | Redis, ChromaDB |
| **Security** | JWT, Cryptography |
| **Testing** | Pytest, Coverage |

---

## **Use Cases**

- Employee self-service (leave, WFH, worklog)
- HR policy assistant via natural language
- Unified chatbot for enterprise systems
- Context-aware and mobile-friendly interface

---

## **Highlights**

- Secure and scalable multi-agent architecture

- High-speed Redis caching
- Token-efficient memory system
- Semantic policy retrieval
- Environment-based configuration

I